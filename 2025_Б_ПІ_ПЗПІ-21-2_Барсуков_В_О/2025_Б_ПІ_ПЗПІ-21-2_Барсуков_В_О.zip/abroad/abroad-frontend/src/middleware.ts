// UTILS
import { getCookie } from 'cookies-next';
import { publicRouteCheckerUtil } from '@/utils/routes/publicRouteChecker.util';

// CONSTANT
import { ACCESS_TOKEN_KEY } from '@/constants/jwt.constant';
import { ROUTES } from '@/routes/routes';

// INTERFACES
import { NextRequest, NextResponse } from 'next/server';
import { jwtDecode } from 'jwt-decode';

export interface AccessTokenPayload {
	userId: number;
	name: string;
	surname: string;
	email: string;
	iat: number;
	exp: number;
}

export const middleware = (request: NextRequest) => {
	const accessToken = getCookie(ACCESS_TOKEN_KEY, { req: request });

	if (publicRouteCheckerUtil(request.nextUrl.pathname) && !accessToken) return NextResponse.next();

	if (!accessToken) return NextResponse.redirect(new URL(ROUTES.LOGIN, request.url));

	const payload: AccessTokenPayload = jwtDecode(accessToken);

	if ((request.nextUrl.pathname === ROUTES.LOGIN || request.nextUrl.pathname === ROUTES.SIGNUP) && accessToken)
		return NextResponse.redirect(new URL(ROUTES.USERS + '/' + payload.userId, request.url));

	return NextResponse.next();
};

export const config = {
	matcher: ['/((?!_next|.*\\..*).*)'],
};

'use client';

// STYLES
import '../styles/global.css';

// PROVIDERS
import { HeroUIProvider } from '@heroui/react';
import { ToastProvider } from '@heroui/react';
import QueryProvider from '@/components/layouts/QueryProvider';

// INTERFACES
import { JSX, ReactNode } from 'react';

interface LayoutProps {
	children: ReactNode;
}

const MainLayout = ({ children }: LayoutProps): JSX.Element => {
	return (
		<html>
			<head>
				<title>Connect Abroad</title>
			</head>
			<body>
				<QueryProvider>
					<HeroUIProvider>
						<ToastProvider />
						{children}
					</HeroUIProvider>
				</QueryProvider>
			</body>
		</html>
	);
};

export default MainLayout;

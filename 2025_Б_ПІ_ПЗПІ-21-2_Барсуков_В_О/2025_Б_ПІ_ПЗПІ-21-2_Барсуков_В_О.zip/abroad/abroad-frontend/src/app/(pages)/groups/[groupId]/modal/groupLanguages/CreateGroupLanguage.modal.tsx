'use client';

import { Fragment, JSX } from 'react';
import { GetFullGroupResponseDto } from '@/services/group/dto/response/GetFullGroup.response.dto';
import {
	Autocomplete,
	AutocompleteItem,
	Button,
	Modal,
	ModalBody,
	ModalContent,
	ModalFooter,
	ModalHeader,
	Select,
	SelectItem,
	useDisclosure,
} from '@heroui/react';
import { useCreateGroupLanguageMutation } from '@/hooks/group/group-language.hook';
import { CreateGroupLanguageRequestDto } from '@/services/group/group-language/dto/request/CreateGroupLanguage.request.dto';
import { LevelOfLanguage } from '@/enum/LevelOfLanguage.enum';
import { Form, Formik, FormikHelpers } from 'formik';
import { IconPlus } from '@tabler/icons-react';
import { BtnColorStyle } from '@/constants/btn.constant';
import { CreateGroupLanguageSchema } from '@/app/(pages)/groups/[groupId]/modal/groupLanguages/CreateGroupLanguage.schema';
import ISO6391 from 'iso-639-1';

interface CreateGroupLanguageModalProps {
	group: GetFullGroupResponseDto;
}

const CreateGroupLanguageModal = ({ group }: CreateGroupLanguageModalProps): JSX.Element => {
	const { isOpen, onOpen, onClose, onOpenChange } = useDisclosure();

	const createGroupLanguage = useCreateGroupLanguageMutation(group.groupId);

	const initialValues: CreateGroupLanguageRequestDto = {
		groupId: group.groupId,
		language: '',
		levelOfLanguage: LevelOfLanguage.A1,
	};

	const submitHandler = async (
		values: CreateGroupLanguageRequestDto,
		{ resetForm }: FormikHelpers<CreateGroupLanguageRequestDto>,
	) => {
		await createGroupLanguage.mutateAsync(values);
		resetForm();
		onClose();
	};

	return (
		<Fragment>
			<Button isIconOnly startContent={<IconPlus size={18} />} size="sm" className={BtnColorStyle.primary} onPress={onOpen} />
			<Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="top" size="lg">
				<ModalContent>
					<Formik initialValues={initialValues} onSubmit={submitHandler} validationSchema={CreateGroupLanguageSchema}>
						{({ values, setFieldValue, handleSubmit, isValid }) => (
							<Form onSubmit={handleSubmit}>
								<ModalHeader>Language</ModalHeader>
								<ModalBody>
									<Autocomplete
										isRequired
										disallowEmptySelection
										label="Language"
										variant="bordered"
										size="sm"
										onSelectionChange={(key) => setFieldValue('language', key)}
									>
										{ISO6391.getAllCodes().map((code) => (
											<AutocompleteItem key={code}>{ISO6391.getName(code)}</AutocompleteItem>
										))}
									</Autocomplete>
									<Select
										isRequired
										disallowEmptySelection
										label="Level of language"
										variant="bordered"
										size="sm"
										onChange={(event) => setFieldValue('levelOfLanguage', event.target.value)}
									>
										<SelectItem key={LevelOfLanguage.NATIVE}>Native</SelectItem>
										<SelectItem key={LevelOfLanguage.A1}>A1</SelectItem>
										<SelectItem key={LevelOfLanguage.A2}>A2</SelectItem>
										<SelectItem key={LevelOfLanguage.B1}>B1</SelectItem>
										<SelectItem key={LevelOfLanguage.B2}>B2</SelectItem>
										<SelectItem key={LevelOfLanguage.C1}>C1</SelectItem>
										<SelectItem key={LevelOfLanguage.C2}>C2</SelectItem>
									</Select>
								</ModalBody>
								<ModalFooter>
									<Button isDisabled={!isValid} className={BtnColorStyle.primary} type="submit">
										Create
									</Button>
								</ModalFooter>
							</Form>
						)}
					</Formik>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default CreateGroupLanguageModal;

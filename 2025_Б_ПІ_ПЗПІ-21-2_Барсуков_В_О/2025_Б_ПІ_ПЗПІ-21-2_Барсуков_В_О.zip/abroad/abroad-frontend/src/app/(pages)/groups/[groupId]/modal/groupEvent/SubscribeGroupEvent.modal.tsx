'use client';

import { Fragment, JSX } from 'react';
import { GetFullGroupResponseDto } from '@/services/group/dto/response/GetFullGroup.response.dto';
import {
	Button,
	Modal,
	ModalBody,
	ModalContent,
	ModalFooter,
	ModalHeader,
	Select,
	SelectItem,
	useDisclosure,
} from '@heroui/react';
import { useSubscribeEventGroupMutation } from '@/hooks/event/event-group.hook';
import { SubscribeOrUnsubscribeEventGroupRequestDto } from '@/services/event/event-group/dto/request/SubscribeOrUnsubscribeEventGroup.request.dto';
import { Form, Formik, FormikHelpers } from 'formik';
import { useGetEventsQuery } from '@/hooks/event/event.hook';
import { IconPlus } from '@tabler/icons-react';
import { BtnColorStyle } from '@/constants/btn.constant';

interface SubscribeGroupEventProps {
	group: GetFullGroupResponseDto;
}

const SubscribeGroupEvent = ({ group }: SubscribeGroupEventProps): JSX.Element => {
	const { isOpen, onOpen, onClose, onOpenChange } = useDisclosure();

	const subscribeGroupEvent = useSubscribeEventGroupMutation(group.groupId);
	const events = useGetEventsQuery().data?.data || [];

	const initialValues = {
		eventId: 0,
	};

	const submitHandler = async (values: any, { resetForm }: FormikHelpers<any>) => {
		await subscribeGroupEvent.mutateAsync({
			eventId: values.eventId,
			dto: {
				groupId: group.groupId,
			},
		});
		resetForm();
		onClose();
	};

	return (
		<Fragment>
			<Button isIconOnly startContent={<IconPlus size={18} />} size="sm" className={BtnColorStyle.primary} onPress={onOpen} />
			<Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="top" size="lg">
				<ModalContent>
					<Formik initialValues={initialValues} onSubmit={submitHandler}>
						{({ setFieldValue, handleSubmit }) => (
							<Form onSubmit={handleSubmit}>
								<ModalHeader>Event</ModalHeader>
								<ModalBody>
									<Select
										isRequired
										disallowEmptySelection
										label="Event"
										variant="bordered"
										size="sm"
										onChange={(event) => setFieldValue('eventId', Number(event.target.value))}
										items={events}
									>
										{(item) => <SelectItem key={item.eventId}>{item.nameOfEvent}</SelectItem>}
									</Select>
								</ModalBody>
								<ModalFooter>
									<Button className={BtnColorStyle.primary} type="submit">
										Confirm
									</Button>
								</ModalFooter>
							</Form>
						)}
					</Formik>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default SubscribeGroupEvent;

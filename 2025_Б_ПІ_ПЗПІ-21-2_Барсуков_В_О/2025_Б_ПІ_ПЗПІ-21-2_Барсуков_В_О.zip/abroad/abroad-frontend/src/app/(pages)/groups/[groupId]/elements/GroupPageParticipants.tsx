'use client';

import { Fragment, JSX } from 'react';
import {
	Avatar,
	Button,
	Card,
	CardBody,
	CardHeader,
	Modal,
	ModalBody,
	ModalContent,
	ModalHeader,
	useDisclosure,
	User,
} from '@heroui/react';
import { GetFullGroupResponseDto } from '@/services/group/dto/response/GetFullGroup.response.dto';
import Link from 'next/link';
import { ROUTES } from '@/routes/routes';
import { BtnColorStyle } from '@/constants/btn.constant';
import { useDeleteGroupUserMutation } from '@/hooks/group/group-user.hook';
import { getCookie } from 'cookies-next';
import { ACCESS_TOKEN_KEY } from '@/constants/jwt.constant';
import { AccessTokenPayload } from '@/middleware';
import { jwtDecode } from 'jwt-decode';

interface GroupPageParticipantsProps {
	group: GetFullGroupResponseDto;
}

const GroupPageParticipants = ({ group }: GroupPageParticipantsProps): JSX.Element => {
	const { isOpen, onOpen, onOpenChange } = useDisclosure();

	const deleteGroupUser = useDeleteGroupUserMutation(group.groupId);

	const deleteGroupUserHandler = async (groupUserId: number) => {
		await deleteGroupUser.mutateAsync({
			groupUserId,
		});
	};

	return (
		<Fragment>
			<Card className="card">
				<CardHeader>
					<div className="flex flex-row items-center justify-between w-full">
						<span className="ml-4 text-xl font-medium">Participants</span>
						<span className="mr-8 text-xl font-medium">{group.users.length}</span>
					</div>
				</CardHeader>
				<CardBody
					className={`px-6 pt-0 w-full h-full ${group.users.length ? 'cursor-pointer' : ''}`}
					onClick={group.users.length ? onOpen : () => {}}
				>
					<div className="flex items-center justify-center w-full h-full">
						{group.users.length ? (
							<div className="flex flex-wrap items-center justify-center gap-6">
								{group.users.slice(0, 6).map((user) => (
									<div key={user.groupUserId} className="flex flex-col items-center gap-1">
										<Avatar className="w-20 h-20" />
										<span className="font-medium">
											{user.user.name} {user.user.surname}
										</span>
									</div>
								))}
							</div>
						) : (
							<span className="text-sm text-foreground-400">There are no participants</span>
						)}
					</div>
				</CardBody>
			</Card>
			<Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="top" size="3xl">
				<ModalContent>
					<ModalHeader>Participants</ModalHeader>
					<ModalBody>
						<div className="flex flex-col items-start gap-4 w-full">
							{group.users.map((user) => (
								<div key={user.groupUserId} className="flex flex-row items-center justify-between w-full">
									<User
										name={`${user.user.name} ${user.user.surname}`}
										avatarProps={{ size: 'lg' }}
										as={Link}
										href={ROUTES.USERS + '/' + user.user.userId}
									/>
									{group.isOwner && group.admin.userId !== user.user.userId ? (
										<Button className={BtnColorStyle.danger} size="sm" onPress={() => deleteGroupUserHandler(user.groupUserId)}>
											Delete
										</Button>
									) : null}
								</div>
							))}
						</div>
					</ModalBody>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default GroupPageParticipants;

'use client';

import { JSX } from 'react';
import { Card, CardHeader, CardBody, Chip } from '@heroui/react';
import { GetFullGroupResponseDto } from '@/services/group/dto/response/GetFullGroup.response.dto';
import { TARGET_TEXT_CONSTANT } from '@/constants/target.constant';
import CreateOrUpdateGroupTargets from '@/app/(pages)/groups/[groupId]/modal/groupTargets/CreateOrUpdateGroupTargets.modal';

interface GroupPageTargetProps {
	group: GetFullGroupResponseDto;
}

const GroupPageTarget = ({ group }: GroupPageTargetProps): JSX.Element => {
	return (
		<Card className="card">
			<CardHeader className="flex flex-row justify-between">
				<span className="ml-4 text-xl font-medium">Group targets</span>
				{group.isOwner ? <CreateOrUpdateGroupTargets group={group} /> : null}
			</CardHeader>
			<CardBody className="ml-4 pt-0">
				{group.targets.length ? (
					<div className="flex flex-row items-center gap-1">
						{group.targets.map((target) => (
							<Chip key={target.groupTargetId} size="sm">
								{TARGET_TEXT_CONSTANT[target.target]}
							</Chip>
						))}
					</div>
				) : (
					<span className="text-sm text-foreground-400">There are no targets</span>
				)}
			</CardBody>
		</Card>
	);
};

export default GroupPageTarget;

'use client';

import { JSX } from 'react';
import { Avatar, Card, CardHeader } from '@heroui/react';
import { GetFullGroupResponseDto } from '@/services/group/dto/response/GetFullGroup.response.dto';
import Link from 'next/link';
import { ROUTES } from '@/routes/routes';

interface GroupPageAdminProps {
	group: GetFullGroupResponseDto;
}

const GroupPageAdmin = ({ group }: GroupPageAdminProps): JSX.Element => {
	return (
		<Card className="card">
			<CardHeader>
				<Link className="flex items-center gap-2" href={ROUTES.USERS + '/' + group.admin.userId}>
					<Avatar size="lg" />
					<div className="flex flex-col">
						<span className="font-medium">
							{group.admin.name} {group.admin.surname}
						</span>
						<span className="text-sm text-foreground-400">Administrator</span>
					</div>
				</Link>
			</CardHeader>
		</Card>
	);
};

export default GroupPageAdmin;

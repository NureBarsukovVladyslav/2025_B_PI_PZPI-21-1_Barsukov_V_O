'use client';

import { JSX } from 'react';
import { Card, CardHeader, CardBody, Chip } from '@heroui/react';
import { GetFullGroupResponseDto } from '@/services/group/dto/response/GetFullGroup.response.dto';
import { HOBBY_TEXT_CONSTANT } from '@/constants/hobby.constant';
import CreateOrUpdateGroupHobbiesModal from '@/app/(pages)/groups/[groupId]/modal/groupHobbies/CreateOrUpdateGroupHobby.modal';

interface GroupPageHobbyProps {
	group: GetFullGroupResponseDto;
}

const GroupPageHobby = ({ group }: GroupPageHobbyProps): JSX.Element => {
	return (
		<Card className="card">
			<CardHeader className="flex flex-row justify-between">
				<span className="ml-4 text-xl font-medium">Group hobbies</span>
				{group.isOwner ? <CreateOrUpdateGroupHobbiesModal group={group} /> : null}
			</CardHeader>
			<CardBody className="ml-4 pt-0">
				{group.hobbies.length ? (
					<div className="flex flex-row items-center gap-1">
						{group.hobbies.map((hobby) => (
							<Chip key={hobby.groupHobbyId} size="sm">
								{HOBBY_TEXT_CONSTANT[hobby.hobby]}
							</Chip>
						))}
					</div>
				) : (
					<span className="text-sm text-foreground-400">There are no hobby</span>
				)}
			</CardBody>
		</Card>
	);
};

export default GroupPageHobby;

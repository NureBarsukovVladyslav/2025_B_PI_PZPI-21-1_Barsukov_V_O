'use client';

import { Fragment, JSX, useState } from 'react';
import { GetFullGroupResponseDto } from '@/services/group/dto/response/GetFullGroup.response.dto';
import { getCookie } from 'cookies-next';
import { ACCESS_TOKEN_KEY } from '@/constants/jwt.constant';
import { AccessTokenPayload } from '@/middleware';
import { jwtDecode } from 'jwt-decode';
import { Avatar, Button, Modal, ModalBody, ModalContent, ModalHeader, useDisclosure } from '@heroui/react';
import { useCreateGroupMessageMutation } from '@/hooks/group/group-message.hook';
import { BtnColorStyle } from '@/constants/btn.constant';
import InputGroup from '@/components/elements/input/InputGroup';
import { Input } from '@heroui/input';
import { IconSend } from '@tabler/icons-react';

interface GroupPageChatProps {
	group: GetFullGroupResponseDto;
}

const GroupPageChat = ({ group }: GroupPageChatProps): JSX.Element => {
	const accessToken = getCookie(ACCESS_TOKEN_KEY) || null;
	const jwtUser: AccessTokenPayload | null = accessToken ? jwtDecode(accessToken) : null;

	const [textOfMessage, setTextOfMessage] = useState<string>('');

	const { isOpen, onOpen, onOpenChange } = useDisclosure();

	const createMessage = useCreateGroupMessageMutation(group.groupId);

	const createMessageHandler = async () => {
		if (!textOfMessage.trim().length) return;

		await createMessage.mutateAsync({
			textOfMessage,
		});

		setTextOfMessage('');
	};

	return (
		<Fragment>
			<Button size="sm" className={BtnColorStyle.primary} onPress={onOpen}>
				Open chat
			</Button>
			<Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="top" size="4xl" className="h-5/6">
				<ModalContent>
					<ModalHeader>Group chat</ModalHeader>
					<ModalBody className="flex flex-col items-center h-full">
						<div className="flex flex-col gap-2 flex-1 w-full">
							{group.messages.map((message) => (
								<div
									key={message.messageId}
									className={`flex gap-2 w-full ${message.user.userId === jwtUser?.userId ? 'flex-row-reverse text-right' : 'flex-row'}`}
								>
									<Avatar size="md" />
									<div className="flex flex-col">
										<span className="font-medium">
											{message.user.userId === jwtUser?.userId ? 'Me' : `${message.user.name} ${message.user.surname}`}
											{group.admin.userId === message.user.userId ? (
												<span className="text-sm text-foreground-400 ml-1">(administrator)</span>
											) : null}
										</span>
										<span>{message.textOfMessage}</span>
									</div>
								</div>
							))}
						</div>
						<InputGroup>
							<Input
								placeholder="Message..."
								variant="bordered"
								value={textOfMessage}
								onValueChange={(value) => setTextOfMessage(value)}
							/>
							<Button
								isIconOnly
								startContent={<IconSend size={18} />}
								className={BtnColorStyle.primary}
								onPress={createMessageHandler}
							/>
						</InputGroup>
					</ModalBody>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default GroupPageChat;

'use client';

import { JSX } from 'react';
import { Card, CardHeader, CardBody, User, Autocomplete, Button, Input } from '@heroui/react';
import { BtnColorStyle } from '@/constants/btn.constant';
import Link from 'next/link';
import { ROUTES } from '@/routes/routes';
import { useGetGroupsQuery, useGetRecommendationGroupsQuery } from '@/hooks/group/group.hook';
import CreateGroupModal from '@/app/(pages)/groups/modal/CreateGroup.modal';
import { useAddGroupUserMutation, useLeaveGroupUserMutation } from '@/hooks/group/group-user.hook';

const Groups = (): JSX.Element => {
	const groups = useGetGroupsQuery().data?.data || [];
	const recommendationGroups = useGetRecommendationGroupsQuery().data?.data || [];

	const addGroupUser = useAddGroupUserMutation();
	const leaveGroupUser = useLeaveGroupUserMutation();

	const addGroupUserHandler = async (groupId: number) => {
		await addGroupUser.mutateAsync(groupId);
	};

	const leaveGroupUserHandler = async (groupId: number) => {
		await leaveGroupUser.mutateAsync(groupId);
	};

	return (
		<div className="flex flex-row gap-4 w-full h-full">
			<Card className="card w-full list-max-height">
				<CardHeader className="flex flex-row justify-between">
					<span className="ml-4 text-xl font-medium">Groups</span>
					<CreateGroupModal />
				</CardHeader>
				<CardBody className="pt-0 px-6">
					{groups.length ? (
						<div className="flex flex-col items-start gap-4 w-full">
							{groups.map((group) => (
								<div key={group.groupId} className="flex flex-row items-center justify-between w-full">
									<User
										name={group.nameOfGroup}
										description={`Participants: ${group.users.length}`}
										avatarProps={{ size: 'lg' }}
										as={Link}
										href={ROUTES.GROUPS + '/' + group.groupId}
									/>
									{!group.isParticipant ? (
										<Button className={BtnColorStyle.primary} size="sm" onPress={() => addGroupUserHandler(group.groupId)}>
											Enter
										</Button>
									) : (
										<Button className={BtnColorStyle.danger} size="sm" onPress={() => leaveGroupUserHandler(group.groupId)}>
											Leave
										</Button>
									)}
								</div>
							))}
						</div>
					) : (
						<div className="flex items-center justify-center text-base text-foreground-400 w-full h-full">
							There are no groups
						</div>
					)}
				</CardBody>
			</Card>
			<div className="list-max-height flex flex-col gap-4 w-full h-full" style={{ flex: '1 1 50%' }}>
				<Card className="card flex-1 h-full">
					<CardHeader>
						<span className="ml-4 text-xl font-medium">Recommendations</span>
					</CardHeader>
					<CardBody className={`pt-0 px-6 ${!recommendationGroups.length ? 'justify-center' : ''}`}>
						{recommendationGroups.length ? (
							<div className="flex flex-col items-start gap-4 w-full">
								{recommendationGroups.map((group) => (
									<div key={group.groupId} className="flex flex-row items-center justify-between w-full">
										<User
											name={group.nameOfGroup}
											description={`Participants: ${group.users?.length}`}
											avatarProps={{ size: 'lg' }}
											as={Link}
											href={ROUTES.GROUPS + '/' + group.groupId}
										/>
									</div>
								))}
							</div>
						) : (
							<div className="flex items-center justify-center text-base text-foreground-400 w-full h-full">
								There are no groups
							</div>
						)}
					</CardBody>
				</Card>
			</div>
		</div>
	);
};

export default Groups;

'use client';

import { JSX } from 'react';
import GroupPageHeader from '@/app/(pages)/groups/[groupId]/elements/GroupPageHeader';
import GroupPageDescription from '@/app/(pages)/groups/[groupId]/elements/GroupPageDescription';
import GroupPageEvent from '@/app/(pages)/groups/[groupId]/elements/GroupPageEvent';
import GroupPageTarget from '@/app/(pages)/groups/[groupId]/elements/GroupPageTarget';
import GroupPageLanguage from '@/app/(pages)/groups/[groupId]/elements/GroupPageLanguage';
import GroupPageHobby from '@/app/(pages)/groups/[groupId]/elements/GroupPageHobby';
import GroupPageParticipants from '@/app/(pages)/groups/[groupId]/elements/GroupPageParticipants';
import { useGetGroupQuery } from '@/hooks/group/group.hook';
import GroupPageAdmin from '@/app/(pages)/groups/[groupId]/elements/GroupPageAdmin';

interface GroupPageProps {
	params: {
		groupId: string;
	};
}

const GroupPage = ({ params }: GroupPageProps): JSX.Element => {
	const groupId = Number(params.groupId);
	const group = useGetGroupQuery(groupId).data?.data || null;

	if (!group) return <></>;

	return (
		<div className="flex flex-col gap-4 w-full h-full">
			<GroupPageHeader group={group} />
			<div className="flex flex-row gap-4 w-full h-full">
				<div className="flex flex-col gap-4 w-full h-full">
					<GroupPageDescription group={group} />
					<GroupPageTarget group={group} />
					<GroupPageLanguage group={group} />
					<GroupPageHobby group={group} />
					<GroupPageEvent group={group} />
				</div>
				<div className="flex flex-col gap-4 w-full h-full" style={{ flex: '1 2 auto' }}>
					<GroupPageAdmin group={group} />
					<GroupPageParticipants group={group} />
				</div>
			</div>
		</div>
	);
};

export default GroupPage;

'use client';

import { JSX } from 'react';
import { Card, CardHeader, CardBody } from '@heroui/react';
import { GetFullGroupResponseDto } from '@/services/group/dto/response/GetFullGroup.response.dto';

interface GroupPageDescriptionProps {
	group: GetFullGroupResponseDto;
}

const GroupPageDescription = ({ group }: GroupPageDescriptionProps): JSX.Element => {
	return (
		<Card className="card">
			<CardHeader className="flex flex-row justify-between">
				<span className="ml-4 text-xl font-medium">Description</span>
			</CardHeader>
			<CardBody className="mx-4 pt-0">
				<span className="whitespace-break-spaces">{group.description}</span>
			</CardBody>
		</Card>
	);
};

export default GroupPageDescription;

'use client';

import { JSX } from 'react';
import { Button, Card, CardBody, CardHeader, Chip } from '@heroui/react';
import Link from 'next/link';
import { IconTrash } from '@tabler/icons-react';
import { BtnColorStyle } from '@/constants/btn.constant';
import { GetFullGroupResponseDto } from '@/services/group/dto/response/GetFullGroup.response.dto';
import { TARGET_TEXT_CONSTANT } from '@/constants/target.constant';
import { ROUTES } from '@/routes/routes';
import SubscribeGroupEventModal from '@/app/(pages)/groups/[groupId]/modal/groupEvent/SubscribeGroupEvent.modal';
import { useUnsubscribeEventGroupMutation } from '@/hooks/event/event-group.hook';

interface GroupPageEventProps {
	group: GetFullGroupResponseDto;
}

const GroupPageEvent = ({ group }: GroupPageEventProps): JSX.Element => {
	const unsubscribeGroupEvent = useUnsubscribeEventGroupMutation(group.groupId);

	const unsubscribeGroupEventHandler = async (eventId: number) => {
		await unsubscribeGroupEvent.mutateAsync({
			eventId,
			dto: {
				groupId: group.groupId,
			},
		});
	};

	return (
		<Card className="card event-list-max-height">
			<CardHeader className="flex flex-row justify-between">
				<span className="ml-4 text-xl font-medium">Events</span>
				{group.isOwner ? <SubscribeGroupEventModal group={group} /> : null}
			</CardHeader>
			<CardBody className="ml-4 pt-0 w-full h-full">
				{group.events.length ? (
					<div className="flex flex-col gap-2 w-full h-full">
						{group.events.map((event) => (
							<Card key={event.groupEventId} className="double-card" style={{ width: '95%' }}>
								<CardHeader>
									<div className="flex flex-col gap-1 w-full ml-4">
										<div className="flex flex-row justify-between">
											<Link href={ROUTES.EVENTS + '/' + event.event.eventId} className="text-xl font-medium underline">
												{event.event.nameOfEvent}
											</Link>
											{group.isOwner ? (
												<Button
													isIconOnly
													startContent={<IconTrash size={18} />}
													size="sm"
													className={BtnColorStyle.danger}
													onPress={() => unsubscribeGroupEventHandler(event.event.eventId)}
												/>
											) : null}
										</div>
										<div className="flex flex-col">
											<span>
												Date time: {event.event.dateOfEvent.split('T')[0]}, {event.event.timeStart} - {event.event.timeEnd}
											</span>
											<span>
												Location: {event.event.country}, {event.event.city}, {event.event.address}
											</span>
										</div>
										{event.event.targets.length ? (
											<div className="flex flex-row items-center gap-1">
												{event.event.targets.map((target) => (
													<Chip key={target.eventTargetId} size="sm">
														{TARGET_TEXT_CONSTANT[target.target]}
													</Chip>
												))}
											</div>
										) : (
											<span className="text-sm text-foreground-400">There are no targets</span>
										)}
									</div>
								</CardHeader>
							</Card>
						))}
					</div>
				) : (
					<span className="text-sm text-foreground-400">There are no events</span>
				)}
			</CardBody>
		</Card>
	);
};

export default GroupPageEvent;

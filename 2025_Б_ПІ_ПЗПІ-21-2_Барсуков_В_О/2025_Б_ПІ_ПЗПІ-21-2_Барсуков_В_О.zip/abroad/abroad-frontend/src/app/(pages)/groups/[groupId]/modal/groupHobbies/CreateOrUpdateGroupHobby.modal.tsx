'use client';

import { Fragment, JSX } from 'react';
import { GetFullGroupResponseDto } from '@/services/group/dto/response/GetFullGroup.response.dto';
import {
	Button,
	Modal,
	ModalBody,
	ModalContent,
	ModalFooter,
	ModalHeader,
	Select,
	SelectItem,
	useDisclosure,
} from '@heroui/react';
import { useCreateOrUpdateGroupHobbyMutation } from '@/hooks/group/group-hobby.hook';
import { CreateOrUpdateGroupHobbyRequestDto } from '@/services/group/group-hobby/dto/request/CreateOrUpdateGroupHobby.request.dto';
import { Form, Formik, FormikHelpers } from 'formik';
import { IconEdit } from '@tabler/icons-react';
import { BtnColorStyle } from '@/constants/btn.constant';
import { Hobby } from '@/enum/Hobby.enum';
import { HOBBY_TEXT_CONSTANT } from '@/constants/hobby.constant';

interface CreateOrUpdateGroupHobbiesModalProps {
	group: GetFullGroupResponseDto;
}

const CreateOrUpdateGroupHobbiesModal = ({ group }: CreateOrUpdateGroupHobbiesModalProps): JSX.Element => {
	const { isOpen, onOpen, onClose, onOpenChange } = useDisclosure();

	const createOrUpdateGroupHobbies = useCreateOrUpdateGroupHobbyMutation(group.groupId);

	const initialValues: CreateOrUpdateGroupHobbyRequestDto = {
		groupId: group.groupId,
		hobbies: group.hobbies.map((hobby) => hobby.hobby),
	};

	const submitHandler = async (
		values: CreateOrUpdateGroupHobbyRequestDto,
		{ resetForm }: FormikHelpers<CreateOrUpdateGroupHobbyRequestDto>,
	) => {
		await createOrUpdateGroupHobbies.mutateAsync(values);
		resetForm();
		onClose();
	};

	return (
		<Fragment>
			<Button isIconOnly startContent={<IconEdit size={18} />} size="sm" className={BtnColorStyle.primary} onPress={onOpen} />
			<Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="top" size="lg">
				<ModalContent>
					<Formik initialValues={initialValues} onSubmit={submitHandler}>
						{({ values, setFieldValue, handleSubmit }) => (
							<Form onSubmit={handleSubmit}>
								<ModalHeader>Hobbies</ModalHeader>
								<ModalBody>
									<Select
										selectionMode="multiple"
										label="Hobbies"
										variant="bordered"
										size="sm"
										defaultSelectedKeys={values.hobbies}
										onChange={(event) => setFieldValue('hobbies', event.target.value ? event.target.value.split(',') : [])}
									>
										<SelectItem key={Hobby.SPORT}>{HOBBY_TEXT_CONSTANT[Hobby.SPORT]}</SelectItem>
										<SelectItem key={Hobby.CULTURE}>{HOBBY_TEXT_CONSTANT[Hobby.CULTURE]}</SelectItem>
										<SelectItem key={Hobby.MOVIE}>{HOBBY_TEXT_CONSTANT[Hobby.MOVIE]}</SelectItem>
										<SelectItem key={Hobby.LITERATURE}>{HOBBY_TEXT_CONSTANT[Hobby.LITERATURE]}</SelectItem>
										<SelectItem key={Hobby.BUSINESS}>{HOBBY_TEXT_CONSTANT[Hobby.BUSINESS]}</SelectItem>
										<SelectItem key={Hobby.VIDEO_GAMES}>{HOBBY_TEXT_CONSTANT[Hobby.VIDEO_GAMES]}</SelectItem>
										<SelectItem key={Hobby.TECH}>{HOBBY_TEXT_CONSTANT[Hobby.TECH]}</SelectItem>
										<SelectItem key={Hobby.MUSIC}>{HOBBY_TEXT_CONSTANT[Hobby.MUSIC]}</SelectItem>
										<SelectItem key={Hobby.TRAVEL}>{HOBBY_TEXT_CONSTANT[Hobby.TRAVEL]}</SelectItem>
										<SelectItem key={Hobby.PHOTOGRAPHY}>{HOBBY_TEXT_CONSTANT[Hobby.PHOTOGRAPHY]}</SelectItem>
										<SelectItem key={Hobby.COOKING}>{HOBBY_TEXT_CONSTANT[Hobby.COOKING]}</SelectItem>
										<SelectItem key={Hobby.ART}>{HOBBY_TEXT_CONSTANT[Hobby.ART]}</SelectItem>
										<SelectItem key={Hobby.DANCE}>{HOBBY_TEXT_CONSTANT[Hobby.DANCE]}</SelectItem>
										<SelectItem key={Hobby.FITNESS}>{HOBBY_TEXT_CONSTANT[Hobby.FITNESS]}</SelectItem>
										<SelectItem key={Hobby.FASHION}>{HOBBY_TEXT_CONSTANT[Hobby.FASHION]}</SelectItem>
										<SelectItem key={Hobby.SCIENCE}>{HOBBY_TEXT_CONSTANT[Hobby.SCIENCE]}</SelectItem>
										<SelectItem key={Hobby.DIY}>{HOBBY_TEXT_CONSTANT[Hobby.DIY]}</SelectItem>
										<SelectItem key={Hobby.GARDENING}>{HOBBY_TEXT_CONSTANT[Hobby.GARDENING]}</SelectItem>
										<SelectItem key={Hobby.ANIMALS}>{HOBBY_TEXT_CONSTANT[Hobby.ANIMALS]}</SelectItem>
										<SelectItem key={Hobby.COLLECTING}>{HOBBY_TEXT_CONSTANT[Hobby.COLLECTING]}</SelectItem>
										<SelectItem key={Hobby.BOARD_GAMES}>{HOBBY_TEXT_CONSTANT[Hobby.BOARD_GAMES]}</SelectItem>
										<SelectItem key={Hobby.MEDITATION}>{HOBBY_TEXT_CONSTANT[Hobby.MEDITATION]}</SelectItem>
										<SelectItem key={Hobby.MOTORSPORTS}>{HOBBY_TEXT_CONSTANT[Hobby.MOTORSPORTS]}</SelectItem>
										<SelectItem key={Hobby.BLOGGING}>{HOBBY_TEXT_CONSTANT[Hobby.BLOGGING]}</SelectItem>
										<SelectItem key={Hobby.CODING}>{HOBBY_TEXT_CONSTANT[Hobby.CODING]}</SelectItem>
										<SelectItem key={Hobby.ASTRONOMY}>{HOBBY_TEXT_CONSTANT[Hobby.ASTRONOMY]}</SelectItem>
										<SelectItem key={Hobby.CAMPING}>{HOBBY_TEXT_CONSTANT[Hobby.CAMPING]}</SelectItem>
										<SelectItem key={Hobby.FISHING}>{HOBBY_TEXT_CONSTANT[Hobby.FISHING]}</SelectItem>
									</Select>
								</ModalBody>
								<ModalFooter>
									<Button className={BtnColorStyle.primary} type="submit">
										Confirm
									</Button>
								</ModalFooter>
							</Form>
						)}
					</Formik>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default CreateOrUpdateGroupHobbiesModal;

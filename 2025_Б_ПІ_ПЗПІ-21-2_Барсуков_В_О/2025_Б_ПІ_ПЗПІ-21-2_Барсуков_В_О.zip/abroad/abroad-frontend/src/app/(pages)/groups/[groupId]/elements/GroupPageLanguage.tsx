'use client';

import { JSX } from 'react';
import { Card, CardHeader, CardBody, Chip, Tooltip } from '@heroui/react';
import { GetFullGroupResponseDto } from '@/services/group/dto/response/GetFullGroup.response.dto';
import ISO6391 from 'iso-639-1';
import { useDeleteGroupLanguageMutation } from '@/hooks/group/group-language.hook';
import CreateGroupLanguageModal from '@/app/(pages)/groups/[groupId]/modal/groupLanguages/CreateGroupLanguage.modal';

interface GroupPageLanguageProps {
	group: GetFullGroupResponseDto;
}

const GroupPageLanguage = ({ group }: GroupPageLanguageProps): JSX.Element => {
	const deleteGroupLanguage = useDeleteGroupLanguageMutation(group.groupId);

	const deleteGroupLanguageHandler = async (groupLanguageId: number) => {
		if (!group.isOwner) return;

		await deleteGroupLanguage.mutateAsync(groupLanguageId);
	};

	return (
		<Card className="card">
			<CardHeader className="flex flex-row justify-between">
				<span className="ml-4 text-xl font-medium">Group languages</span>
				{group.isOwner ? <CreateGroupLanguageModal group={group} /> : null}
			</CardHeader>
			<CardBody className="ml-4 pt-0">
				{group.languages.length ? (
					<div className="flex flex-row items-center gap-1">
						{group.languages.map((language) => (
							<Tooltip key={language.groupLanguageId} content={group.isOwner ? 'Press to delete' : null}>
								<Chip className="cursor-pointer" size="sm" onClick={() => deleteGroupLanguageHandler(language.groupLanguageId)}>
									{ISO6391.getName(language.language)} ({language.levelOfLanguage})
								</Chip>
							</Tooltip>
						))}
					</div>
				) : (
					<span className="text-sm text-foreground-400">There are no languages</span>
				)}
			</CardBody>
		</Card>
	);
};

export default GroupPageLanguage;

import { mixed, object, string } from 'yup';
import { INPUT_DATA_IS_REQUIRED } from '@/constants/error/input.error';
import { LevelOfLanguage } from '@/enum/LevelOfLanguage.enum';

export const CreateGroupLanguageSchema = object().shape({
	language: string().required(INPUT_DATA_IS_REQUIRED),
	levelOfLanguage: mixed<LevelOfLanguage>().required(INPUT_DATA_IS_REQUIRED),
});

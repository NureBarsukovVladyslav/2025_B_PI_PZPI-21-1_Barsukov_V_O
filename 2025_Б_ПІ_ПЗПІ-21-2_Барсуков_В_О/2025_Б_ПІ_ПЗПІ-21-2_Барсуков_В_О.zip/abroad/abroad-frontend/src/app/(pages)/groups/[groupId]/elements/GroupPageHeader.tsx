'use client';

import { Fragment, JSX } from 'react';
import { Avatar, Button, Card, CardHeader } from '@heroui/react';
import { BtnColorStyle } from '@/constants/btn.constant';
import { GetFullGroupResponseDto } from '@/services/group/dto/response/GetFullGroup.response.dto';
import UpdateGroupModal from '@/app/(pages)/groups/modal/UpdateGroup.modal';
import { useDeleteGroupMutation } from '@/hooks/group/group.hook';
import { useAddGroupUserMutation, useLeaveGroupUserMutation } from '@/hooks/group/group-user.hook';
import GroupPageChat from '@/app/(pages)/groups/[groupId]/elements/GroupPageChat';

interface GroupPageHeaderProps {
	group: GetFullGroupResponseDto;
}

const GroupPageHeader = ({ group }: GroupPageHeaderProps): JSX.Element => {
	const addGroupUser = useAddGroupUserMutation(group.groupId);
	const leaveGroupUser = useLeaveGroupUserMutation(group.groupId);
	const deleteGroup = useDeleteGroupMutation(group.groupId);

	const addGroupUserHandler = async () => {
		await addGroupUser.mutateAsync(group.groupId);
	};

	const leaveGroupUserHandler = async () => {
		await leaveGroupUser.mutateAsync(group.groupId);
	};

	const deleteGroupHandler = async () => {
		await deleteGroup.mutateAsync(group.groupId);
	};

	return (
		<Card className="card w-full">
			<CardHeader className="px-6">
				<div className="flex flex-row items-center justify-between w-full h-full">
					<div className="flex flex-row items-center gap-4">
						<Avatar className="w-24 h-24" />
						<div className="flex flex-col">
							<span className="text-2xl font-medium leading-none">{group.nameOfGroup}</span>
							<span className="text-base">
								{group.country}, {group.city}
							</span>
						</div>
					</div>
					<div className="flex flex-col gap-2">
						{group.isOwner ? (
							<Fragment>
								<GroupPageChat group={group} />
								<UpdateGroupModal group={group} />
								<Button size="sm" className={BtnColorStyle.danger} onPress={deleteGroupHandler}>
									Delete group
								</Button>
							</Fragment>
						) : !group.isParticipant ? (
							<Button size="sm" className={BtnColorStyle.primary} onPress={addGroupUserHandler}>
								Enter
							</Button>
						) : (
							<Fragment>
								<GroupPageChat group={group} />
								<Button size="sm" className={BtnColorStyle.danger} onPress={leaveGroupUserHandler}>
									Leave
								</Button>
							</Fragment>
						)}
					</div>
				</div>
			</CardHeader>
		</Card>
	);
};

export default GroupPageHeader;

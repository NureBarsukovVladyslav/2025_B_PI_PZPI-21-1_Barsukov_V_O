import { object, string } from 'yup';
import { DEFAULT_STRING_MIN_LENGTH } from '@/constants/default-value.constant';
import { INPUT_DATA_IS_REQUIRED, INPUT_DATA_TOO_LONG, INPUT_DATA_TOO_SHORT } from '@/constants/error/input.error';

export const CreateOrUpdateGroupSchema = object().shape({
	nameOfGroup: string()
		.min(DEFAULT_STRING_MIN_LENGTH, INPUT_DATA_TOO_SHORT)
		.max(100, INPUT_DATA_TOO_LONG)
		.required(INPUT_DATA_IS_REQUIRED),
	description: string()
		.min(DEFAULT_STRING_MIN_LENGTH, INPUT_DATA_TOO_SHORT)
		.max(1000, INPUT_DATA_TOO_LONG)
		.required(INPUT_DATA_IS_REQUIRED),
	country: string(),
	city: string(),
});

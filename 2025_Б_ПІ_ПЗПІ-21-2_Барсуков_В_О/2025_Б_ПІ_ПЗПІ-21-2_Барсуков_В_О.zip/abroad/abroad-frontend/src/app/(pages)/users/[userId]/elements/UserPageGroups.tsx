'use client';

import { Fragment, JSX } from 'react';
import {
	Avatar,
	Button,
	Card,
	CardBody,
	CardHeader,
	Modal,
	ModalBody,
	ModalContent,
	ModalHeader,
	useDisclosure,
	User,
} from '@heroui/react';
import { GetFullUserResponseDto } from '@/services/user/dto/response/GetFullUser.response.dto';
import Link from 'next/link';
import { ROUTES } from '@/routes/routes';
import { BtnColorStyle } from '@/constants/btn.constant';
import { useLeaveGroupUserMutation } from '@/hooks/group/group-user.hook';
import { ApiEntityEnum } from '@/utils/axios/api.routes';

interface UserPageGroupsProps {
	user: GetFullUserResponseDto;
	isOwner: boolean;
}

const UserPageGroups = ({ user, isOwner }: UserPageGroupsProps): JSX.Element => {
	const { isOpen, onOpen, onOpenChange } = useDisclosure();

	const leaveGroupUser = useLeaveGroupUserMutation(0, ApiEntityEnum.USER + user.userId);

	const leaveGroupUserHandler = async (groupId: number) => {
		await leaveGroupUser.mutateAsync(groupId);
	};

	return (
		<Fragment>
			<Card className="card">
				<CardHeader>
					<div className="flex flex-row items-center justify-between w-full">
						<span className="ml-4 text-xl font-medium">Groups</span>
						<span className="mr-8 text-xl font-medium">{user.groups.length}</span>
					</div>
				</CardHeader>
				<CardBody
					className={`px-6 pt-0 w-full h-full ${user.groups.length ? 'cursor-pointer' : ''}`}
					onClick={user.groups.length ? onOpen : () => {}}
				>
					<div className="flex items-center justify-center w-full h-full">
						{user.groups.length ? (
							<div className="flex flex-wrap items-center justify-center gap-6">
								{user.groups.slice(0, 6).map((group) => (
									<div key={group.groupUserId} className="flex flex-col items-center gap-1">
										<Avatar className="w-20 h-20" />
										<span className="font-medium">{group.group.nameOfGroup}</span>
									</div>
								))}
							</div>
						) : (
							<span className="text-sm text-foreground-400">There are no groups</span>
						)}
					</div>
				</CardBody>
			</Card>
			<Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="top" size="3xl">
				<ModalContent>
					<ModalHeader>Groups</ModalHeader>
					<ModalBody>
						<div className="flex flex-col items-start gap-4 w-full">
							{user.groups.map((group) => (
								<div key={group.groupUserId} className="flex flex-row items-center justify-between w-full">
									<User
										name={group.group.nameOfGroup}
										avatarProps={{ size: 'lg' }}
										as={Link}
										href={ROUTES.GROUPS + '/' + group.group.groupId}
									/>
									{isOwner ? (
										<Button className={BtnColorStyle.danger} size="sm" onPress={() => leaveGroupUserHandler(group.group.groupId)}>
											Leave
										</Button>
									) : null}
								</div>
							))}
						</div>
					</ModalBody>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default UserPageGroups;

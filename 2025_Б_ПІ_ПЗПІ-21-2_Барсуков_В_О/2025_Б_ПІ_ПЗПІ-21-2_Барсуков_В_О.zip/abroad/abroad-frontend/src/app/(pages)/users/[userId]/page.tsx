'use client';

import { JSX } from 'react';
import UserPageHeader from '@/app/(pages)/users/[userId]/elements/UserPageHeader';
import UserPageGoal from '@/app/(pages)/users/[userId]/elements/UserPageGoal';
import UserPageTarget from '@/app/(pages)/users/[userId]/elements/UserPageTarget';
import UserPageLanguage from '@/app/(pages)/users/[userId]/elements/UserPageLanguage';
import UserPageHobby from '@/app/(pages)/users/[userId]/elements/UserPageHobby';
import UserPageMoreInfo from '@/app/(pages)/users/[userId]/elements/UserPageMoreInfo';
import UserPageGroups from '@/app/(pages)/users/[userId]/elements/UserPageGroups';
import { getCookie } from 'cookies-next';
import { ACCESS_TOKEN_KEY } from '@/constants/jwt.constant';
import { AccessTokenPayload } from '@/middleware';
import { jwtDecode } from 'jwt-decode';
import UserPageEvent from '@/app/(pages)/users/[userId]/elements/UserPageEvent';
import { useGetUserQuery } from '@/hooks/user/user.hook';

interface UserPageProps {
	params: {
		userId: string;
	};
}

const UserPage = ({ params }: UserPageProps): JSX.Element => {
	const userId = Number(params.userId);
	const user = useGetUserQuery(userId).data?.data || null;

	const accessToken = getCookie(ACCESS_TOKEN_KEY) || null;
	const jwtUser: AccessTokenPayload | null = accessToken ? jwtDecode(accessToken) : null;
	const isOwner = jwtUser?.userId === userId;

	if (!user) return <></>;

	return (
		<div className="flex flex-col gap-4 w-full h-full">
			<UserPageHeader isOwner={isOwner} user={user} />
			{!user.isFriendBlock ? (
				<div className="flex flex-row gap-4 w-full h-full">
					<div className="flex flex-col gap-4 w-full h-full">
						<UserPageGoal user={user} />
						<UserPageTarget isOwner={isOwner} user={user} />
						<UserPageLanguage isOwner={isOwner} user={user} />
						<UserPageHobby isOwner={isOwner} user={user} />
						<UserPageEvent user={user} />
					</div>
					<div className="flex flex-col gap-4 w-full h-full" style={{ flex: '1 2 auto' }}>
						<UserPageMoreInfo isOwner={isOwner} user={user} />
						<UserPageGroups user={user} />
					</div>
				</div>
			) : null}
		</div>
	);
};

export default UserPage;

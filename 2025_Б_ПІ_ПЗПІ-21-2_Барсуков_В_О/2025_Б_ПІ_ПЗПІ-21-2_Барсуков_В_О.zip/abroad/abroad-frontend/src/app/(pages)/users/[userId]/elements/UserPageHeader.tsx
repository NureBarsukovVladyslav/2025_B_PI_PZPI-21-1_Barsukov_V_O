'use client';

import { JSX } from 'react';
import { Avatar, Button, Card, CardHeader, Chip } from '@heroui/react';
import { BtnColorStyle } from '@/constants/btn.constant';
import { GetFullUserResponseDto } from '@/services/user/dto/response/GetFullUser.response.dto';
import UpdateUserModal from '@/app/(pages)/users/[userId]/modal/updateUser/UpdateUser.modal';
import { STATUS_OF_USER_TEXT_CONSTANT } from '@/constants/statusOfUser.constant';
import ChangeUserPasswordModal from '@/app/(pages)/users/[userId]/modal/changeUserPassword/ChangeUserPassword.modal';
import {
	useBlockFriendMutation,
	useDeleteFriendMutation,
	useMakeFriendMutation,
	useRejectFriendRequestMutation,
	useUnblockFriendMutation,
} from '@/hooks/user/user-friend.hook';
import UserPageChat from '@/app/(pages)/users/[userId]/elements/UserPageChat';

interface UserPageHeaderProps {
	isOwner: boolean;
	user: GetFullUserResponseDto;
}

const UserPageHeader = ({ isOwner, user }: UserPageHeaderProps): JSX.Element => {
	const makeFriend = useMakeFriendMutation(user.userId);
	const rejectFriendRequest = useRejectFriendRequestMutation(user.userId);
	const blockFriend = useBlockFriendMutation(user.userId);
	const unblockFriend = useUnblockFriendMutation(user.userId);
	const deleteFriend = useDeleteFriendMutation(user.userId);

	const makeFriendHandler = async () => {
		await makeFriend.mutateAsync(user.userId);
	};

	const rejectFriendRequestHandler = async () => {
		await rejectFriendRequest.mutateAsync(user.userId);
	};

	const blockFriendHandler = async () => {
		await blockFriend.mutateAsync(user.userId);
	};

	const unblockFriendHandler = async () => {
		await unblockFriend.mutateAsync(user.userId);
	};

	const deleteFriendHandler = async () => {
		await deleteFriend.mutateAsync(user.userId);
	};

	const renderUserPageHeaderBtn = () => {
		if (isOwner) {
			return (
				<div className="flex flex-col gap-2">
					<UpdateUserModal user={user} />
					<ChangeUserPasswordModal />
				</div>
			);
		} else if (user.isFriend) {
			return (
				<div className="flex flex-col gap-2">
					<UserPageChat user={user} />
					<Button size="sm" className={BtnColorStyle.danger} onPress={() => blockFriendHandler()}>
						Block friend
					</Button>
					<Button size="sm" className={BtnColorStyle.danger} onPress={() => deleteFriendHandler()}>
						Delete friend
					</Button>
				</div>
			);
		} else if (user.isFriendPending) {
			return (
				<div className="flex flex-col gap-2">
					<Button size="sm" className={BtnColorStyle.danger} onPress={() => blockFriendHandler()}>
						Block user
					</Button>
					<Button size="sm" className={BtnColorStyle.danger} onPress={() => rejectFriendRequestHandler()}>
						Reject request
					</Button>
				</div>
			);
		} else if (user.isFriendBlock) {
			return (
				<Button size="sm" className={BtnColorStyle.primary} onPress={() => unblockFriendHandler()}>
					Unblock user
				</Button>
			);
		} else {
			return (
				<Button size="sm" className={BtnColorStyle.primary} onPress={() => makeFriendHandler()}>
					Invite friend
				</Button>
			);
		}
	};

	return (
		<Card className="card w-full">
			<CardHeader className="px-6">
				<div className="flex flex-row items-center justify-between w-full h-full">
					<div className="flex flex-row items-center gap-4">
						<Avatar className="w-24 h-24" />
						<div className="flex flex-col">
							<div className="flex flex-row items-center gap-4">
								<span className="text-2xl font-medium leading-none">
									{user.name} {user.surname}
								</span>
								{user.statusOfUser ? (
									<Chip color="primary" size="sm">
										{STATUS_OF_USER_TEXT_CONSTANT[user.statusOfUser]}
									</Chip>
								) : null}
							</div>
							<span className="text-base">
								{user.country}, {user.city}
							</span>
						</div>
					</div>
					{renderUserPageHeaderBtn()}
				</div>
			</CardHeader>
		</Card>
	);
};

export default UserPageHeader;

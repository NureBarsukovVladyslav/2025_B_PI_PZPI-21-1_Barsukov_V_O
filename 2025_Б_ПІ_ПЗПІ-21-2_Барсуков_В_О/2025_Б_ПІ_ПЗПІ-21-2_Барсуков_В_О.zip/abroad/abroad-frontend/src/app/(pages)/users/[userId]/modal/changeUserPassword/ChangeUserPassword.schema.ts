import { object, string } from 'yup';
import {
	PASSWORD_LOWERCASE_REGEX,
	PASSWORD_NUMBER_REGEX,
	PASSWORD_SYMBOLS_REGEX,
	PASSWORD_UPPERCASE_REGEX,
} from '@/regex/password.regex';
import {
	INPUT_CONFIRM_PASSWORD_NOT_MATCH,
	INPUT_DATA_IS_REQUIRED,
	INPUT_PASSWORD_MUST_LOWERCASE,
	INPUT_PASSWORD_MUST_NUMBER,
	INPUT_PASSWORD_MUST_SYMBOL,
	INPUT_PASSWORD_MUST_UPPERCASE,
} from '@/constants/error/input.error';

export const ChangeUserPasswordSchema = object().shape({
	password: string()
		.matches(PASSWORD_LOWERCASE_REGEX, INPUT_PASSWORD_MUST_LOWERCASE)
		.matches(PASSWORD_UPPERCASE_REGEX, INPUT_PASSWORD_MUST_UPPERCASE)
		.matches(PASSWORD_NUMBER_REGEX, INPUT_PASSWORD_MUST_NUMBER)
		.matches(PASSWORD_SYMBOLS_REGEX, INPUT_PASSWORD_MUST_SYMBOL)
		.required(INPUT_DATA_IS_REQUIRED),
	confirmPassword: string().test('passwords-match', INPUT_CONFIRM_PASSWORD_NOT_MATCH, function (value) {
		return this.parent.password === value;
	}),
});

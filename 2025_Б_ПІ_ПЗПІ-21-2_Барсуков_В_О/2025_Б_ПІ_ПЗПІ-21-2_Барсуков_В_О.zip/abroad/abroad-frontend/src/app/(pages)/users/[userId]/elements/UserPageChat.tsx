'use client';

import { Fragment, JSX, useState } from 'react';
import { Avatar, Button, Modal, ModalBody, ModalContent, ModalHeader, useDisclosure } from '@heroui/react';
import { BtnColorStyle } from '@/constants/btn.constant';
import { Input } from '@heroui/input';
import InputGroup from '@/components/elements/input/InputGroup';
import { IconSend } from '@tabler/icons-react';
import { useCreateFriendMessageMutation, useGetFriendsMessagesQuery } from '@/hooks/user/user-friend.hook';
import { getCookie } from 'cookies-next';
import { ACCESS_TOKEN_KEY } from '@/constants/jwt.constant';
import { AccessTokenPayload } from '@/middleware';
import { jwtDecode } from 'jwt-decode';

interface UserPageChatProps {
	user: any;
}

const UserPageChat = ({ user }: UserPageChatProps): JSX.Element => {
	const accessToken = getCookie(ACCESS_TOKEN_KEY) || null;
	const jwtUser: AccessTokenPayload | null = accessToken ? jwtDecode(accessToken) : null;

	const [textOfMessage, setTextOfMessage] = useState<string>('');

	const { isOpen, onOpen, onOpenChange } = useDisclosure();

	const messages = useGetFriendsMessagesQuery(user.userId).data?.data || [];

	const createMessage = useCreateFriendMessageMutation(user.userId);

	const createMessageHandler = async () => {
		if (!textOfMessage.trim().length) return;

		await createMessage.mutateAsync({
			textOfMessage,
		});

		setTextOfMessage('');
	};

	return (
		<Fragment>
			<Button size="sm" className={BtnColorStyle.primary} onPress={onOpen}>
				Open chat
			</Button>
			<Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="top" size="4xl" className="h-5/6">
				<ModalContent>
					<ModalHeader>
						Chat with {user.name} {user.surname}
					</ModalHeader>
					<ModalBody className="flex flex-col items-center h-full">
						<div className="flex flex-col gap-2 flex-1 w-full">
							{messages.map((message) => (
								<div
									key={message.userFriendChatId}
									className={`flex gap-2 w-full ${message.userId === jwtUser?.userId ? 'flex-row-reverse text-right' : 'flex-row'}`}
								>
									<Avatar size="md" />
									<div className="flex flex-col">
										<span className="font-medium">
											{message.userId === jwtUser?.userId ? 'Me' : `${user.name} ${user.surname}`}
										</span>
										<span>{message.textOfMessage}</span>
									</div>
								</div>
							))}
						</div>
						<InputGroup>
							<Input
								placeholder="Message..."
								variant="bordered"
								value={textOfMessage}
								onValueChange={(value) => setTextOfMessage(value)}
							/>
							<Button
								isIconOnly
								startContent={<IconSend size={18} />}
								className={BtnColorStyle.primary}
								onPress={createMessageHandler}
							/>
						</InputGroup>
					</ModalBody>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default UserPageChat;

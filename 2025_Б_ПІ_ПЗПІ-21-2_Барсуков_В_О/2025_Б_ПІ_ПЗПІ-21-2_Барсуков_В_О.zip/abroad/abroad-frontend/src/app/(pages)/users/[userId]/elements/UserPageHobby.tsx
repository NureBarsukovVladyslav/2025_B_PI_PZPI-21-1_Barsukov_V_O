'use client';

import { JSX } from 'react';
import { Card, CardHeader, CardBody, Chip } from '@heroui/react';
import { GetFullUserResponseDto } from '@/services/user/dto/response/GetFullUser.response.dto';
import CreateOrUpdateUserHobbiesModal from '@/app/(pages)/users/[userId]/modal/userHobbies/CreateOrUpdateUserHobbies.modal';
import { HOBBY_TEXT_CONSTANT } from '@/constants/hobby.constant';

interface UserPageHobbyProps {
	isOwner: boolean;
	user: GetFullUserResponseDto;
}

const UserPageHobby = ({ isOwner, user }: UserPageHobbyProps): JSX.Element => {
	return (
		<Card className="card">
			<CardHeader className="flex flex-row justify-between">
				<span className="ml-4 text-xl font-medium">My hobbies</span>
				{isOwner ? <CreateOrUpdateUserHobbiesModal user={user} /> : null}
			</CardHeader>
			<CardBody className="ml-4 pt-0">
				{user.hobbies.length ? (
					<div className="flex flex-row items-center gap-1">
						{user.hobbies.map((hobby) => (
							<Chip key={hobby.userHobbyId} size="sm">
								{HOBBY_TEXT_CONSTANT[hobby.hobby]}
							</Chip>
						))}
					</div>
				) : (
					<span className="text-sm text-foreground-400">There are no hobby</span>
				)}
			</CardBody>
		</Card>
	);
};

export default UserPageHobby;

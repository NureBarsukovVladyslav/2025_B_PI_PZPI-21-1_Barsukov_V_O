'use client';

import { Fragment, JSX } from 'react';
import { Button, Input, Modal, ModalBody, ModalContent, ModalFooter, ModalHeader, useDisclosure } from '@heroui/react';
import { useChangeUserPasswordMutation } from '@/hooks/user/user.hook';
import { ChangeUserPasswordRequestDto } from '@/services/user/dto/request/ChangeUserPassword.request.dto';
import { Form, Formik, FormikHelpers } from 'formik';
import { BtnColorStyle } from '@/constants/btn.constant';
import { ChangeUserPasswordSchema } from '@/app/(pages)/users/[userId]/modal/changeUserPassword/ChangeUserPassword.schema';

const ChangeUserPasswordModal = (): JSX.Element => {
	const { isOpen, onOpen, onClose, onOpenChange } = useDisclosure();

	const changeUserPassword = useChangeUserPasswordMutation();

	const initialValues: ChangeUserPasswordRequestDto = {
		password: '',
	};

	const submitHandler = async (
		values: ChangeUserPasswordRequestDto,
		{ resetForm }: FormikHelpers<ChangeUserPasswordRequestDto>,
	) => {
		await changeUserPassword.mutateAsync({
			password: values.password,
		});
		resetForm();
		onClose();
	};

	return (
		<Fragment>
			<Button size="sm" className={BtnColorStyle.primary} onPress={onOpen}>
				Change password
			</Button>
			<Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="top" size="lg">
				<ModalContent>
					<Formik initialValues={initialValues} onSubmit={submitHandler} validationSchema={ChangeUserPasswordSchema}>
						{({ values, errors, setFieldValue, handleSubmit, isValid }) => (
							<Form onSubmit={handleSubmit}>
								<ModalHeader>Update user password</ModalHeader>
								<ModalBody>
									<Input
										isRequired
										type="password"
										label="Password"
										variant="bordered"
										size="sm"
										onValueChange={(value) => setFieldValue('password', value)}
										isInvalid={!!errors.password}
										errorMessage={errors.password as string}
									/>
									<Input
										isRequired
										type="password"
										label="Confirm password"
										variant="bordered"
										size="sm"
										onValueChange={(value) => setFieldValue('confirmPassword', value)}
										isInvalid={!!errors.confirmPassword}
										errorMessage={errors.confirmPassword as string}
									/>
								</ModalBody>
								<ModalFooter>
									<Button isDisabled={!isValid} className={BtnColorStyle.primary} type="submit">
										Update
									</Button>
								</ModalFooter>
							</Form>
						)}
					</Formik>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default ChangeUserPasswordModal;

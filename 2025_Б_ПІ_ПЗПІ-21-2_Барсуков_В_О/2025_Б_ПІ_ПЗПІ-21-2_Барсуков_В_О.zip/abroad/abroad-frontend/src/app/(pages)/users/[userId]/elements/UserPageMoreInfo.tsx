'use client';

import { Fragment, JSX } from 'react';
import { Card, CardHeader, Modal, ModalBody, ModalHeader, useDisclosure, Button, ModalContent } from '@heroui/react';
import { IconInfoCircle } from '@tabler/icons-react';
import { GetFullUserResponseDto } from '@/services/user/dto/response/GetFullUser.response.dto';
import { GENDER_TEXT_CONSTANT } from '@/constants/male.constant';
import NoneValue from '@/components/elements/NoneValue.element';
import { STATUS_OF_STAY_TEXT_CONSTANT } from '@/constants/statusOfStay.constant';
import { STATUS_OF_VISIBILITY_TEXT_CONSTANT } from '@/constants/statusOfVisibility.constant';

interface UserPageMoreInfoProps {
	isOwner: boolean;
	user: GetFullUserResponseDto;
}

const UserPageMoreInfo = ({ isOwner, user }: UserPageMoreInfoProps): JSX.Element => {
	const { isOpen, onOpen, onClose, onOpenChange } = useDisclosure();

	return (
		<Fragment>
			<Card className="card cursor-pointer">
				<CardHeader onClick={onOpen} className="flex items-center gap-2">
					<IconInfoCircle size={18} />
					<span>More information</span>
				</CardHeader>
			</Card>
			<Modal isOpen={isOpen} onOpenChange={onOpenChange}>
				<ModalContent>
					<ModalHeader>
						More information about {user.name} {user.surname}
					</ModalHeader>
					<ModalBody>
						<div className="flex flex-row justify-between w-full">
							<span className="text-sm text-foreground-400">Gender</span>
							<span className="text-sm">{GENDER_TEXT_CONSTANT[user.gender]}</span>
						</div>
						<div className="flex flex-row justify-between w-full">
							<span className="text-sm text-foreground-400">Date of birth</span>
							<span className="text-sm">{user.dateOfBirth ? user.dateOfBirth.split('T')[0] : <NoneValue />}</span>
						</div>
						<div className="flex flex-row justify-between w-full">
							<span className="text-sm text-foreground-400">Date of arrival</span>
							<span className="text-sm">{user.dateOfArrival ? user.dateOfArrival.split('T')[0] : <NoneValue />}</span>
						</div>
						<div className="flex flex-row justify-between w-full">
							<span className="text-sm text-foreground-400">Status of stay</span>
							<span className="text-sm">{STATUS_OF_STAY_TEXT_CONSTANT[user.statusOfStay] || <NoneValue />}</span>
						</div>
						{isOwner ? (
							<div className="flex flex-row justify-between w-full">
								<span className="text-sm text-foreground-400">Status of visibility</span>
								<span className="text-sm">{STATUS_OF_VISIBILITY_TEXT_CONSTANT[user.statusOfVisibility]}</span>
							</div>
						) : null}
					</ModalBody>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default UserPageMoreInfo;

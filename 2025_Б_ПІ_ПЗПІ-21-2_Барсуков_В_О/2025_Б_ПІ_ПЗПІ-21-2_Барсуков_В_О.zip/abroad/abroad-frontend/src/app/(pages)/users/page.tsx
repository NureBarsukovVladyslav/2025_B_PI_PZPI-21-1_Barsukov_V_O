'use client';

import { JSX } from 'react';
import { Card, CardHeader, CardBody, User, Button } from '@heroui/react';
import { BtnColorStyle } from '@/constants/btn.constant';
import Link from 'next/link';
import { ROUTES } from '@/routes/routes';
import { useGetRecommendationUsersQuery, useGetUsersQuery } from '@/hooks/user/user.hook';
import { getCookie } from 'cookies-next';
import { ACCESS_TOKEN_KEY } from '@/constants/jwt.constant';
import { AccessTokenPayload } from '@/middleware';
import { jwtDecode } from 'jwt-decode';
import { useMakeFriendMutation } from '@/hooks/user/user-friend.hook';
import ISO6391 from 'iso-639-1';

const Users = (): JSX.Element => {
	const accessToken = getCookie(ACCESS_TOKEN_KEY) || null;
	const jwtUser: AccessTokenPayload | null = accessToken ? jwtDecode(accessToken) : null;

	const users = useGetUsersQuery().data?.data || [];
	const recommendationUsers = useGetRecommendationUsersQuery().data?.data || [];
	const makeFriend = useMakeFriendMutation();

	const makeFriendHandler = async (friendId: number): Promise<void> => {
		await makeFriend.mutateAsync(friendId);
	};

	return (
		<div className="flex flex-row gap-4 w-full h-full">
			<Card className="card w-full list-max-height">
				<CardHeader>
					<span className="ml-4 text-xl font-medium">Users</span>
				</CardHeader>
				<CardBody className="pt-0 px-6">
					<div className="flex flex-col items-start gap-4 w-full h-full">
						{users.length ? (
							users.map((user) => (
								<div key={user.userId} className="flex flex-row items-center justify-between w-full">
									<User
										name={`${user.name} ${user.surname}`}
										description={
											<span>
												{user.country}, {user.city} (
												{user.languages.length
													? user.languages
															.map((language) => `${ISO6391.getName(language.language)}: ${language.levelOfLanguage}`)
															.join(', ')
													: 'there are no languages'}
												)
											</span>
										}
										avatarProps={{ size: 'lg' }}
										as={Link}
										href={ROUTES.USERS + '/' + user.userId}
									/>
									{jwtUser?.userId !== user.userId && !user.isFriend ? (
										<Button className={BtnColorStyle.primary} onPress={() => makeFriendHandler(user.userId)} size="sm">
											Invite friend
										</Button>
									) : null}
								</div>
							))
						) : (
							<div className="flex items-center justify-center text-base text-foreground-400 w-full h-full">
								There are no users
							</div>
						)}
					</div>
				</CardBody>
			</Card>
			<div className="list-max-height flex flex-col gap-4 w-full h-full" style={{ flex: '1 1 50%' }}>
				<Card className="card flex-1 h-full">
					<CardHeader>
						<span className="ml-4 text-xl font-medium">Recommendations</span>
					</CardHeader>
					<CardBody className={`pt-0 px-6 ${!recommendationUsers.length ? 'justify-center' : ''}`}>
						{recommendationUsers.length ? (
							<div className="flex flex-col items-start gap-4 w-full">
								{recommendationUsers.map((user) => (
									<div key={user.userId} className="flex flex-row items-center justify-between w-full">
										<User
											name={`${user.name} ${user.surname}`}
											description={
												<span>
													{user.country}, {user.city} (
													{user.languages.length
														? user.languages
																.map((language) => `${ISO6391.getName(language.language)}: ${language.levelOfLanguage}`)
																.join(', ')
														: 'there are no languages'}
													)
												</span>
											}
											avatarProps={{ size: 'lg' }}
											as={Link}
											href={ROUTES.USERS + '/' + user.userId}
										/>
									</div>
								))}
							</div>
						) : (
							<div className="flex items-center justify-center text-base text-foreground-400 w-full h-full">
								There are no users
							</div>
						)}
					</CardBody>
				</Card>
			</div>
		</div>
	);
};

export default Users;

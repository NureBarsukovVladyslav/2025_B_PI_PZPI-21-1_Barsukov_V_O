'use client';

import { JSX } from 'react';
import { Card, CardHeader, CardBody } from '@heroui/react';
import { GetFullUserResponseDto } from '@/services/user/dto/response/GetFullUser.response.dto';

interface UserPageGoalProps {
	user: GetFullUserResponseDto;
}

const UserPageGoal = ({ user }: UserPageGoalProps): JSX.Element => {
	return (
		<Card className="card">
			<CardHeader className="flex flex-row justify-between">
				<span className="ml-4 text-xl font-medium">My goal</span>
			</CardHeader>
			<CardBody className="mx-4 pt-0">
				{user.goalOfUser ? (
					<span className="text-sm whitespace-break-spaces">{user.goalOfUser}</span>
				) : (
					<span className="text-sm text-foreground-400">There are no goals</span>
				)}
			</CardBody>
		</Card>
	);
};

export default UserPageGoal;

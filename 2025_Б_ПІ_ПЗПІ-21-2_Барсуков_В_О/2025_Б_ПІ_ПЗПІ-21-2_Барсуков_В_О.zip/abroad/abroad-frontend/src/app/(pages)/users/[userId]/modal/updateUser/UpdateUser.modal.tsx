'use client';

import { Fragment, JSX, useState } from 'react';
import {
	AccordionItem,
	Autocomplete,
	Button,
	DatePicker,
	Modal,
	ModalBody,
	ModalContent,
	ModalFooter,
	ModalHeader,
	Select,
	SelectItem,
	Textarea,
	useDisclosure,
} from '@heroui/react';
import { useUpdateUserMutation } from '@/hooks/user/user.hook';
import { UpdateUserRequestDto } from '@/services/user/dto/request/UpdateUser.request.dto';
import { TypeOfGender } from '@/enum/TypeOfGender.enum';
import { StatusOfStay } from '@/enum/StatusOfStay.enum';
import { StatusOfUser } from '@/enum/StatusOfUser.enum';
import { GetFullUserResponseDto } from '@/services/user/dto/response/GetFullUser.response.dto';
import { Form, Formik, FormikHelpers } from 'formik';
import { BtnColorStyle } from '@/constants/btn.constant';
import { UpdateUserSchema } from '@/app/(pages)/users/[userId]/modal/updateUser/UpdateUser.schema';
import { Input } from '@heroui/input';
import { parseDate } from '@internationalized/date';
import { City, Country } from 'country-state-city';
import { STATUS_OF_STAY_TEXT_CONSTANT } from '@/constants/statusOfStay.constant';
import { STATUS_OF_USER_TEXT_CONSTANT } from '@/constants/statusOfUser.constant';
import { StatusOfVisibility } from '@/enum/StatusOfVisibility.enum';
import { STATUS_OF_VISIBILITY_TEXT_CONSTANT } from '@/constants/statusOfVisibility.constant';

interface UpdateUserModalProps {
	user: GetFullUserResponseDto;
}

const UpdateUserModal = ({ user }: UpdateUserModalProps): JSX.Element => {
	const [chooseCounty, setChooseCountry] = useState<string | null>(null);

	const { isOpen, onOpen, onClose, onOpenChange } = useDisclosure();

	const updateUser = useUpdateUserMutation(user.userId);

	const initialValues: UpdateUserRequestDto = {
		name: user.name || '',
		surname: user.surname || '',
		email: user.email || '',
		gender: user.gender || TypeOfGender.MALE,
		dateOfBirth: user.dateOfBirth || '',
		country: user.country || '',
		city: user.city || '',
		goalOfUser: user.goalOfUser,
		dateOfArrival: user.dateOfArrival,
		statusOfStay: user.statusOfStay,
		statusOfUser: user.statusOfUser,
		statusOfVisibility: user.statusOfVisibility,
	};

	const submitHandler = async (values: UpdateUserRequestDto, { resetForm }: FormikHelpers<UpdateUserRequestDto>) => {
		await updateUser.mutateAsync(values);
		resetForm();
		onClose();
	};

	return (
		<Fragment>
			<Button size="sm" className={BtnColorStyle.primary} onPress={onOpen}>
				Update profile
			</Button>
			<Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="top" size="lg">
				<ModalContent>
					<Formik initialValues={initialValues} onSubmit={submitHandler} validationSchema={UpdateUserSchema}>
						{({ values, errors, setFieldValue, handleSubmit, isValid }) => (
							<Form onSubmit={handleSubmit}>
								<ModalHeader>Update profile</ModalHeader>
								<ModalBody>
									<Input
										isRequired
										label="Name"
										variant="bordered"
										size="sm"
										value={values.name}
										onValueChange={(value) => setFieldValue('name', value)}
										isInvalid={!!errors.name}
										errorMessage={errors.name as string}
									/>
									<Input
										isRequired
										label="Surname"
										variant="bordered"
										size="sm"
										value={values.surname}
										onValueChange={(value) => setFieldValue('surname', value)}
										isInvalid={!!errors.surname}
										errorMessage={errors.surname as string}
									/>
									<Input
										isRequired
										type="email"
										label="Email"
										variant="bordered"
										size="sm"
										value={values.email}
										onValueChange={(value) => setFieldValue('email', value)}
										isInvalid={!!errors.email}
										errorMessage={errors.email as string}
									/>
									<Select
										isRequired
										disallowEmptySelection
										label="Gender"
										variant="bordered"
										size="sm"
										defaultSelectedKeys={[values.gender]}
										onChange={(event) => setFieldValue('gender', event.target.value)}
									>
										<SelectItem key={TypeOfGender.MALE}>Male</SelectItem>
										<SelectItem key={TypeOfGender.FEMALE}>Female</SelectItem>
									</Select>
									<DatePicker
										showMonthAndYearPickers
										label="Date of birth"
										variant="bordered"
										size="sm"
										value={values.dateOfBirth ? parseDate(values.dateOfBirth.split('T')[0]) : null}
										onChange={(value) => setFieldValue('dateOfBirth', value ? `${value.toString()}T00:00:00Z` : null)}
										isInvalid={!!errors.dateOfBirth}
										errorMessage={errors.dateOfBirth as string}
									/>
									<Autocomplete
										isRequired
										disallowEmptySelection
										label="Contry"
										variant="bordered"
										size="sm"
										defaultInputValue={values.country}
										onSelectionChange={(key) => {
											setChooseCountry(key as string);
											setFieldValue('country', Country.getCountryByCode(key as string)?.name || '');
										}}
										defaultItems={Country.getAllCountries()}
									>
										{(item) => <AccordionItem key={item.isoCode}>{item.name}</AccordionItem>}
									</Autocomplete>
									<Autocomplete
										isDisabled={!chooseCounty}
										isRequired
										disallowEmptySelection
										label="City"
										variant="bordered"
										size="sm"
										defaultInputValue={values.city}
										onSelectionChange={(key) => setFieldValue('city', key)}
										defaultItems={chooseCounty ? City.getCitiesOfCountry(chooseCounty) : []}
									>
										{(item) => <AccordionItem key={item.name}>{item.name}</AccordionItem>}
									</Autocomplete>
									<DatePicker
										showMonthAndYearPickers
										label="Date of arrival"
										variant="bordered"
										size="sm"
										value={values.dateOfArrival ? parseDate(values.dateOfArrival.split('T')[0]) : null}
										onChange={(value) => setFieldValue('dateOfArrival', value ? `${value.toString()}T00:00:00Z` : null)}
										isInvalid={!!errors.dateOfArrival}
										errorMessage={errors.dateOfArrival as string}
									/>
									<Textarea
										label="Goal of user"
										variant="bordered"
										size="sm"
										minRows={1}
										value={values.goalOfUser || ''}
										onValueChange={(value) => setFieldValue('goalOfUser', value || null)}
										isInvalid={!!errors.goalOfUser}
										errorMessage={errors.goalOfUser as string}
									/>
									<Select
										label="Status of stay"
										variant="bordered"
										size="sm"
										defaultSelectedKeys={values.statusOfStay ? [values.statusOfStay] : ''}
										onChange={(event) => setFieldValue('statusOfStay', event.target.value || null)}
									>
										<SelectItem key={StatusOfStay.TEMPORARILY}>
											{STATUS_OF_STAY_TEXT_CONSTANT[StatusOfStay.TEMPORARILY]}
										</SelectItem>
										<SelectItem key={StatusOfStay.FOREVER}>{STATUS_OF_STAY_TEXT_CONSTANT[StatusOfStay.FOREVER]}</SelectItem>
										<SelectItem key={StatusOfStay.LONG_TIME}>{STATUS_OF_STAY_TEXT_CONSTANT[StatusOfStay.LONG_TIME]}</SelectItem>
										<SelectItem key={StatusOfStay.CANNOT_ANSWER}>
											{STATUS_OF_STAY_TEXT_CONSTANT[StatusOfStay.CANNOT_ANSWER]}
										</SelectItem>
									</Select>
									<Select
										label="Status of user"
										variant="bordered"
										size="sm"
										defaultSelectedKeys={values.statusOfUser ? [values.statusOfUser] : ''}
										onChange={(event) => setFieldValue('statusOfUser', event.target.value || null)}
									>
										<SelectItem key={StatusOfUser.LONELY}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.LONELY]}</SelectItem>
										<SelectItem key={StatusOfUser.STRESS}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.STRESS]}</SelectItem>
										<SelectItem key={StatusOfUser.STUDY}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.STUDY]}</SelectItem>
										<SelectItem key={StatusOfUser.WALK}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.WALK]}</SelectItem>
										<SelectItem key={StatusOfUser.SURPRISE}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.SURPRISE]}</SelectItem>
										<SelectItem key={StatusOfUser.ENJOY}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.ENJOY]}</SelectItem>
										<SelectItem key={StatusOfUser.WORKING}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.WORKING]}</SelectItem>
										<SelectItem key={StatusOfUser.EXPLORING}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.EXPLORING]}</SelectItem>
										<SelectItem key={StatusOfUser.RELAXING}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.RELAXING]}</SelectItem>
										<SelectItem key={StatusOfUser.HOMESICK}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.HOMESICK]}</SelectItem>
										<SelectItem key={StatusOfUser.PARTY}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.PARTY]}</SelectItem>
										<SelectItem key={StatusOfUser.LOST}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.LOST]}</SelectItem>
										<SelectItem key={StatusOfUser.NETWORKING}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.NETWORKING]}</SelectItem>
										<SelectItem key={StatusOfUser.ADVENTURE}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.ADVENTURE]}</SelectItem>
									</Select>
									<Select
										isRequired
										disallowEmptySelection
										label="Status of visibility"
										variant="bordered"
										size="sm"
										defaultSelectedKeys={values.statusOfVisibility ? [values.statusOfVisibility] : ''}
										onChange={(event) => setFieldValue('statusOfVisibility', event.target.value)}
									>
										<SelectItem key={StatusOfVisibility.ALL}>
											{STATUS_OF_VISIBILITY_TEXT_CONSTANT[StatusOfVisibility.ALL]}
										</SelectItem>
										<SelectItem key={StatusOfVisibility.FRIEND_ONLY}>
											{STATUS_OF_VISIBILITY_TEXT_CONSTANT[StatusOfVisibility.FRIEND_ONLY]}
										</SelectItem>
									</Select>
								</ModalBody>
								<ModalFooter>
									<Button isDisabled={!isValid} className={BtnColorStyle.primary} type="submit">
										Update
									</Button>
								</ModalFooter>
							</Form>
						)}
					</Formik>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default UpdateUserModal;

'use client';

import { JSX } from 'react';
import { Card, CardHeader, CardBody, Chip, Tooltip } from '@heroui/react';
import { GetFullUserResponseDto } from '@/services/user/dto/response/GetFullUser.response.dto';
import CreateUserLanguageModal from '@/app/(pages)/users/[userId]/modal/userLanguages/CreateUserLanguage.modal';
import ISO6391 from 'iso-639-1';
import { useDeleteUserLanguageMutation } from '@/hooks/user/user-language.hook';

interface UserPageLanguageProps {
	isOwner: boolean;
	user: GetFullUserResponseDto;
}

const UserPageLanguage = ({ isOwner, user }: UserPageLanguageProps): JSX.Element => {
	const deleteUserLanguage = useDeleteUserLanguageMutation(user.userId);

	const deleteUserLanguageHandler = async (userLanguageId: number) => {
		if (!isOwner) return;

		await deleteUserLanguage.mutateAsync(userLanguageId);
	};

	return (
		<Card className="card">
			<CardHeader className="flex flex-row justify-between">
				<span className="ml-4 text-xl font-medium">My languages</span>
				{isOwner ? <CreateUserLanguageModal user={user} /> : null}
			</CardHeader>
			<CardBody className="ml-4 pt-0">
				{user.languages.length ? (
					<div className="flex flex-row items-center gap-1">
						{user.languages.map((language) => (
							<Tooltip key={language.userLanguageId} content={isOwner ? 'Press to delete' : null}>
								<Chip
									className="cursor-pointer"
									color={language.isBasic ? 'primary' : 'default'}
									size="sm"
									onClick={() => deleteUserLanguageHandler(language.userLanguageId)}
								>
									{ISO6391.getName(language.language)} ({language.levelOfLanguage})
								</Chip>
							</Tooltip>
						))}
					</div>
				) : (
					<span className="text-sm text-foreground-400">There are no languages</span>
				)}
			</CardBody>
		</Card>
	);
};

export default UserPageLanguage;

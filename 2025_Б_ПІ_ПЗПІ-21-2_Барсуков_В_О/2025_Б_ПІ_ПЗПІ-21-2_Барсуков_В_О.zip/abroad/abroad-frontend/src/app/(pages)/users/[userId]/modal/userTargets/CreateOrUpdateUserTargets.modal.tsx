'use client';

import { Fragment, JSX } from 'react';
import { GetFullUserResponseDto } from '@/services/user/dto/response/GetFullUser.response.dto';
import {
	Button,
	Modal,
	ModalBody,
	ModalContent,
	ModalFooter,
	ModalHeader,
	Select,
	SelectItem,
	useDisclosure,
} from '@heroui/react';
import { CreateOrUpdateUserTargetRequestDto } from '@/services/user/user-target/dto/request/CreateOrUpdateUserTarget.request.dto';
import { Form, Formik, FormikHelpers } from 'formik';
import { IconEdit } from '@tabler/icons-react';
import { BtnColorStyle } from '@/constants/btn.constant';
import { Target } from '@/enum/Target.enum';
import { TARGET_TEXT_CONSTANT } from '@/constants/target.constant';
import { useCreateOrUpdateUserTargetsMutation } from '@/hooks/user/user-target.hook';

interface CreateOrUpdateUserTargetsModalProps {
	user: GetFullUserResponseDto;
}

const CreateOrUpdateUserTargets = ({ user }: CreateOrUpdateUserTargetsModalProps): JSX.Element => {
	const { isOpen, onOpen, onClose, onOpenChange } = useDisclosure();

	const createOrUpdateUserTargets = useCreateOrUpdateUserTargetsMutation(user.userId);

	const initialValues: CreateOrUpdateUserTargetRequestDto = {
		targets: user.targets.map((target) => target.target),
	};

	const submitHandler = async (
		values: CreateOrUpdateUserTargetRequestDto,
		{ resetForm }: FormikHelpers<CreateOrUpdateUserTargetRequestDto>,
	) => {
		await createOrUpdateUserTargets.mutateAsync(values);
		resetForm();
		onClose();
	};

	return (
		<Fragment>
			<Button isIconOnly startContent={<IconEdit size={18} />} size="sm" className={BtnColorStyle.primary} onPress={onOpen} />
			<Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="top" size="lg">
				<ModalContent>
					<Formik initialValues={initialValues} onSubmit={submitHandler}>
						{({ values, setFieldValue, handleSubmit }) => (
							<Form onSubmit={handleSubmit}>
								<ModalHeader>Targets</ModalHeader>
								<ModalBody>
									<Select
										selectionMode="multiple"
										label="Targets"
										variant="bordered"
										size="sm"
										defaultSelectedKeys={values.targets}
										onChange={(event) => setFieldValue('targets', event.target.value ? event.target.value.split(',') : [])}
									>
										<SelectItem key={Target.HELP}>{TARGET_TEXT_CONSTANT[Target.HELP]}</SelectItem>
										<SelectItem key={Target.LANGUAGE_EXCHANGE}>{TARGET_TEXT_CONSTANT[Target.LANGUAGE_EXCHANGE]}</SelectItem>
										<SelectItem key={Target.PART_IN_EVENT}>{TARGET_TEXT_CONSTANT[Target.PART_IN_EVENT]}</SelectItem>
										<SelectItem key={Target.ADAPTATION_TIPS}>{TARGET_TEXT_CONSTANT[Target.ADAPTATION_TIPS]}</SelectItem>
										<SelectItem key={Target.LEARN_SKILLS}>{TARGET_TEXT_CONSTANT[Target.LEARN_SKILLS]}</SelectItem>
										<SelectItem key={Target.FIND_JOB}>{TARGET_TEXT_CONSTANT[Target.FIND_JOB]}</SelectItem>
										<SelectItem key={Target.SHARE_EXPERIENCE}>{TARGET_TEXT_CONSTANT[Target.SHARE_EXPERIENCE]}</SelectItem>
										<SelectItem key={Target.NETWORKING}>{TARGET_TEXT_CONSTANT[Target.NETWORKING]}</SelectItem>
										<SelectItem key={Target.JOIN_COMMUNITY}>{TARGET_TEXT_CONSTANT[Target.JOIN_COMMUNITY]}</SelectItem>
										<SelectItem key={Target.MAKE_FRIENDS}>{TARGET_TEXT_CONSTANT[Target.MAKE_FRIENDS]}</SelectItem>
										<SelectItem key={Target.PARTICIPATE_IN_DISCUSSIONS}>
											{TARGET_TEXT_CONSTANT[Target.PARTICIPATE_IN_DISCUSSIONS]}
										</SelectItem>
										<SelectItem key={Target.FIND_MENTOR}>{TARGET_TEXT_CONSTANT[Target.FIND_MENTOR]}</SelectItem>
										<SelectItem key={Target.FIND_MOTIVATION}>{TARGET_TEXT_CONSTANT[Target.FIND_MOTIVATION]}</SelectItem>
										<SelectItem key={Target.SHARE_ACHIEVEMENTS}>{TARGET_TEXT_CONSTANT[Target.SHARE_ACHIEVEMENTS]}</SelectItem>
										<SelectItem key={Target.SEEK_ADVICE}>{TARGET_TEXT_CONSTANT[Target.SEEK_ADVICE]}</SelectItem>
										<SelectItem key={Target.STAY_CONNECTED}>{TARGET_TEXT_CONSTANT[Target.STAY_CONNECTED]}</SelectItem>
									</Select>
								</ModalBody>
								<ModalFooter>
									<Button className={BtnColorStyle.primary} type="submit">
										Confirm
									</Button>
								</ModalFooter>
							</Form>
						)}
					</Formik>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default CreateOrUpdateUserTargets;

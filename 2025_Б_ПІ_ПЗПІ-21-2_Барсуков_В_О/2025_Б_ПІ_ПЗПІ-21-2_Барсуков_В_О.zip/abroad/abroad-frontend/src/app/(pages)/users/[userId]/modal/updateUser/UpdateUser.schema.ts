import { mixed, object, string } from 'yup';
import { DEFAULT_STRING_MIN_LENGTH } from '@/constants/default-value.constant';
import { INPUT_DATA_IS_REQUIRED, INPUT_DATA_TOO_LONG, INPUT_DATA_TOO_SHORT } from '@/constants/error/input.error';
import { TypeOfGender } from '@/enum/TypeOfGender.enum';
import { StatusOfStay } from '@/enum/StatusOfStay.enum';
import { StatusOfUser } from '@/enum/StatusOfUser.enum';
import { StatusOfVisibility } from '@/enum/StatusOfVisibility.enum';

export const UpdateUserSchema = object().shape({
	name: string()
		.min(DEFAULT_STRING_MIN_LENGTH, INPUT_DATA_TOO_SHORT)
		.max(20, INPUT_DATA_TOO_LONG)
		.required(INPUT_DATA_IS_REQUIRED),
	surname: string()
		.min(DEFAULT_STRING_MIN_LENGTH, INPUT_DATA_TOO_SHORT)
		.max(20, INPUT_DATA_TOO_LONG)
		.required(INPUT_DATA_IS_REQUIRED),
	gender: mixed<TypeOfGender>().required(INPUT_DATA_IS_REQUIRED),
	email: string().min(DEFAULT_STRING_MIN_LENGTH).max(50, INPUT_DATA_TOO_LONG).required(INPUT_DATA_IS_REQUIRED),
	dateOfBirth: string().required(INPUT_DATA_IS_REQUIRED),
	county: string(),
	city: string().required(INPUT_DATA_IS_REQUIRED),
	goalOfUser: string().min(DEFAULT_STRING_MIN_LENGTH, INPUT_DATA_TOO_SHORT).max(300, INPUT_DATA_TOO_LONG).nullable(),
	dateOfArrival: string().nullable(),
	statusOfStay: mixed<StatusOfStay>().nullable(),
	statusOfUser: mixed<StatusOfUser>().nullable(),
	statusOfVisibility: mixed<StatusOfVisibility>(),
});

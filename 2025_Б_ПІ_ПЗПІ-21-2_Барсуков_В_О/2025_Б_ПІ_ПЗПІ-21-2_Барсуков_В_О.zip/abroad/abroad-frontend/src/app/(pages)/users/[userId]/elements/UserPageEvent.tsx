'use client';

import { JSX } from 'react';
import { Button, Card, CardBody, CardHeader, Chip } from '@heroui/react';
import Link from 'next/link';
import { IconEdit, IconTrash } from '@tabler/icons-react';
import { BtnColorStyle } from '@/constants/btn.constant';
import { GetFullUserResponseDto } from '@/services/user/dto/response/GetFullUser.response.dto';
import { ROUTES } from '@/routes/routes';
import { TARGET_TEXT_CONSTANT } from '@/constants/target.constant';

interface UserPageEventProps {
	user: GetFullUserResponseDto;
}

const UserPageEvent = ({ user }: UserPageEventProps): JSX.Element => {
	return (
		<Card className="card event-list-max-height">
			<CardHeader className="flex flex-row justify-between">
				<span className="ml-4 text-xl font-medium">My events</span>
			</CardHeader>
			<CardBody className="ml-4 pt-0 w-full h-full">
				{user.authorEvents.length ? (
					user.authorEvents.map((event) => (
						<div key={event.eventId} className="flex flex-col gap-2 w-full h-full">
							<Card className="double-card" as={Link} href={ROUTES.EVENTS + '/' + event.eventId} style={{ width: '95%' }}>
								<CardHeader>
									<div className="flex flex-col gap-1 w-full ml-4">
										<div className="flex flex-row justify-between">
											<span className="text-xl font-medium">{event.nameOfEvent}</span>
										</div>
										<div className="flex flex-col">
											<span>
												Date time: {event.dateOfEvent.split('T')[0]}, {event.timeStart} - {event.timeEnd}
											</span>
											<span>
												Location: {event.country}, {event.city}, {event.address}
											</span>
										</div>
										{event.targets.length ? (
											<div className="flex flex-row items-center gap-1">
												{event.targets.map((target) => (
													<Chip key={target.eventTargetId} size="sm">
														{TARGET_TEXT_CONSTANT[target.target]}
													</Chip>
												))}
											</div>
										) : null}
									</div>
								</CardHeader>
							</Card>
						</div>
					))
				) : (
					<span className="text-sm text-foreground-400">There are no events</span>
				)}
			</CardBody>
		</Card>
	);
};

export default UserPageEvent;

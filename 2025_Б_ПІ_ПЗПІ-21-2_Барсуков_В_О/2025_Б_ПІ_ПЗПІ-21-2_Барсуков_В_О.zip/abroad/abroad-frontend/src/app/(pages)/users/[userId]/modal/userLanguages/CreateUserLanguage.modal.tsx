'use client';

import { Fragment, JSX } from 'react';
import { GetFullUserResponseDto } from '@/services/user/dto/response/GetFullUser.response.dto';
import {
	Autocomplete,
	AutocompleteItem,
	Button,
	Checkbox,
	Modal,
	ModalBody,
	ModalContent,
	ModalFooter,
	ModalHeader,
	Select,
	SelectItem,
	useDisclosure,
} from '@heroui/react';
import { useCreateUserLanguageMutation } from '@/hooks/user/user-language.hook';
import { CreateUserLanguageRequestDto } from '@/services/user/user-language/dto/request/CreateUserLanguage.request.dto';
import { LevelOfLanguage } from '@/enum/LevelOfLanguage.enum';
import { Form, Formik, FormikHelpers } from 'formik';
import { IconPlus } from '@tabler/icons-react';
import { BtnColorStyle } from '@/constants/btn.constant';
import { CreateUserLanguageSchema } from '@/app/(pages)/users/[userId]/modal/userLanguages/CreateUserLanguage.schema';
import ISO6391 from 'iso-639-1';

interface CreateUserLanguageModalProps {
	user: GetFullUserResponseDto;
}

const CreateUserLanguageModal = ({ user }: CreateUserLanguageModalProps): JSX.Element => {
	const { isOpen, onOpen, onClose, onOpenChange } = useDisclosure();

	const createUserLanguage = useCreateUserLanguageMutation(user.userId);

	const initialValues: CreateUserLanguageRequestDto = {
		language: '',
		levelOfLanguage: LevelOfLanguage.A1,
		isBasic: false,
	};

	const submitHandler = async (
		values: CreateUserLanguageRequestDto,
		{ resetForm }: FormikHelpers<CreateUserLanguageRequestDto>,
	) => {
		await createUserLanguage.mutateAsync(values);
		resetForm();
		onClose();
	};

	return (
		<Fragment>
			<Button isIconOnly startContent={<IconPlus size={18} />} size="sm" className={BtnColorStyle.primary} onPress={onOpen} />
			<Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="top" size="lg">
				<ModalContent>
					<Formik initialValues={initialValues} onSubmit={submitHandler} validationSchema={CreateUserLanguageSchema}>
						{({ values, setFieldValue, handleSubmit, isValid }) => (
							<Form onSubmit={handleSubmit}>
								<ModalHeader>Language</ModalHeader>
								<ModalBody>
									<Autocomplete
										isRequired
										disallowEmptySelection
										label="Language"
										variant="bordered"
										size="sm"
										onSelectionChange={(key) => setFieldValue('language', key)}
									>
										{ISO6391.getAllCodes().map((code) => (
											<AutocompleteItem key={code}>{ISO6391.getName(code)}</AutocompleteItem>
										))}
									</Autocomplete>
									<Select
										isRequired
										disallowEmptySelection
										label="Level of language"
										variant="bordered"
										size="sm"
										onChange={(event) => setFieldValue('levelOfLanguage', event.target.value)}
									>
										<SelectItem key={LevelOfLanguage.NATIVE}>Native</SelectItem>
										<SelectItem key={LevelOfLanguage.A1}>A1</SelectItem>
										<SelectItem key={LevelOfLanguage.A2}>A2</SelectItem>
										<SelectItem key={LevelOfLanguage.B1}>B1</SelectItem>
										<SelectItem key={LevelOfLanguage.B2}>B2</SelectItem>
										<SelectItem key={LevelOfLanguage.C1}>C1</SelectItem>
										<SelectItem key={LevelOfLanguage.C2}>C2</SelectItem>
									</Select>
									<Checkbox onValueChange={(value) => setFieldValue('isBasic', value)}>The language is basic</Checkbox>
								</ModalBody>
								<ModalFooter>
									<Button isDisabled={!isValid} className={BtnColorStyle.primary} type="submit">
										Create
									</Button>
								</ModalFooter>
							</Form>
						)}
					</Formik>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default CreateUserLanguageModal;

'use client';

import { JSX } from 'react';
import { Card, CardHeader, CardBody, Chip } from '@heroui/react';
import { GetFullUserResponseDto } from '@/services/user/dto/response/GetFullUser.response.dto';
import CreateOrUpdateUserTargetsModal from '@/app/(pages)/users/[userId]/modal/userTargets/CreateOrUpdateUserTargets.modal';
import { TARGET_TEXT_CONSTANT } from '@/constants/target.constant';

interface UserPageTargetProps {
	isOwner: boolean;
	user: GetFullUserResponseDto;
}

const UserPageTarget = ({ isOwner, user }: UserPageTargetProps): JSX.Element => {
	return (
		<Card className="card">
			<CardHeader className="flex flex-row justify-between">
				<span className="ml-4 text-xl font-medium">My targets</span>
				{isOwner ? <CreateOrUpdateUserTargetsModal user={user} /> : null}
			</CardHeader>
			<CardBody className="ml-4 pt-0">
				{user.targets.length ? (
					<div className="flex flex-row items-center gap-1">
						{user.targets.map((target) => (
							<Chip key={target.userTargetId} size="sm">
								{TARGET_TEXT_CONSTANT[target.target]}
							</Chip>
						))}
					</div>
				) : (
					<span className="text-sm text-foreground-400">There are no targets</span>
				)}
			</CardBody>
		</Card>
	);
};

export default UserPageTarget;

'use client';

import { JSX, ReactNode } from 'react';
import Menu from '@/components/elements/menu/Menu';

const PageLayout = ({ children }: { children: ReactNode }): JSX.Element => {
	return (
		<div className="flex flex-row min-h-screen w-screen overflow-hidden">
			<div className="flex flex-row gap-4 p-4 w-full h-full">
				<Menu />
				<div className="pl-4 pr-4 pb-4 w-full h-full select-none">{children}</div>
			</div>
		</div>
	);
};

export default PageLayout;

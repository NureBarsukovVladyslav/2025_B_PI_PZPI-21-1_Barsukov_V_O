'use client';

import { JSX } from 'react';
import { Autocomplete, Button, Card, CardBody, CardHeader, DatePicker, Input, User } from '@heroui/react';
import Link from 'next/link';
import { ROUTES } from '@/routes/routes';
import { BtnColorStyle } from '@/constants/btn.constant';
import {
	useAcceptFriendRequestMutation,
	useGetFriendsQuery,
	useGetFriendsRequestQuery,
	useRejectFriendRequestMutation,
} from '@/hooks/user/user-friend.hook';
import UserPageChat from "@/app/(pages)/users/[userId]/elements/UserPageChat";

const MyFriends = (): JSX.Element => {
	const friends = useGetFriendsQuery().data?.data || [];
	const friendRequests = useGetFriendsRequestQuery().data?.data || [];
	const acceptFriendRequest = useAcceptFriendRequestMutation();
	const rejectFriendRequest = useRejectFriendRequestMutation();

	const acceptFriendRequestHandler = async (friendId: number) => {
		await acceptFriendRequest.mutateAsync(friendId);
	};

	const rejectFriendRequestHandler = async (friendId: number) => {
		await rejectFriendRequest.mutateAsync(friendId);
	};

	return (
		<div className="flex flex-row gap-4 w-full h-full">
			<Card className="card list-max-height w-full">
				<CardHeader>
					<span className="ml-4 text-xl font-medium">My Friends</span>
				</CardHeader>
				<CardBody className="pt-0 px-6">
					{friends.length ? (
						<div className="flex flex-col items-start gap-4 w-full">
							{friends.map((friend) => (
								<div key={friend.userId} className="flex flex-row items-center justify-between w-full">
									<User
										name={`${friend.name} ${friend.surname}`}
										avatarProps={{ size: 'lg' }}
										as={Link}
										href={ROUTES.USERS + '/' + friend.userId}
									/>
									<UserPageChat user={friend} />
								</div>
							))}
						</div>
					) : (
						<span className="flex flex-1 items-center justify-center text-base text-foreground-400 w-full h-full">
							You don&apos;t have friends
						</span>
					)}
				</CardBody>
			</Card>
			<div className="list-max-height flex flex-col gap-4 w-full" style={{ flex: '1 1 50%' }}>
				<Card className="card h-full">
					<Card className="card h-full">
						<CardHeader>
							<span className="ml-4 text-xl font-medium">Requests</span>
						</CardHeader>
						<CardBody className="pt-0 px-6">
							{friendRequests.length ? (
								<div className="flex flex-col items-start gap-4 w-full">
									{friendRequests.map((friendRequest) => (
										<div key={friendRequest.userId} className="flex flex-row items-center justify-between w-full">
											<User
												name={`${friendRequest.name} ${friendRequest.surname}`}
												avatarProps={{ size: 'lg' }}
												as={Link}
												href={ROUTES.USERS + '/' + friendRequest.userId}
											/>
											<div className="flex flex-row gap-2">
												<Button
													className={BtnColorStyle.primary}
													size="sm"
													onPress={() => acceptFriendRequestHandler(friendRequest.userId)}
												>
													Accept
												</Button>
												<Button
													className={BtnColorStyle.danger}
													size="sm"
													onPress={() => rejectFriendRequestHandler(friendRequest.userId)}
												>
													Reject
												</Button>
											</div>
										</div>
									))}
								</div>
							) : (
								<span className="flex flex-1 items-center justify-center text-base text-foreground-400 w-full h-full">
									You do not have requests in friends
								</span>
							)}
						</CardBody>
					</Card>
				</Card>
			</div>
		</div>
	);
};

export default MyFriends;

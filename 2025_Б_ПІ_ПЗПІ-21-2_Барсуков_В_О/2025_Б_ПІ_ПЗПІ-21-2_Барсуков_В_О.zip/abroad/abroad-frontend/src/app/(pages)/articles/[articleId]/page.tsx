'use client';

import '../../../../styles/pages/article.css';

import { Fragment, JSX } from 'react';
import { Button, Card, CardBody, CardHeader } from '@heroui/react';
import { BtnColorStyle } from '@/constants/btn.constant';
import { useDeleteArticleMutation, useGetArticleQuery } from '@/hooks/article.hook';
import Link from 'next/link';
import UpdateArticleModal from '@/app/(pages)/articles/modal/UpdateArticle.modal';

interface ArticlePageProps {
	params: {
		articleId: string;
	};
}

const ArticlePage = ({ params }: ArticlePageProps): JSX.Element => {
	const articleId = Number(params.articleId);
	const article = useGetArticleQuery(articleId).data?.data || null;
	const deleteArticle = useDeleteArticleMutation(articleId);

	if (!article) return <></>;

	const renderDateTime = (dateTime: string): string => {
		const [date, time] = dateTime.split('T');

		return `${date} ${time.slice(0, 5)}`;
	};

	const deleteArticleHandler = async () => {
		if (!article.isOwner) return;

		await deleteArticle.mutateAsync(articleId);
	};

	return (
		<div className="flex flex-col items-center justify-center gap-4 w-full h-full">
			<Card className="card w-full h-full">
				<CardHeader className="px-6">
					<div className="flex flex-row items-center justify-between w-full h-full">
						<div className="flex flex-row items-center gap-4">
							<div className="flex flex-col items-start gap-1">
								<span className="text-2xl font-medium leading-none">{article.nameOfArticle}</span>
								<span className="text-base">{article.description}</span>
								<div className="flex flex-col items-start">
									<span className="text-sm">
										Author: {article.author.name} {article.author.surname} {article.email ? `(${article.email})` : null}
									</span>
									<span className="text-sm">Created At: {renderDateTime(article.createdAt)}</span>
								</div>
							</div>
						</div>
						<div className="flex flex-col gap-2">
							{article.isOwner ? (
								<Fragment>
									<UpdateArticleModal article={article} />
									<Button size="sm" className={BtnColorStyle.danger} onPress={deleteArticleHandler}>
										Delete article
									</Button>
								</Fragment>
							) : null}
							{article.link ? (
								<Button className={BtnColorStyle.primary} size="sm" as={Link} href={article.link}>
									{article.nameOfLink || 'Resource'}
								</Button>
							) : null}
						</div>
					</div>
				</CardHeader>
			</Card>
			<Card className="card w-full h-full">
				<CardBody className="flex flex-col gap-4">
					<span className="article-content text-sm whitespace-break-spaces">{article.content}</span>
				</CardBody>
			</Card>
		</div>
	);
};

export default ArticlePage;

'use client';

import { Fragment, JSX } from 'react';
import {
	Button,
	Modal,
	ModalBody,
	ModalContent,
	ModalFooter,
	ModalHeader,
	Select,
	SelectItem,
	Textarea,
	useDisclosure,
} from '@heroui/react';
import { useCreateArticleMutation, useUpdateArticleMutation } from '@/hooks/article.hook';
import { CreateOrUpdateArticleRequestDto } from '@/services/article/dto/request/CreateOrUpdateArticle.request.dto';
import { StatusOfUser } from '@/enum/StatusOfUser.enum';
import { Target } from '@/enum/Target.enum';
import { Form, Formik, FormikHelpers } from 'formik';
import { IconPlus } from '@tabler/icons-react';
import { BtnColorStyle } from '@/constants/btn.constant';
import { CreateOrUpdateArticleSchema } from '@/app/(pages)/articles/modal/CreateOrUpdateArticle.schema';
import { Input } from '@heroui/input';
import { STATUS_OF_USER_TEXT_CONSTANT } from '@/constants/statusOfUser.constant';
import { TARGET_TEXT_CONSTANT } from '@/constants/target.constant';
import { GetFullArticleResponseDto } from '@/services/article/dto/response/GetFullArticle.response.dto';

interface UpdateArticleModalProps {
	article: GetFullArticleResponseDto;
}

const UpdateArticleModal = ({ article }: UpdateArticleModalProps): JSX.Element => {
	const { isOpen, onOpen, onClose, onOpenChange } = useDisclosure();

	const updateArticle = useUpdateArticleMutation(article.articleId);

	const initialValues: CreateOrUpdateArticleRequestDto = {
		nameOfArticle: article.nameOfArticle || '',
		description: article.description || '',
		content: article.content || '',
		email: article.email || null,
		link: article.link || null,
		nameOfLink: article.nameOfLink || null,
		statusOfUser: article.statusOfUser || StatusOfUser.PARTY,
		target: article.target || Target.HELP,
	};

	const submitHandler = async (
		values: CreateOrUpdateArticleRequestDto,
		{ resetForm }: FormikHelpers<CreateOrUpdateArticleRequestDto>,
	) => {
		await updateArticle.mutateAsync(values);
		resetForm();
		onClose();
	};

	return (
		<Fragment>
			<Button size="sm" className={BtnColorStyle.primary} onPress={onOpen}>
				Update article
			</Button>
			<Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="top" size="lg">
				<ModalContent>
					<Formik initialValues={initialValues} onSubmit={submitHandler} validationSchema={CreateOrUpdateArticleSchema}>
						{({ values, errors, setFieldValue, handleSubmit, isValid }) => (
							<Form onSubmit={handleSubmit}>
								<ModalHeader>Update article</ModalHeader>
								<ModalBody>
									<Input
										isRequired
										label="Name of article"
										variant="bordered"
										size="sm"
										value={values.nameOfArticle}
										onValueChange={(value) => setFieldValue('nameOfArticle', value)}
										isInvalid={!!errors.nameOfArticle}
										errorMessage={errors.nameOfArticle as string}
									/>
									<Textarea
										isRequired
										label="Description"
										variant="bordered"
										size="sm"
										minRows={1}
										value={values.description}
										onValueChange={(value) => setFieldValue('description', value)}
										isInvalid={!!errors.description}
										errorMessage={errors.description as string}
									/>
									<Textarea
										isRequired
										label="Content"
										variant="bordered"
										size="sm"
										minRows={5}
										value={values.content}
										onValueChange={(value) => setFieldValue('content', value)}
										isInvalid={!!errors.content}
										errorMessage={errors.content as string}
									/>
									<Input
										type="email"
										label="Email"
										variant="bordered"
										size="sm"
										value={values.email || ''}
										onValueChange={(value) => setFieldValue('email', value || null)}
										isInvalid={!!errors.email}
										errorMessage={errors.email as string}
									/>
									<Input
										label="Link"
										variant="bordered"
										size="sm"
										value={values.link || ''}
										onValueChange={(value) => setFieldValue('link', value || null)}
										isInvalid={!!errors.link}
										errorMessage={errors.link as string}
									/>
									<Input
										label="Name of link"
										variant="bordered"
										size="sm"
										value={values.nameOfLink || ''}
										onValueChange={(value) => setFieldValue('nameOfLink', value || null)}
										isInvalid={!!errors.nameOfLink}
										errorMessage={errors.nameOfLink as string}
									/>
									<Select
										isRequired
										disallowEmptySelection
										label="Status of user"
										variant="bordered"
										size="sm"
										defaultSelectedKeys={[values.statusOfUser]}
										onChange={(event) => setFieldValue('statusOfUser', event.target.value)}
									>
										<SelectItem key={StatusOfUser.LONELY}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.LONELY]}</SelectItem>
										<SelectItem key={StatusOfUser.STRESS}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.STRESS]}</SelectItem>
										<SelectItem key={StatusOfUser.STUDY}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.STUDY]}</SelectItem>
										<SelectItem key={StatusOfUser.WALK}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.WALK]}</SelectItem>
										<SelectItem key={StatusOfUser.SURPRISE}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.SURPRISE]}</SelectItem>
										<SelectItem key={StatusOfUser.ENJOY}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.ENJOY]}</SelectItem>
										<SelectItem key={StatusOfUser.WORKING}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.WORKING]}</SelectItem>
										<SelectItem key={StatusOfUser.EXPLORING}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.EXPLORING]}</SelectItem>
										<SelectItem key={StatusOfUser.RELAXING}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.RELAXING]}</SelectItem>
										<SelectItem key={StatusOfUser.HOMESICK}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.HOMESICK]}</SelectItem>
										<SelectItem key={StatusOfUser.PARTY}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.PARTY]}</SelectItem>
										<SelectItem key={StatusOfUser.LOST}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.LOST]}</SelectItem>
										<SelectItem key={StatusOfUser.NETWORKING}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.NETWORKING]}</SelectItem>
										<SelectItem key={StatusOfUser.ADVENTURE}>{STATUS_OF_USER_TEXT_CONSTANT[StatusOfUser.ADVENTURE]}</SelectItem>
									</Select>
									<Select
										isRequired
										disallowEmptySelection
										label="Target"
										variant="bordered"
										size="sm"
										defaultSelectedKeys={[values.target]}
										onChange={(event) => setFieldValue('target', event.target.value)}
									>
										<SelectItem key={Target.HELP}>{TARGET_TEXT_CONSTANT[Target.HELP]}</SelectItem>
										<SelectItem key={Target.LANGUAGE_EXCHANGE}>{TARGET_TEXT_CONSTANT[Target.LANGUAGE_EXCHANGE]}</SelectItem>
										<SelectItem key={Target.PART_IN_EVENT}>{TARGET_TEXT_CONSTANT[Target.PART_IN_EVENT]}</SelectItem>
										<SelectItem key={Target.ADAPTATION_TIPS}>{TARGET_TEXT_CONSTANT[Target.ADAPTATION_TIPS]}</SelectItem>
										<SelectItem key={Target.LEARN_SKILLS}>{TARGET_TEXT_CONSTANT[Target.LEARN_SKILLS]}</SelectItem>
										<SelectItem key={Target.FIND_JOB}>{TARGET_TEXT_CONSTANT[Target.FIND_JOB]}</SelectItem>
										<SelectItem key={Target.SHARE_EXPERIENCE}>{TARGET_TEXT_CONSTANT[Target.SHARE_EXPERIENCE]}</SelectItem>
										<SelectItem key={Target.NETWORKING}>{TARGET_TEXT_CONSTANT[Target.NETWORKING]}</SelectItem>
										<SelectItem key={Target.JOIN_COMMUNITY}>{TARGET_TEXT_CONSTANT[Target.JOIN_COMMUNITY]}</SelectItem>
										<SelectItem key={Target.MAKE_FRIENDS}>{TARGET_TEXT_CONSTANT[Target.MAKE_FRIENDS]}</SelectItem>
										<SelectItem key={Target.PARTICIPATE_IN_DISCUSSIONS}>
											{TARGET_TEXT_CONSTANT[Target.PARTICIPATE_IN_DISCUSSIONS]}
										</SelectItem>
										<SelectItem key={Target.FIND_MENTOR}>{TARGET_TEXT_CONSTANT[Target.FIND_MENTOR]}</SelectItem>
										<SelectItem key={Target.FIND_MOTIVATION}>{TARGET_TEXT_CONSTANT[Target.FIND_MOTIVATION]}</SelectItem>
										<SelectItem key={Target.SHARE_ACHIEVEMENTS}>{TARGET_TEXT_CONSTANT[Target.SHARE_ACHIEVEMENTS]}</SelectItem>
										<SelectItem key={Target.SEEK_ADVICE}>{TARGET_TEXT_CONSTANT[Target.SEEK_ADVICE]}</SelectItem>
										<SelectItem key={Target.STAY_CONNECTED}>{TARGET_TEXT_CONSTANT[Target.STAY_CONNECTED]}</SelectItem>
									</Select>
								</ModalBody>
								<ModalFooter>
									<Button isDisabled={!isValid} className={BtnColorStyle.primary} type="submit">
										Update
									</Button>
								</ModalFooter>
							</Form>
						)}
					</Formik>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default UpdateArticleModal;

'use client';

import { JSX } from 'react';
import { Card, CardBody, CardHeader, Chip } from '@heroui/react';
import Link from 'next/link';
import { ROUTES } from '@/routes/routes';
import { useGetArticlesQuery } from '@/hooks/article.hook';
import { STATUS_OF_USER_TEXT_CONSTANT } from '@/constants/statusOfUser.constant';
import { TARGET_TEXT_CONSTANT } from '@/constants/target.constant';
import CreateArticleModal from '@/app/(pages)/articles/modal/CreateArticle.modal';

const Articles = (): JSX.Element => {
	const articles = useGetArticlesQuery().data?.data || [];

	return (
		<div className="w-full h-full">
			<Card className="card w-full list-max-height">
				<CardHeader className="flex flex-row justify-between">
					<span className="ml-4 text-xl font-medium">Articles</span>
					<CreateArticleModal />
				</CardHeader>
				<CardBody className="h-full w-full">
					{articles.length ? (
						<div className="flex flex-col gap-4 pt-0 px-6">
							{articles.map((article) => (
								<Card
									key={article.articleId}
									className="double-card shrink-0"
									as={Link}
									href={ROUTES.ARTICLES + '/' + article.articleId}
								>
									<CardHeader>
										<div className="flex flex-col gap-4 w-full ml-4">
											<div className="flex flex-col items-start">
												<span className="text-xl font-medium leading-none">{article.nameOfArticle}</span>
												<span className="text-base">{article.description}</span>
											</div>
											<div className="flex flex-row items-center justify-between">
												<div className="flex flex-row items-center gap-2">
													<Chip size="sm" color="primary">
														{STATUS_OF_USER_TEXT_CONSTANT[article.statusOfUser]}
													</Chip>
													<Chip size="sm" color="secondary">
														{TARGET_TEXT_CONSTANT[article.target]}
													</Chip>
												</div>
												<span className="font-medium">
													{article.author.name} {article.author.surname}
												</span>
											</div>
										</div>
									</CardHeader>
								</Card>
							))}
						</div>
					) : (
						<span className="flex flex-1 items-center justify-center text-base text-foreground-400 w-full h-full">
							There are no articles
						</span>
					)}
				</CardBody>
			</Card>
		</div>
	);
};

export default Articles;

import { mixed, object, string } from 'yup';
import { DEFAULT_STRING_MIN_LENGTH } from '@/constants/default-value.constant';
import { INPUT_DATA_IS_REQUIRED, INPUT_DATA_TOO_LONG, INPUT_DATA_TOO_SHORT } from '@/constants/error/input.error';
import { StatusOfUser } from '@/enum/StatusOfUser.enum';
import { Target } from '@/enum/Target.enum';

export const CreateOrUpdateArticleSchema = object().shape({
	nameOfArticle: string()
		.min(DEFAULT_STRING_MIN_LENGTH, INPUT_DATA_TOO_SHORT)
		.max(150, INPUT_DATA_TOO_LONG)
		.required(INPUT_DATA_IS_REQUIRED),
	description: string()
		.min(DEFAULT_STRING_MIN_LENGTH, INPUT_DATA_TOO_SHORT)
		.max(500, INPUT_DATA_TOO_LONG)
		.required(INPUT_DATA_IS_REQUIRED),
	content: string().min(100, INPUT_DATA_TOO_SHORT).max(3000, INPUT_DATA_TOO_LONG).required(INPUT_DATA_IS_REQUIRED),
	email: string().min(DEFAULT_STRING_MIN_LENGTH, INPUT_DATA_TOO_SHORT).max(50, INPUT_DATA_TOO_LONG).nullable(),
	link: string().min(DEFAULT_STRING_MIN_LENGTH, INPUT_DATA_TOO_SHORT).nullable(),
	nameOfLink: string().min(DEFAULT_STRING_MIN_LENGTH, INPUT_DATA_TOO_SHORT).max(50, INPUT_DATA_TOO_LONG).nullable(),
	statusOfUser: mixed<StatusOfUser>().required(INPUT_DATA_IS_REQUIRED),
	target: mixed<Target>().required(INPUT_DATA_IS_REQUIRED),
});

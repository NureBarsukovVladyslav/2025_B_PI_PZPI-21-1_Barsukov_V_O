'use client';

import { JSX } from 'react';
import { Card, CardHeader, CardBody } from '@heroui/react';
import { GetFullEventResponseDto } from '@/services/event/dto/response/GetFullEvent.response.dto';

interface EventPageDescriptionProps {
	event: GetFullEventResponseDto;
}

const EventPageDescription = ({ event }: EventPageDescriptionProps): JSX.Element => {
	return (
		<Card className="card">
			<CardHeader className="flex flex-row justify-between">
				<span className="ml-4 text-xl font-medium">Description</span>
			</CardHeader>
			<CardBody className="mx-4 pt-0">
				<span className="whitespace-break-spaces">{event.description}</span>
			</CardBody>
		</Card>
	);
};

export default EventPageDescription;

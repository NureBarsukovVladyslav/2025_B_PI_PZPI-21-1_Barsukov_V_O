'use client';

import { Fragment, JSX, useState } from 'react';
import {
	AccordionItem,
	Autocomplete,
	Button,
	DatePicker,
	Modal,
	ModalBody,
	ModalContent,
	ModalFooter,
	ModalHeader,
	Textarea,
	TimeInput,
	useDisclosure,
} from '@heroui/react';
import { useUpdateEventMutation } from '@/hooks/event/event.hook';
import { CreateOrUpdateEventRequestDto } from '@/services/event/dto/request/CreateOrUpdateEvent.request.dto';
import { Form, Formik, FormikHelpers } from 'formik';
import { BtnColorStyle } from '@/constants/btn.constant';
import { CreateOrUpdateEventSchema } from '@/app/(pages)/events/modal/CreateOrUpdateEvent.schema';
import { Input } from '@heroui/input';
import InputGroup from '@/components/elements/input/InputGroup';
import { City, Country } from 'country-state-city';
import { GetFullEventResponseDto } from '@/services/event/dto/response/GetFullEvent.response.dto';
import { parseDate, Time } from '@internationalized/date';

interface UpdateEventModalProps {
	event: GetFullEventResponseDto;
}

const UpdateEventModal = ({ event }: UpdateEventModalProps): JSX.Element => {
	const [chooseCounty, setChooseCountry] = useState<string | null>(null);

	const { isOpen, onOpen, onClose, onOpenChange } = useDisclosure();

	const updateEvent = useUpdateEventMutation(event.eventId);

	const initialValues: CreateOrUpdateEventRequestDto = {
		nameOfEvent: event.nameOfEvent || '',
		description: event.description || '',
		dateOfEvent: event.dateOfEvent || '',
		timeStart: event.timeStart || '',
		timeEnd: event.timeEnd || '',
		country: event.country || '',
		city: event.city || '',
		address: event.address || '',
	};

	const submitHandler = async (
		values: CreateOrUpdateEventRequestDto,
		{ resetForm }: FormikHelpers<CreateOrUpdateEventRequestDto>,
	) => {
		await updateEvent.mutateAsync(values);
		resetForm();
		onClose();
	};

	return (
		<Fragment>
			<Button size="sm" className={BtnColorStyle.primary} onPress={onOpen}>
				Update event
			</Button>
			<Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="top" size="lg">
				<ModalContent>
					<Formik initialValues={initialValues} onSubmit={submitHandler} validationSchema={CreateOrUpdateEventSchema}>
						{({ values, errors, setFieldValue, handleSubmit, isValid }) => (
							<Form onSubmit={handleSubmit}>
								<ModalHeader>Update event</ModalHeader>
								<ModalBody>
									<Input
										isRequired
										label="Name of event"
										variant="bordered"
										size="sm"
										value={values.nameOfEvent}
										onValueChange={(value) => setFieldValue('nameOfEvent', value)}
										isInvalid={!!errors.nameOfEvent}
										errorMessage={errors.nameOfEvent as string}
									/>
									<Textarea
										isRequired
										label="Description"
										variant="bordered"
										size="sm"
										minRows={1}
										value={values.description}
										onValueChange={(value) => setFieldValue('description', value)}
										isInvalid={!!errors.description}
										errorMessage={errors.description as string}
									/>
									<DatePicker
										isRequired
										showMonthAndYearPickers
										label="Date of event"
										variant="bordered"
										size="sm"
										value={values.dateOfEvent ? parseDate(values.dateOfEvent.split('T')[0]) : null}
										onChange={(value) => setFieldValue('dateOfEvent', value ? `${value.toString()}T00:00:00Z` : null)}
										isInvalid={!!errors.dateOfEvent}
										errorMessage={errors.dateOfEvent as string}
									/>
									<InputGroup>
										<TimeInput
											isRequired
											hourCycle={24}
											label="Time start"
											variant="bordered"
											size="sm"
											value={
												values.timeStart
													? new Time(Number(values.timeStart?.split(':')[0]), Number(values.timeStart?.split(':')[1]))
													: null
											}
											onChange={(value) => setFieldValue('timeStart', value ? value.toString().slice(0, 5) : null)}
											isInvalid={!!errors.timeStart}
											errorMessage={errors.timeStart as string}
										/>
										<TimeInput
											isRequired
											hourCycle={24}
											label="Time end"
											variant="bordered"
											size="sm"
											value={
												values.timeEnd
													? new Time(Number(values.timeEnd?.split(':')[0]), Number(values.timeEnd?.split(':')[1]))
													: null
											}
											onChange={(value) => setFieldValue('timeEnd', value ? value.toString().slice(0, 5) : null)}
											isInvalid={!!errors.timeEnd}
											errorMessage={errors.timeEnd as string}
										/>
									</InputGroup>
									<Autocomplete
										isRequired
										disallowEmptySelection
										label="Contry"
										variant="bordered"
										size="sm"
										defaultInputValue={values.country}
										onSelectionChange={(key) => {
											setChooseCountry(key as string);
											setFieldValue('country', Country.getCountryByCode(key as string)?.name || '');
										}}
										defaultItems={Country.getAllCountries()}
									>
										{(item) => <AccordionItem key={item.isoCode}>{item.name}</AccordionItem>}
									</Autocomplete>
									<Autocomplete
										isDisabled={!chooseCounty}
										isRequired
										disallowEmptySelection
										label="City"
										variant="bordered"
										size="sm"
										defaultInputValue={values.city}
										onSelectionChange={(key) => setFieldValue('city', key)}
										defaultItems={chooseCounty ? City.getCitiesOfCountry(chooseCounty) : []}
									>
										{(item) => <AccordionItem key={item.name}>{item.name}</AccordionItem>}
									</Autocomplete>
									<Input
										isRequired
										label="Address"
										variant="bordered"
										size="sm"
										value={values.address}
										onValueChange={(value) => setFieldValue('address', value)}
										isInvalid={!!errors.address}
										errorMessage={errors.address as string}
									/>
								</ModalBody>
								<ModalFooter>
									<Button isDisabled={!isValid} className={BtnColorStyle.primary} type="submit">
										Update
									</Button>
								</ModalFooter>
							</Form>
						)}
					</Formik>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default UpdateEventModal;

'use client';

import { JSX } from 'react';
import EventPageHeader from '@/app/(pages)/events/[eventId]/elements/EventPageHeader';
import EventPageDescription from '@/app/(pages)/events/[eventId]/elements/EventPageDescription';
import EventPageTarget from '@/app/(pages)/events/[eventId]/elements/EventPageTarget';
import EventPageAuthor from '@/app/(pages)/events/[eventId]/elements/EventPageAuthor';
import EventPageParticipant from '@/app/(pages)/events/[eventId]/elements/EventPageParticipant';
import EventPageGroup from '@/app/(pages)/events/[eventId]/elements/EventPageGroup';
import { useGetEventQuery } from '@/hooks/event/event.hook';

interface EventPageProps {
	params: {
		eventId: string;
	};
}

const EventPage = ({ params }: EventPageProps): JSX.Element => {
	const eventId = Number(params.eventId);
	const event = useGetEventQuery(eventId).data?.data || null;

	if (!event) return <></>;

	return (
		<div className="flex flex-col gap-4 w-full h-full">
			<EventPageHeader event={event} />
			<div className="flex flex-row gap-4 w-full h-full">
				<div className="flex flex-col gap-4 w-full h-full">
					<EventPageDescription event={event} />
					<EventPageTarget event={event} />
				</div>
				<div className="flex flex-col gap-4 w-full h-full" style={{ flex: '1 2 auto' }}>
					<EventPageAuthor event={event} />
					<EventPageParticipant event={event} />
					<EventPageGroup event={event} />
				</div>
			</div>
		</div>
	);
};

export default EventPage;

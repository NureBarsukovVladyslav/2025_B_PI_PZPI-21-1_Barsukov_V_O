'use client';

import { JSX } from 'react';
import { Button, Card, CardHeader } from '@heroui/react';
import { BtnColorStyle } from '@/constants/btn.constant';
import { GetFullEventResponseDto } from '@/services/event/dto/response/GetFullEvent.response.dto';
import { useDeleteEventMutation } from '@/hooks/event/event.hook';
import UpdateEventModal from '@/app/(pages)/events/modal/UpdateEvent.modal';
import { useSubscribeEventUserMutation, useUnsubscribeEventUserMutation } from '@/hooks/event/event-user';

interface EventPageHeaderProps {
	event: GetFullEventResponseDto;
}

const EventPageHeader = ({ event }: EventPageHeaderProps): JSX.Element => {
	const subscribeEvent = useSubscribeEventUserMutation(event.eventId);
	const unsubscribeEvent = useUnsubscribeEventUserMutation(event.eventId);
	const deleteEvent = useDeleteEventMutation(event.eventId);

	const subscribeEventHandler = async () => {
		await subscribeEvent.mutateAsync(event.eventId);
	};

	const unsubscribeEventHandler = async () => {
		await unsubscribeEvent.mutateAsync(event.eventId);
	};

	const deleteEventHandler = async () => {
		await deleteEvent.mutateAsync(event.eventId);
	};

	return (
		<Card className="card w-full">
			<CardHeader className="px-6">
				<div className="flex flex-row items-center justify-between w-full h-full">
					<div className="flex flex-col gap-1">
						<span className="text-2xl font-medium leading-none">{event.nameOfEvent}</span>
						<span className="text-sm">
							{event.dateOfEvent.split('T')[0]}, {event.timeStart} - {event.timeEnd}
						</span>
						<span className="text-sm">
							{event.country}, {event.city}, {event.address}
						</span>
					</div>
					{event.isOwner ? (
						<div className="flex flex-col gap-2">
							<UpdateEventModal event={event} />
							<Button size="sm" className={BtnColorStyle.danger} onPress={deleteEventHandler}>
								Delete event
							</Button>
						</div>
					) : !event.isParticipant ? (
						<Button size="sm" className={BtnColorStyle.primary} onPress={subscribeEventHandler}>
							Subscribe
						</Button>
					) : (
						<Button size="sm" className={BtnColorStyle.danger} onPress={unsubscribeEventHandler}>
							Unsubscribe
						</Button>
					)}
				</div>
			</CardHeader>
		</Card>
	);
};

export default EventPageHeader;

'use client';

import { Fragment, JSX } from 'react';
import {
	Avatar,
	Card,
	CardBody,
	CardHeader,
	Modal,
	ModalBody,
	ModalContent,
	ModalHeader,
	useDisclosure,
	User,
} from '@heroui/react';
import { GetFullEventResponseDto } from '@/services/event/dto/response/GetFullEvent.response.dto';
import Link from 'next/link';
import { ROUTES } from '@/routes/routes';

interface EventPageGroupProps {
	event: GetFullEventResponseDto;
}

const EventPageGroup = ({ event }: EventPageGroupProps): JSX.Element => {
	const { isOpen, onOpen, onOpenChange } = useDisclosure();

	return (
		<Fragment>
			<Card className="card">
				<CardHeader>
					<div className="flex flex-row items-center justify-between w-full">
						<span className="ml-4 text-xl font-medium">Groups</span>
						<span className="mr-8 text-xl font-medium">{event.groups.length}</span>
					</div>
				</CardHeader>
				<CardBody
					className={`px-6 pt-0 w-full h-full ${event.groups.length ? 'cursor-pointer' : ''}`}
					onClick={event.groups.length ? onOpen : () => {}}
				>
					<div className="flex items-center justify-center w-full h-full">
						{event.groups.length ? (
							<div className="flex flex-wrap items-center justify-center gap-6">
								{event.groups.slice(0, 6).map((group) => (
									<div key={group.groupEventId} className="flex flex-col items-center gap-1">
										<Avatar className="w-20 h-20" />
										<span className="font-medium">{group.group.nameOfGroup}</span>
									</div>
								))}
							</div>
						) : (
							<span className="text-sm text-foreground-400">There are no groups</span>
						)}
					</div>
				</CardBody>
			</Card>
			<Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="top" size="3xl">
				<ModalContent>
					<ModalHeader>Groups</ModalHeader>
					<ModalBody>
						<div className="flex flex-col items-start gap-4 w-full">
							{event.groups.map((group) => (
								<div key={group.groupEventId} className="flex flex-row items-center justify-between w-full">
									<User
										name={group.group.nameOfGroup}
										avatarProps={{ size: 'lg' }}
										as={Link}
										href={ROUTES.GROUPS + '/' + group.group.groupId}
									/>
								</div>
							))}
						</div>
					</ModalBody>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default EventPageGroup;

'use client';

import { JSX } from 'react';
import { Button, Card, CardBody, CardHeader, Chip } from '@heroui/react';
import Link from 'next/link';
import { ROUTES } from '@/routes/routes';
import { BtnColorStyle } from '@/constants/btn.constant';
import { IconPlus } from '@tabler/icons-react';
import { useGetEventsQuery } from '@/hooks/event/event.hook';
import { TARGET_TEXT_CONSTANT } from '@/constants/target.constant';
import CreateEventModal from '@/app/(pages)/events/modal/CreateEvent.modal';

const Events = (): JSX.Element => {
	const events = useGetEventsQuery().data?.data || [];

	return (
		<Card className="card w-full list-max-height">
			<CardHeader className="flex flex-row justify-between">
				<span className="ml-4 text-xl font-medium">Event</span>
				<CreateEventModal />
			</CardHeader>
			<CardBody className={`pt-0 px-6 h-full ${!events.length ? 'justify-center' : ''}`}>
				{events.length ? (
					<div className="flex flex-col gap-4 w-full h-full">
						{events.map((event) => (
							<Card key={event.eventId} className="double-card shrink-0" as={Link} href={ROUTES.EVENTS + '/' + event.eventId}>
								<CardHeader>
									<div className="flex flex-col gap-1 w-full ml-4">
										<span className="text-xl font-medium">{event.nameOfEvent}</span>
										<div className="flex flex-col">
											<span>
												Date time: {event.dateOfEvent.split('T')[0]}, {event.timeStart} - {event.timeEnd}
											</span>
											<span>
												Location: {event.country}, {event.city}, {event.address}
											</span>
											<span>Groups: {event.groups.map((group) => group.group.nameOfGroup)}</span>
										</div>
										{event.targets.length ? (
											<div className="flex flex-row items-center gap-1">
												{event.targets.map((target) => (
													<Chip key={target.eventTargetId} size="sm" color="primary">
														{TARGET_TEXT_CONSTANT[target.target]}
													</Chip>
												))}
											</div>
										) : null}
									</div>
								</CardHeader>
							</Card>
						))}
					</div>
				) : (
					<div className="flex items-center justify-center text-base text-foreground-400 w-full h-full">There are no events</div>
				)}
			</CardBody>
		</Card>
	);
};

export default Events;

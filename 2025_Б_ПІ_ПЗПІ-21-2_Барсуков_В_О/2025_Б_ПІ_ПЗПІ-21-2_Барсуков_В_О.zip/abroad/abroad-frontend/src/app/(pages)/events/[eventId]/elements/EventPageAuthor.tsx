'use client';

import { JSX } from 'react';
import { Avatar, Card, CardHeader } from '@heroui/react';
import { GetFullEventResponseDto } from '@/services/event/dto/response/GetFullEvent.response.dto';
import Link from 'next/link';
import { ROUTES } from '@/routes/routes';

interface EventPageAuthorProps {
	event: GetFullEventResponseDto;
}

const EventPageAuthor = ({ event }: EventPageAuthorProps): JSX.Element => {
	return (
		<Card className="card">
			<CardHeader>
				<Link className="flex items-center gap-2" href={ROUTES.USERS + '/' + event.author.userId}>
					<Avatar size="lg" />
					<div className="flex flex-col">
						<span className="font-medium">
							{event.author.name} {event.author.surname}
						</span>
						<span className="text-sm text-foreground-400">Author of event</span>
					</div>
				</Link>
			</CardHeader>
		</Card>
	);
};

export default EventPageAuthor;

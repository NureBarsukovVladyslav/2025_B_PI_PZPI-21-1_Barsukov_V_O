'use client';

import { JSX } from 'react';
import { Card, CardHeader, CardBody, Chip } from '@heroui/react';
import { GetFullEventResponseDto } from '@/services/event/dto/response/GetFullEvent.response.dto';
import { TARGET_TEXT_CONSTANT } from '@/constants/target.constant';
import CreateOrUpdateEventTargets from '@/app/(pages)/events/[eventId]/modal/eventTargets/CreateOrUpdateEventTargets.modal';

interface EventPageTargetProps {
	event: GetFullEventResponseDto;
}

const EventPageTarget = ({ event }: EventPageTargetProps): JSX.Element => {
	return (
		<Card className="card">
			<CardHeader className="flex flex-row justify-between">
				<span className="ml-4 text-xl font-medium">Targets</span>
				{event.isOwner ? <CreateOrUpdateEventTargets event={event} /> : null}
			</CardHeader>
			<CardBody className="ml-4 pt-0">
				{event.targets.length ? (
					<div className="flex flex-row items-center gap-1">
						{event.targets.map((target) => (
							<Chip key={target.eventTargetId} size="sm">
								{TARGET_TEXT_CONSTANT[target.target]}
							</Chip>
						))}
					</div>
				) : (
					<span className="text-sm text-foreground-400">There are no targets</span>
				)}
			</CardBody>
		</Card>
	);
};

export default EventPageTarget;

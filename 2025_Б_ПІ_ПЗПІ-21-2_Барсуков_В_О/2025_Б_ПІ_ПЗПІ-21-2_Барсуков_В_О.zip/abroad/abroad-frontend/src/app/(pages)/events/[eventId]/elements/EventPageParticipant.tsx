'use client';

import { Fragment, JSX } from 'react';
import {
	Avatar,
	Card,
	CardBody,
	CardHeader,
	Modal,
	ModalBody,
	ModalContent,
	ModalHeader,
	useDisclosure,
	User,
} from '@heroui/react';
import { GetFullEventResponseDto } from '@/services/event/dto/response/GetFullEvent.response.dto';
import Link from 'next/link';
import { ROUTES } from '@/routes/routes';

interface EventPageParticipantProps {
	event: GetFullEventResponseDto;
}

const EventPageParticipant = ({ event }: EventPageParticipantProps): JSX.Element => {
	const { isOpen, onOpen, onOpenChange } = useDisclosure();

	return (
		<Fragment>
			<Card className="card">
				<CardHeader>
					<div className="flex flex-row items-center justify-between w-full">
						<span className="ml-4 text-xl font-medium">Participants</span>
						<span className="mr-8 text-xl font-medium">{event.users.length}</span>
					</div>
				</CardHeader>
				<CardBody
					className={`px-6 pt-0 w-full h-full ${event.users.length ? 'cursor-pointer' : ''}`}
					onClick={event.users.length ? onOpen : () => {}}
				>
					<div className="flex items-center justify-center w-full h-full">
						{event.users.length ? (
							<div className="flex flex-wrap items-center justify-center gap-6">
								{event.users.slice(0, 6).map((user) => (
									<div key={user.eventUserId} className="flex flex-col items-center gap-1">
										<Avatar className="w-20 h-20" />
										<span className="font-medium">
											{user.user.name} {user.user.surname}
										</span>
									</div>
								))}
							</div>
						) : (
							<span className="text-sm text-foreground-400">There are no participants</span>
						)}
					</div>
				</CardBody>
			</Card>
			<Modal isOpen={isOpen} onOpenChange={onOpenChange} placement="top" size="3xl">
				<ModalContent>
					<ModalHeader>Participants</ModalHeader>
					<ModalBody>
						<div className="flex flex-col items-start gap-4 w-full">
							{event.users.map((user) => (
								<div key={user.eventUserId} className="flex flex-row items-center justify-between w-full">
									<User
										name={`${user.user.name} ${user.user.surname}`}
										avatarProps={{ size: 'lg' }}
										as={Link}
										href={ROUTES.USERS + '/' + user.user.userId}
									/>
								</div>
							))}
						</div>
					</ModalBody>
				</ModalContent>
			</Modal>
		</Fragment>
	);
};

export default EventPageParticipant;

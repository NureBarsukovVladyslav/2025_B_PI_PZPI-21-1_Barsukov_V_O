'use client';

import { JSX } from 'react';
import { Button, Card, CardBody, CardHeader, User } from '@heroui/react';
import Link from 'next/link';
import { ROUTES } from '@/routes/routes';
import { BtnColorStyle } from '@/constants/btn.constant';
import { getCookie } from 'cookies-next';
import { ACCESS_TOKEN_KEY } from '@/constants/jwt.constant';
import { AccessTokenPayload } from '@/middleware';
import { jwtDecode } from 'jwt-decode';
import { useGetUserQuery } from '@/hooks/user/user.hook';
import { useLeaveGroupUserMutation } from '@/hooks/group/group-user.hook';
import { ApiEntityEnum } from '@/utils/axios/api.routes';

const MyGroups = (): JSX.Element => {
	const accessToken = getCookie(ACCESS_TOKEN_KEY) || '';
	const payload: AccessTokenPayload = jwtDecode(accessToken);
	const user = useGetUserQuery(payload.userId).data?.data || null;
	const leaveGroupUser = useLeaveGroupUserMutation(0, ApiEntityEnum.USER + payload.userId);

	if (!user) return <></>;

	const leaveGroupUserHandler = async (groupId: number) => {
		await leaveGroupUser.mutateAsync(groupId);
	};

	return (
		<Card className="card w-full list-max-height">
			<CardHeader>
				<span className="ml-4 text-xl font-medium">My Groups</span>
			</CardHeader>
			<CardBody className="pt-0 px-6">
				{user.groups.length ? (
					<div className="flex flex-col items-start gap-4 w-full">
						{user.groups.map((group) => (
							<div key={group.groupUserId} className="flex flex-row items-center justify-between w-full">
								<User
									name={group.group.nameOfGroup}
									avatarProps={{ size: 'lg' }}
									as={Link}
									href={ROUTES.GROUPS + '/' + group.group.groupId}
								/>
								<Button className={BtnColorStyle.danger} size="sm" onPress={() => leaveGroupUserHandler(group.group.groupId)}>
									Leave
								</Button>
							</div>
						))}
					</div>
				) : (
					<span className="flex flex-1 items-center justify-center text-base text-foreground-400 w-full h-full">
						You are not in groups
					</span>
				)}
			</CardBody>
		</Card>
	);
};

export default MyGroups;

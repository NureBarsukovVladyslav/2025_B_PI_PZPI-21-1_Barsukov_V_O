'use client';

import '../../../styles/pages/auth.css';

import { JSX, useState } from 'react';
import { useSignupMutation } from '@/hooks/auth.hook';
import { SignupRequestDto } from '@/services/auth/dto/request/Signup.request.dto';
import { TypeOfGender } from '@/enum/TypeOfGender.enum';
import { IconArrowsDiff, IconLogin2, IconPasswordUser } from '@tabler/icons-react';
import { AccordionItem, Autocomplete, Button, Card, CardBody, DatePicker, Select, SelectItem, Input } from '@heroui/react';
import { Form, Formik } from 'formik';
import { BtnColorStyle } from '@/constants/btn.constant';
import Link from 'next/link';
import { ROUTES } from '@/routes/routes';
import InputGroup from '@/components/elements/input/InputGroup';
import { Country, City } from 'country-state-city';
import { SignupSchema } from '@/app/(auth)/signup/signup.schema';

const Signup = (): JSX.Element => {
	const [chooseCounty, setChooseCountry] = useState<string | null>(null);

	const signupMutation = useSignupMutation();

	const initialValues: SignupRequestDto = {
		name: '',
		surname: '',
		gender: TypeOfGender.MALE,
		email: '',
		password: '',
		dateOfBirth: null,
		country: '',
		city: '',
		dateOfArrival: null,
		statusOfStay: null,
		statusOfUser: null,
		goalOfUser: null,
	};

	const submitHandler = async (values: SignupRequestDto): Promise<void> => {
		await signupMutation.mutateAsync(values);
	};

	return (
		<div className="signup flex flex-col gap-8 items-center justify-center w-full h-screen">
			<div className="context flex items-center justify-center gap-4 z-10">
				<h1 className="font-medium">Connect Abroad</h1>
				<IconArrowsDiff className="text-blue-400" size={48} />
			</div>
			<Card isBlurred className="card w-1/3 z-10" shadow="lg">
				<CardBody>
					<Formik initialValues={initialValues} onSubmit={submitHandler} validationSchema={SignupSchema}>
						{({ values, errors, setFieldValue, handleSubmit, isValid }) => (
							<Form onSubmit={handleSubmit}>
								<div className="flex flex-col gap-4">
									<InputGroup>
										<Input
											isRequired
											label="Name"
											variant="bordered"
											size="sm"
											onValueChange={(value) => setFieldValue('name', value)}
											isInvalid={!!errors.name}
											errorMessage={errors.name as string}
										/>
										<Input
											isRequired
											label="Surname"
											variant="bordered"
											size="sm"
											onValueChange={(value) => setFieldValue('surname', value)}
											isInvalid={!!errors.surname}
											errorMessage={errors.surname as string}
										/>
									</InputGroup>
									<Select
										isRequired
										disallowEmptySelection
										label="Gender"
										variant="bordered"
										size="sm"
										onChange={(event) => setFieldValue('gender', event.target.value)}
									>
										<SelectItem key={TypeOfGender.MALE}>Male</SelectItem>
										<SelectItem key={TypeOfGender.FEMALE}>Female</SelectItem>
									</Select>
									<Input
										isRequired
										type="email"
										label="Email"
										variant="bordered"
										size="sm"
										onValueChange={(value) => setFieldValue('email', value)}
										isInvalid={!!errors.email}
										errorMessage={errors.email as string}
									/>
									<Input
										isRequired
										type="password"
										label="Password"
										variant="bordered"
										size="sm"
										onValueChange={(value) => setFieldValue('password', value)}
										isInvalid={!!errors.password}
										errorMessage={errors.password as string}
									/>
									<DatePicker
										showMonthAndYearPickers
										label="Date of birth"
										variant="bordered"
										size="sm"
										onChange={(value) => setFieldValue('dateOfBirth', value ? `${value.toString()}T00:00:00Z` : null)}
										isInvalid={!!errors.dateOfBirth}
										errorMessage={errors.dateOfBirth as string}
									/>
									<Autocomplete
										isRequired
										disallowEmptySelection
										label="Contry"
										variant="bordered"
										size="sm"
										onSelectionChange={(key) => {
											setChooseCountry(key as string);
											setFieldValue('country', Country.getCountryByCode(key as string)?.name || '');
										}}
										defaultItems={Country.getAllCountries()}
									>
										{(item) => <AccordionItem key={item.isoCode}>{item.name}</AccordionItem>}
									</Autocomplete>
									<Autocomplete
										isDisabled={!chooseCounty}
										isRequired
										disallowEmptySelection
										label="City"
										variant="bordered"
										size="sm"
										onSelectionChange={(key) => setFieldValue('city', key)}
										defaultItems={chooseCounty ? City.getCitiesOfCountry(chooseCounty) : []}
									>
										{(item) => <AccordionItem key={item.name}>{item.name}</AccordionItem>}
									</Autocomplete>
									<Button
										isDisabled={!isValid}
										className={BtnColorStyle.primary}
										endContent={<IconPasswordUser size={18} />}
										type="submit"
									>
										Sign up
									</Button>
									<Button as={Link} href={ROUTES.LOGIN} className={BtnColorStyle.primary} endContent={<IconLogin2 size={18} />}>
										I already have an account
									</Button>
								</div>
							</Form>
						)}
					</Formik>
				</CardBody>
			</Card>
			<div className="area">
				<ul className="circles">
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
				</ul>
			</div>
		</div>
	);
};

export default Signup;

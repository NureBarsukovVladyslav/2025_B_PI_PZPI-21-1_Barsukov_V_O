import { mixed, object, string } from 'yup';
import { DEFAULT_STRING_MIN_LENGTH } from '@/constants/default-value.constant';
import {
	INPUT_DATA_IS_REQUIRED,
	INPUT_DATA_TOO_LONG,
	INPUT_DATA_TOO_SHORT,
	INPUT_PASSWORD_MUST_LOWERCASE,
	INPUT_PASSWORD_MUST_NUMBER,
	INPUT_PASSWORD_MUST_SYMBOL,
	INPUT_PASSWORD_MUST_UPPERCASE,
} from '@/constants/error/input.error';
import { TypeOfGender } from '@/enum/TypeOfGender.enum';
import {
	PASSWORD_LOWERCASE_REGEX,
	PASSWORD_NUMBER_REGEX,
	PASSWORD_SYMBOLS_REGEX,
	PASSWORD_UPPERCASE_REGEX,
} from '@/regex/password.regex';
import { StatusOfUser } from '@/enum/StatusOfUser.enum';
import { StatusOfStay } from '@/enum/StatusOfStay.enum';

export const SignupSchema = object().shape({
	name: string()
		.min(DEFAULT_STRING_MIN_LENGTH, INPUT_DATA_TOO_SHORT)
		.max(20, INPUT_DATA_TOO_LONG)
		.required(INPUT_DATA_IS_REQUIRED),
	surname: string()
		.min(DEFAULT_STRING_MIN_LENGTH, INPUT_DATA_TOO_SHORT)
		.max(20, INPUT_DATA_TOO_LONG)
		.required(INPUT_DATA_IS_REQUIRED),
	gender: mixed<TypeOfGender>().required(INPUT_DATA_IS_REQUIRED),
	email: string().required(INPUT_DATA_IS_REQUIRED),
	password: string()
		.matches(PASSWORD_LOWERCASE_REGEX, INPUT_PASSWORD_MUST_LOWERCASE)
		.matches(PASSWORD_UPPERCASE_REGEX, INPUT_PASSWORD_MUST_UPPERCASE)
		.matches(PASSWORD_NUMBER_REGEX, INPUT_PASSWORD_MUST_NUMBER)
		.matches(PASSWORD_SYMBOLS_REGEX, INPUT_PASSWORD_MUST_SYMBOL)
		.required(INPUT_DATA_IS_REQUIRED),
	dateOfBirth: string().nullable(),
	country: string(),
	city: string(),
	dateOfArrival: string().nullable(),
	statusOfStay: mixed<StatusOfStay>().nullable(),
	statusOfUser: mixed<StatusOfUser>().nullable(),
	goalOfUser: string().min(DEFAULT_STRING_MIN_LENGTH, INPUT_DATA_TOO_SHORT).max(300, INPUT_DATA_TOO_LONG).nullable(),
});

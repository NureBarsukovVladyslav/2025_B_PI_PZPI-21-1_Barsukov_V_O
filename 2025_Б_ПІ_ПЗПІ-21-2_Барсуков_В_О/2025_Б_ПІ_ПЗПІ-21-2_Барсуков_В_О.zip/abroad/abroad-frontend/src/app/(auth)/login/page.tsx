'use client';

import '../../../styles/pages/auth.css';

import { JSX } from 'react';
import { Button, Card, CardBody } from '@heroui/react';
import { Input } from '@heroui/input';
import { Form, Formik, FormikHelpers } from 'formik';
import { LoginRequestDto } from '@/services/auth/dto/request/Login.request.dto';
import { useLoginMutation } from '@/hooks/auth.hook';
import { LoginSchema } from '@/app/(auth)/login/login.schema';
import { IconArrowsDiff, IconLogin2, IconPasswordUser } from '@tabler/icons-react';
import { BtnColorStyle } from '@/constants/btn.constant';
import Link from 'next/link';
import { ROUTES } from '@/routes/routes';

const Login = (): JSX.Element => {
	const loginMutation = useLoginMutation();

	const initialValues: LoginRequestDto = { email: '', password: '' };

	const submitHandler = async (values: LoginRequestDto, { setSubmitting }: FormikHelpers<any>): Promise<void> => {
		await loginMutation.mutateAsync(values);
		setSubmitting(true);
	};

	return (
		<div className="flex flex-col gap-12 items-center justify-center w-full h-screen">
			<div className="context flex items-center justify-center gap-4 z-10">
				<h1 className="font-medium">Connect Abroad</h1>
				<IconArrowsDiff className="text-blue-400" size={48} />
			</div>
			<Card className="card w-1/3 z-10" shadow="lg">
				<CardBody>
					<Formik initialValues={initialValues} onSubmit={submitHandler} validationSchema={LoginSchema}>
						{({ values, errors, setFieldValue, handleSubmit, isValid }) => (
							<Form onSubmit={handleSubmit}>
								<div className="flex flex-col gap-4">
									<Input
										isRequired
										label="Email"
										variant="bordered"
										size="sm"
										onValueChange={(value) => setFieldValue('email', value)}
										isInvalid={!!errors.email}
										errorMessage={errors.email as string}
									/>
									<Input
										isRequired
										type="password"
										label="Password"
										variant="bordered"
										size="sm"
										onValueChange={(value) => setFieldValue('password', value)}
										isInvalid={!!errors.password}
										errorMessage={errors.password as string}
									/>
									<Button
										isDisabled={!isValid}
										className={BtnColorStyle.primary}
										endContent={<IconLogin2 size={18} />}
										type="submit"
									>
										Log in
									</Button>
									<Button
										as={Link}
										href={ROUTES.SIGNUP}
										className={BtnColorStyle.primary}
										endContent={<IconPasswordUser size={18} />}
									>
										I don't have an account
									</Button>
								</div>
							</Form>
						)}
					</Formik>
				</CardBody>
			</Card>
			<div className="area">
				<ul className="circles">
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
					<li></li>
				</ul>
			</div>
		</div>
	);
};

export default Login;

import { object, string } from 'yup';
import { INPUT_DATA_IS_REQUIRED, INPUT_EMAIL_DATA_IS_NOT_CORRECT } from '@/constants/error/input.error';

export const LoginSchema = object().shape({
	email: string().email(INPUT_EMAIL_DATA_IS_NOT_CORRECT).required(INPUT_DATA_IS_REQUIRED),
	password: string().required(INPUT_DATA_IS_REQUIRED),
});

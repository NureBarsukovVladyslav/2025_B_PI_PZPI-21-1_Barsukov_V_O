import { IObjectIndex } from '@/interfaces/frontend/object.interface';

export interface IRoutes extends IObjectIndex {
	LOGIN: string;
	SIGNUP: string;
	EVENTS: string;
	USERS: string;
	MY_FRIENDS: string;
	MY_GROUPS: string;
	GROUPS: string;
	ARTICLES: string;
}

export const ROUTES: IRoutes = {
	LOGIN: '/login',
	SIGNUP: '/signup',
	EVENTS: '/events',
	USERS: '/users',
	MY_FRIENDS: '/my-friends',
	MY_GROUPS: '/my-groups',
	GROUPS: '/groups',
	ARTICLES: '/articles',
};

export const PUBLIC_ROUTES: string[] = [ROUTES.LOGIN, ROUTES.SIGNUP];

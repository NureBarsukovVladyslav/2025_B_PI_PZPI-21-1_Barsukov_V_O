import { addToast } from '@heroui/toast';

export const successAlert = (message: string) =>
	addToast({
		title: 'Success',
		description: message,
		color: 'success',
		timeout: 3000,
	});

export const dangerAlert = (message: string, code: number) =>
	addToast({
		title: `Error ${code}`,
		description: message,
		color: 'danger',
		timeout: 3000,
	});

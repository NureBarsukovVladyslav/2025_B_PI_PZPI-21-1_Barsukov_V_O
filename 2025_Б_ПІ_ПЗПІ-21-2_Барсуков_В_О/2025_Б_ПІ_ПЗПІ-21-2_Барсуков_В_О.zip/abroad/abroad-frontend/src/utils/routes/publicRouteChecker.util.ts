import { PUBLIC_ROUTES } from '@/routes/routes';

export const publicRouteCheckerUtil = (pathname: string): boolean => PUBLIC_ROUTES.includes(pathname);

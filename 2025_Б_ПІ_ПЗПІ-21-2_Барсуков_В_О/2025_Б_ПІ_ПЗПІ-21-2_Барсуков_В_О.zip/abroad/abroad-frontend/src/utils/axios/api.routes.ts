export enum ApiEntityEnum {
	AUTH = 'auth',
	ARTICLE = 'article',
	EVENT = 'event',
	EVENT_GROUP = 'event-group',
	EVENT_TARGET = 'event-target',
	EVENT_USER = 'event-user',
	GROUP = 'group',
	GROUP_HOBBY = 'group-hobby',
	GROUP_LANGUAGE = 'group-language',
	GROUP_MESSAGE = 'group-message',
	GROUP_TARGET = 'group-target',
	GROUP_USER = 'group-user',
	USER = 'user',
	USER_FRIEND = 'user-friend',
	USER_HOBBY = 'user-hobby',
	USER_LANGUAGE = 'user-language',
	USER_TARGET = 'user-target',
}

export interface IApiRoutes {
	[path: string]: string;
}

export const generateApiPath = (entity: ApiEntityEnum, path?: string): string =>
	`http://localhost:3000/api/${entity}/${path || ''}`;

import axios, { AxiosError, AxiosResponse } from 'axios';
import { AxiosResponseDto, AxiosResponseErrorDto } from '@/dto/response/axios/axios.response.dto';
import { axiosErrorHandler } from '../../handler/axiosError.handler';
import { successAlert } from '@/utils/alert/alert.util';
import { AUTH_ERROR, AUTH_REFRESH_ERROR } from '@/constants/error/auth.error';
import { PayloadResponseDto } from '@/services/auth/dto/response/payload.response.dto';
import { authService } from '@/services/auth/auth.service';
import { logout } from '@/hooks/auth.hook';

enum AXIOS_METHOD {
	GET = 'get',
	POST = 'post',
	PUT = 'put',
	PATCH = 'patch',
	DELETE = 'delete',
}

export const axiosInterceptorOnFulfilled = (response: AxiosResponse<AxiosResponseDto<any>>): AxiosResponse => {
	const method = response.config?.method;

	if (method) {
		switch (method) {
			case AXIOS_METHOD.GET:
				return response;
			case AXIOS_METHOD.POST: {
				successAlert(response.data.message);
				return response;
			}
			case AXIOS_METHOD.PUT: {
				successAlert(response.data.message);
				return response;
			}
			case AXIOS_METHOD.PATCH: {
				successAlert(response.data.message);
				return response;
			}
			case AXIOS_METHOD.DELETE: {
				successAlert(response.data.message);
				return response;
			}
		}
	}

	return response;
};

export const axiosInterceptorOnRejected = async (error: AxiosError<AxiosResponseErrorDto>) => {
	const statusCode = error.response?.data.statusCode;
	const message = error.response?.data.message;

	if (statusCode === AUTH_ERROR.statusCode && message === AUTH_ERROR.message) {
		try {
			const resRefreshToken: PayloadResponseDto | undefined = await authService.refresh();
			const originalRequest = error.config;

			if (originalRequest) {
				originalRequest.headers['Authorization'] = `Bearer ${resRefreshToken?.access_token}`;
				return axios(originalRequest);
			}
		} catch (refError) {
			const { response } = refError as AxiosError<AxiosResponseErrorDto>;

			if (response?.data.statusCode === AUTH_REFRESH_ERROR.statusCode && response?.data.message === AUTH_REFRESH_ERROR.message) {
				logout();
			}
		}
	} else {
		axiosErrorHandler(error);
	}

	return Promise.reject(error);
};

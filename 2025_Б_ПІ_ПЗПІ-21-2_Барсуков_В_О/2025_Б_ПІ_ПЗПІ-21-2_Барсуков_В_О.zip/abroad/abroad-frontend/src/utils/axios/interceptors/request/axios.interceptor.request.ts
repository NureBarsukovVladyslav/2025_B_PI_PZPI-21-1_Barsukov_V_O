import { ACCESS_TOKEN_KEY } from '@/constants/jwt.constant';
import { InternalAxiosRequestConfig } from 'axios';
import { getCookie } from 'cookies-next';

export const axiosInterceptorsOnRequest = async (config: InternalAxiosRequestConfig) => {
	const accessToken = getCookie(ACCESS_TOKEN_KEY);

	if (config.headers) config.headers['authorization'] = `Bearer ${accessToken}`;

	return config;
};

import { AxiosError } from 'axios';
import { AxiosResponseErrorDto } from '@/dto/response/axios/axios.response.dto';
import { dangerAlert } from '@/utils/alert/alert.util';

export const axiosErrorHandler = ({ response, code }: AxiosError<AxiosResponseErrorDto>) => {
	let statusCode: number = 0;
	let message: string | string[] = 'error';
	let error: string = 'FETCH_ERROR';

	if (response) {
		if (response.status) statusCode = response.status;

		if (response.data && typeof response.data === 'object') {
			if (response.data.statusCode) statusCode === response.data.statusCode;
			if (response.data.error) error = response.data.error;
			if (response.data.message) message = response.data.message;
		} else {
			if (code) error = code;
			if (response.statusText) message = response.statusText;
		}
	}

	return dangerAlert(`${Array.isArray(message) ? message.map((message) => message) : message}`, statusCode);
};

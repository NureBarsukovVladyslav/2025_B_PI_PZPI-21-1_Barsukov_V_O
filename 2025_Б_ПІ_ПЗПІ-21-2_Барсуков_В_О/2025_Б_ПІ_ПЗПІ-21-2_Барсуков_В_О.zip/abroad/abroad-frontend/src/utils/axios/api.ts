// UTILS
import axios, { AxiosResponse } from 'axios';

// CONFIG
import { axiosRequestConfig } from '@/utils/axios/axios.config';

// INTERCEPTORS REQUEST
import { axiosInterceptorsOnRequest } from '@/utils/axios/interceptors/request/axios.interceptor.request';

// INTERCEPTORS RESPONSE
import {
	axiosInterceptorOnFulfilled,
	axiosInterceptorOnRejected,
} from '@/utils/axios/interceptors/response/axios.interceptor.response';

// DTO
import { AxiosResponseDto } from '@/dto/response/axios/axios.response.dto';

axios.interceptors.request.use(axiosInterceptorsOnRequest);
axios.interceptors.response.use(axiosInterceptorOnFulfilled, axiosInterceptorOnRejected);

export const api = {
	get: <T>(url: string, params?: object): Promise<AxiosResponse<AxiosResponseDto<T>>> =>
		axios.get<AxiosResponseDto<T>>(url, {
			...axiosRequestConfig,
			...params,
		}),
	post: <T>(url: string, data: any, params?: object): Promise<AxiosResponse<AxiosResponseDto<T>>> =>
		axios.post<AxiosResponseDto<T>>(url, data, {
			...axiosRequestConfig,
			...params,
		}),
	put: <T>(url: string, data?: any, params?: object): Promise<AxiosResponse<AxiosResponseDto<T>>> =>
		axios.put<AxiosResponseDto<T>>(url, data, {
			...axiosRequestConfig,
			...params,
		}),
	patch: <T>(url: string, data?: any, params?: object): Promise<AxiosResponse<AxiosResponseDto<T>>> =>
		axios.patch<AxiosResponseDto<T>>(url, data, {
			...axiosRequestConfig,
			...params,
		}),
	delete: <T>(url: string, params?: object): Promise<AxiosResponse<AxiosResponseDto<T>>> =>
		axios.delete<AxiosResponseDto<T>>(url, {
			...axiosRequestConfig,
			...params,
		}),
};

import { AxiosRequestConfig } from 'axios';

export const axiosRequestConfig: AxiosRequestConfig = {
	headers: {
		'Content-Type': 'application/json',
		Accept: 'application/json',
	},
	withCredentials: true,
};

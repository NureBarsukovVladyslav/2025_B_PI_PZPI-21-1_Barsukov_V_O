import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const ARTICLE_ROUTES = {
	getArticles: generateApiPath(ApiEntityEnum.ARTICLE),
	getArticle: generateApiPath(ApiEntityEnum.ARTICLE),
	createArticle: generateApiPath(ApiEntityEnum.ARTICLE),
	updateArticle: generateApiPath(ApiEntityEnum.ARTICLE),
	deleteArticle: generateApiPath(ApiEntityEnum.ARTICLE),
};

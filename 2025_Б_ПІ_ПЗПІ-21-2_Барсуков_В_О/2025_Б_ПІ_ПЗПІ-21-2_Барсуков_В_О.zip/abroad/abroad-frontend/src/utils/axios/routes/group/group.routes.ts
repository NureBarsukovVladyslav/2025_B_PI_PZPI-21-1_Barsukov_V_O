import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const GROUP_ROUTES = {
	getRecommendationGroups: generateApiPath(ApiEntityEnum.GROUP, 'recommendation/'),
	getGroups: generateApiPath(ApiEntityEnum.GROUP),
	getGroup: generateApiPath(ApiEntityEnum.GROUP),
	createGroup: generateApiPath(ApiEntityEnum.GROUP),
	updateGroup: generateApiPath(ApiEntityEnum.GROUP),
	deleteGroup: generateApiPath(ApiEntityEnum.GROUP),
};

import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const GROUP_TARGET_ROUTES = {
	createOrUpdateTargets: generateApiPath(ApiEntityEnum.GROUP_TARGET),
};

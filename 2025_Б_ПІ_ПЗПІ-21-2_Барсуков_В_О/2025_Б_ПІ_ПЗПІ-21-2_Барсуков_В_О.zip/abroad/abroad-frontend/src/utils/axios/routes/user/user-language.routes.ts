import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const USER_LANGUAGE_ROUTES = {
	createUserLanguage: generateApiPath(ApiEntityEnum.USER_LANGUAGE),
	deleteUserLanguage: generateApiPath(ApiEntityEnum.USER_LANGUAGE),
};

import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const GROUP_LANGUAGE_ROUTES = {
	createGroupLanguage: generateApiPath(ApiEntityEnum.GROUP_LANGUAGE),
	deleteGroupLanguage: generateApiPath(ApiEntityEnum.GROUP_LANGUAGE),
};

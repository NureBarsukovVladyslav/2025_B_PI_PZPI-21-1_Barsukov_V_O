import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const GROUP_USER_ROUTES = {
	addGroupUser: generateApiPath(ApiEntityEnum.GROUP_USER, 'add-user/'),
	leaveGroupUser: generateApiPath(ApiEntityEnum.GROUP_USER, 'leave-user/'),
	deleteGroupUser: generateApiPath(ApiEntityEnum.GROUP_USER, 'delete-user/'),
};

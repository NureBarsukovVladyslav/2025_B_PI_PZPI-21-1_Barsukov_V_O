import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const USER_ROUTES = {
	getRecommendationUsers: generateApiPath(ApiEntityEnum.USER, 'recommendation/'),
	getUsers: generateApiPath(ApiEntityEnum.USER),
	getUser: generateApiPath(ApiEntityEnum.USER),
	updateUser: generateApiPath(ApiEntityEnum.USER),
	changeUserPassword: generateApiPath(ApiEntityEnum.USER, 'change-password/'),
};

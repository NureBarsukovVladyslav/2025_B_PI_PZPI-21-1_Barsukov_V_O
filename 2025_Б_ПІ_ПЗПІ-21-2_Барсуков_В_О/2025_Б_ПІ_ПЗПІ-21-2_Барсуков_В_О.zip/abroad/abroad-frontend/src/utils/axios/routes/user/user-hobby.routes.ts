import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const USER_HOBBY_ROUTES = {
	createOrUpdateHobbies: generateApiPath(ApiEntityEnum.USER_HOBBY),
};

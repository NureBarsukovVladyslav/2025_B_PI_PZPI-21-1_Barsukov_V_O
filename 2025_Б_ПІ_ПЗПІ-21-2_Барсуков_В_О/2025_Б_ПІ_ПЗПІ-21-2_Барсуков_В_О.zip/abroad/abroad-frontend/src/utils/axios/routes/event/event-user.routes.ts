import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const EVENT_USER_ROUTES = {
	subscribeEvent: generateApiPath(ApiEntityEnum.EVENT_USER, 'subscribe/'),
	unsubscribeEvent: generateApiPath(ApiEntityEnum.EVENT_USER, 'unsubscribe/'),
};

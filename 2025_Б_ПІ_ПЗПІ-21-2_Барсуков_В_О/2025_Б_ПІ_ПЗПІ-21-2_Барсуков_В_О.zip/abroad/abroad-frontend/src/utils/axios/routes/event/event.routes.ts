import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const EVENT_ROUTES = {
	getEvents: generateApiPath(ApiEntityEnum.EVENT),
	getEvent: generateApiPath(ApiEntityEnum.EVENT),
	createEvent: generateApiPath(ApiEntityEnum.EVENT),
	updateEvent: generateApiPath(ApiEntityEnum.EVENT),
	deleteEvent: generateApiPath(ApiEntityEnum.EVENT),
};

import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const EVENT_GROUP_ROUTES = {
	subscribeEvent: generateApiPath(ApiEntityEnum.EVENT_GROUP, 'subscribe/'),
	unsubscribeEvent: generateApiPath(ApiEntityEnum.EVENT_GROUP, 'unsubscribe/'),
};

import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const USER_TARGET_ROUTES = {
	createOrUpdateTargets: generateApiPath(ApiEntityEnum.USER_TARGET),
};

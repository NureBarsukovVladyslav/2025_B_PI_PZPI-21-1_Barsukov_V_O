import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const AUTH_ROUTES = {
	login: generateApiPath(ApiEntityEnum.AUTH, 'login'),
	signup: generateApiPath(ApiEntityEnum.AUTH, 'signup'),
	refresh: generateApiPath(ApiEntityEnum.AUTH, 'refresh'),
};

import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const GROUP_HOBBY_ROUTES = {
	createOrUpdateHobbies: generateApiPath(ApiEntityEnum.GROUP_HOBBY),
};

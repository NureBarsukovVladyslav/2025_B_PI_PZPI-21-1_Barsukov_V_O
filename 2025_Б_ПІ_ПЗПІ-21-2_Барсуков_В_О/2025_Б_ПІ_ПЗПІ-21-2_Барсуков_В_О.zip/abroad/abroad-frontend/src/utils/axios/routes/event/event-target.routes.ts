import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const EVENT_TARGET_ROUTES = {
	createOrUpdateTargets: generateApiPath(ApiEntityEnum.EVENT_TARGET),
};

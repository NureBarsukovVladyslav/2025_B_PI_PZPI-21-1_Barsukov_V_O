import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const USER_FRIEND_ROUTES = {
	getFriends: generateApiPath(ApiEntityEnum.USER_FRIEND),
	getFriendsRequest: generateApiPath(ApiEntityEnum.USER_FRIEND, 'friend-request/'),
	getFriendMessages: generateApiPath(ApiEntityEnum.USER_FRIEND, 'messages/'),
	createFriendMessage: generateApiPath(ApiEntityEnum.USER_FRIEND, 'create-message/'),
	makeFriend: generateApiPath(ApiEntityEnum.USER_FRIEND, 'make-friend/'),
	acceptFriendRequest: generateApiPath(ApiEntityEnum.USER_FRIEND, 'accept-friend/'),
	rejectFriendRequest: generateApiPath(ApiEntityEnum.USER_FRIEND, 'reject-friend/'),
	blockFriend: generateApiPath(ApiEntityEnum.USER_FRIEND, 'block-friend/'),
	unblockFriend: generateApiPath(ApiEntityEnum.USER_FRIEND, 'unblock-friend/'),
	deleteFriend: generateApiPath(ApiEntityEnum.USER_FRIEND),
};

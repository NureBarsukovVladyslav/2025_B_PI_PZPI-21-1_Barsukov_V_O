import { ApiEntityEnum, generateApiPath } from '@/utils/axios/api.routes';

export const GROUP_MESSAGE_ROUTES = {
	createMessage: generateApiPath(ApiEntityEnum.GROUP_MESSAGE),
};

import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { useMutation, useQueryClient } from 'react-query';
import { CreateOrUpdateUserHobbyRequestDto } from '@/services/user/user-hobby/dto/request/CreateOrUpdateUserHobby.request.dto';
import { userHobbyService } from '@/services/user/user-hobby/user-hobby.service';

export const useCreateOrUpdateUserHobbiesMutation = (userId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[ApiEntityEnum.USER_HOBBY],
		async (dto: CreateOrUpdateUserHobbyRequestDto) => await userHobbyService.createOrUpdateUserHobbies(dto),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([ApiEntityEnum.USER + userId]);
			},
		},
	);
};

import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { useMutation, useQueryClient } from 'react-query';
import { CreateOrUpdateUserTargetRequestDto } from '@/services/user/user-target/dto/request/CreateOrUpdateUserTarget.request.dto';
import { userTargetService } from '@/services/user/user-target/user-target.service';

export const useCreateOrUpdateUserTargetsMutation = (userId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[ApiEntityEnum.USER_TARGET],
		async (dto: CreateOrUpdateUserTargetRequestDto) => await userTargetService.createOrUpdateUserTargets(dto),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([ApiEntityEnum.USER + userId]);
			},
		},
	);
};

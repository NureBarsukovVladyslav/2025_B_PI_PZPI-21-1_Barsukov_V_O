import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { useMutation, useQuery, useQueryClient } from 'react-query';
import { userService } from '@/services/user/user.service';
import { UpdateUserRequestDto } from '@/services/user/dto/request/UpdateUser.request.dto';
import { ChangeUserPasswordRequestDto } from '@/services/user/dto/request/ChangeUserPassword.request.dto';

const queryKey: string = ApiEntityEnum.USER;

export const useGetRecommendationUsersQuery = () => {
	return useQuery(['user-recommendation'], async () => await userService.getRecommendationUsers());
};

export const useGetUsersQuery = () => {
	return useQuery([queryKey], async () => await userService.getUsers());
};

export const useGetUserQuery = (userId: number) => {
	return useQuery([queryKey + userId], async () => await userService.getUser(userId));
};

export const useUpdateUserMutation = (userId: number) => {
	const queryClient = useQueryClient();

	return useMutation([queryKey + userId], async (dto: UpdateUserRequestDto) => await userService.updateUser(dto), {
		onSuccess: async () => {
			await queryClient.invalidateQueries(queryKey + userId);
		},
	});
};

export const useChangeUserPasswordMutation = () => {
	return useMutation([queryKey], async (dto: ChangeUserPasswordRequestDto) => await userService.changeUserPassword(dto));
};

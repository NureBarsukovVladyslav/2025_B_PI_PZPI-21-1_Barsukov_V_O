import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { useMutation, useQueryClient } from 'react-query';
import { CreateUserLanguageRequestDto } from '@/services/user/user-language/dto/request/CreateUserLanguage.request.dto';
import { userLanguageService } from '@/services/user/user-language/user-language.service';

export const useCreateUserLanguageMutation = (userId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[ApiEntityEnum.USER_LANGUAGE],
		async (dto: CreateUserLanguageRequestDto) => await userLanguageService.createUserLanguage(dto),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([ApiEntityEnum.USER + userId]);
			},
		},
	);
};

export const useDeleteUserLanguageMutation = (userId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[ApiEntityEnum.USER_LANGUAGE],
		async (userLanguageId: number) => await userLanguageService.deleteUserLanguage(userLanguageId),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([ApiEntityEnum.USER + userId]);
			},
		},
	);
};

import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { useMutation, useQuery, useQueryClient } from 'react-query';
import { userFriendService } from '@/services/user/user-friend/user-friend.service';
import { CreateFriendMessageRequestDto } from '@/services/user/user-friend/dto/request/CreateFriendMessage.request.dto';

const queryKey: string = ApiEntityEnum.USER_FRIEND;
const queryKeyRequest: string = 'user-friend-request';
const queryMessagesKey: string = 'user-friend-messages';

export const useGetFriendsQuery = () => {
	return useQuery([queryKey], async () => await userFriendService.getFriends());
};

export const useGetFriendsRequestQuery = () => {
	return useQuery([queryKeyRequest], async () => await userFriendService.getFriendsRequest());
};

export const useGetFriendsMessagesQuery = (friendId: number) => {
	return useQuery([queryMessagesKey + friendId], async () => await userFriendService.getFriendMessages(friendId));
};

export const useCreateFriendMessageMutation = (friendId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[queryMessagesKey + friendId],
		async (dto: CreateFriendMessageRequestDto) => await userFriendService.createFriendMessage(friendId, dto),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([queryMessagesKey + friendId]);
			},
		},
	);
};

export const useMakeFriendMutation = (friendId?: number) => {
	const queryClient = useQueryClient();

	return useMutation([queryKey], async (friendId: number) => await userFriendService.makeFriend(friendId), {
		onSuccess: async () => {
			await queryClient.invalidateQueries([queryKey]);
			if (friendId) await queryClient.invalidateQueries([ApiEntityEnum.USER + friendId]);
		},
	});
};

export const useAcceptFriendRequestMutation = () => {
	const queryClient = useQueryClient();

	return useMutation([queryKeyRequest], async (friendId: number) => await userFriendService.acceptFriendRequest(friendId), {
		onSuccess: async () => {
			await queryClient.invalidateQueries([queryKey]);
			await queryClient.invalidateQueries([queryKeyRequest]);
		},
	});
};

export const useRejectFriendRequestMutation = (friendId?: number) => {
	const queryClient = useQueryClient();

	return useMutation([queryKeyRequest], async (friendId: number) => await userFriendService.rejectFriendRequest(friendId), {
		onSuccess: async () => {
			await queryClient.invalidateQueries([queryKeyRequest]);
			if (friendId) await queryClient.invalidateQueries([ApiEntityEnum.USER + friendId]);
		},
	});
};

export const useBlockFriendMutation = (friendId: number) => {
	const queryClient = useQueryClient();

	return useMutation([queryKey], async (friendId: number) => await userFriendService.blockFriend(friendId), {
		onSuccess: async () => {
			await queryClient.invalidateQueries([ApiEntityEnum.USER + friendId]);
		},
	});
};

export const useUnblockFriendMutation = (friendId: number) => {
	const queryClient = useQueryClient();

	return useMutation([queryKey], async (friendId: number) => await userFriendService.unblockFriend(friendId), {
		onSuccess: async () => {
			await queryClient.invalidateQueries([ApiEntityEnum.USER + friendId]);
		},
	});
};

export const useDeleteFriendMutation = (friendId: number) => {
	const queryClient = useQueryClient();

	return useMutation([queryKey], async (friendId: number) => await userFriendService.deleteFriend(friendId), {
		onSuccess: async () => {
			await queryClient.invalidateQueries([ApiEntityEnum.USER + friendId]);
		},
	});
};

// SERVICE
import { authService } from '@/services/auth/auth.service';

// UTILS
import { useMutation } from 'react-query';
import { setCookie, deleteCookie } from 'cookies-next';

// REQUEST DTO
import { LoginRequestDto } from '@/services/auth/dto/request/Login.request.dto';
import { SignupRequestDto } from '@/services/auth/dto/request/Signup.request.dto';

// RESPONSE DTO
import { PayloadResponseDto } from '@/services/auth/dto/response/payload.response.dto';
import { AxiosResponseDto } from '@/dto/response/axios/axios.response.dto';

// CONSTANTS
import { ACCESS_TOKEN_KEY, REFRESH_TOKEN_KEY } from '@/constants/jwt.constant';

// ENUM
import { ApiEntityEnum } from '@/utils/axios/api.routes';

const queryKey: string[] = [ApiEntityEnum.AUTH];

export const useLoginMutation = () => {
	return useMutation(queryKey, async (dto: LoginRequestDto) => await authService.login(dto), {
		onSuccess: (response: AxiosResponseDto<PayloadResponseDto>) => {
			const accessToken = response.data.access_token;
			const refreshToken = response.data.refresh_token;

			if (accessToken && refreshToken) {
				setCookie(ACCESS_TOKEN_KEY, accessToken);
				setCookie(REFRESH_TOKEN_KEY, refreshToken);
				window.location.reload();
			}
		},
	});
};

export const useSignupMutation = () => {
	return useMutation(queryKey, async (dto: SignupRequestDto) => await authService.signup(dto), {
		onSuccess: (response: AxiosResponseDto<PayloadResponseDto>) => {
			const accessToken = response.data.access_token;
			const refreshToken = response.data.refresh_token;

			if (accessToken && refreshToken) {
				setCookie(ACCESS_TOKEN_KEY, accessToken);
				setCookie(REFRESH_TOKEN_KEY, refreshToken);
				window.location.reload();
			}
		},
	});
};

export const logout = (): void => {
	deleteCookie(ACCESS_TOKEN_KEY);
	deleteCookie(REFRESH_TOKEN_KEY);
	window.location.reload();
};

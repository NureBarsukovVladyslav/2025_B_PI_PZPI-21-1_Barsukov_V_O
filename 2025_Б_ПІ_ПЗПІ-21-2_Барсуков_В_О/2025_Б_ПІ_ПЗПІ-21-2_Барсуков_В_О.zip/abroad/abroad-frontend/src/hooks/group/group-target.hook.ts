import { useMutation, useQueryClient } from 'react-query';
import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { CreateOrUpdateGroupTargetRequestDto } from '@/services/group/group-target/dto/request/CreateOrUpdateGroupTarget.request.dto';
import { groupTargetService } from '@/services/group/group-target/group-target.service';

export const useCreateOrUpdateGroupTargetMutation = (groupId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[ApiEntityEnum.GROUP_TARGET],
		async (dto: CreateOrUpdateGroupTargetRequestDto) => await groupTargetService.createOrUpdateGroupTarget(dto),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([ApiEntityEnum.GROUP + groupId]);
			},
		},
	);
};

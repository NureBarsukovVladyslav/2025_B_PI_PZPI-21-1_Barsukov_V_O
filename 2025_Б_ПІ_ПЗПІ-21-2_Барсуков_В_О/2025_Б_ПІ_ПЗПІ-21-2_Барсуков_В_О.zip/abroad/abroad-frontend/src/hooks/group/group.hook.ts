import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { useMutation, useQuery, useQueryClient } from 'react-query';
import { groupService } from '@/services/group/group.service';
import { CreateOrUpdateGroupRequestDto } from '@/services/group/dto/request/CreateOrUpdateGroup.request.dto';

const queryKey: string = ApiEntityEnum.GROUP;

export const useGetRecommendationGroupsQuery = () => {
	return useQuery(['group-recommendation'], async () => await groupService.getRecommendationGroups());
};

export const useGetGroupsQuery = () => {
	return useQuery([queryKey], async () => await groupService.getGroups());
};

export const useGetGroupQuery = (groupId: number) => {
	return useQuery([queryKey + groupId], async () => await groupService.getGroup(groupId));
};

export const useCreateGroupMutation = () => {
	const queryClient = useQueryClient();

	return useMutation([queryKey], async (dto: CreateOrUpdateGroupRequestDto) => await groupService.createGroup(dto), {
		onSuccess: async () => {
			await queryClient.invalidateQueries([queryKey]);
		},
	});
};

export const useUpdateGroupMutation = (groupId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[queryKey + groupId],
		async (dto: CreateOrUpdateGroupRequestDto) => await groupService.updateGroup(groupId, dto),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([queryKey + groupId]);
			},
		},
	);
};

export const useDeleteGroupMutation = (groupId: number) => {
	const queryClient = useQueryClient();

	return useMutation([queryKey + groupId], async (groupId: number) => await groupService.deleteGroup(groupId), {
		onSuccess: async () => {
			await queryClient.invalidateQueries([queryKey + groupId]);
		},
	});
};

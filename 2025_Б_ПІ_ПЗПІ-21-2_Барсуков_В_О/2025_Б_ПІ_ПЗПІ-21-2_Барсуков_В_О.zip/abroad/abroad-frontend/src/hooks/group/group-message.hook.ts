import { useMutation, useQueryClient } from 'react-query';
import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { CreateGroupMessageRequestDto } from '@/services/group/group-message/dto/request/CreateGroupMessage.request.dto';
import { groupMessageService } from '@/services/group/group-message/group-message.service';

export const useCreateGroupMessageMutation = (groupId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[ApiEntityEnum.GROUP_MESSAGE],
		async (dto: CreateGroupMessageRequestDto) => await groupMessageService.createGroupMessage(groupId, dto),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([ApiEntityEnum.GROUP + groupId]);
			},
		},
	);
};

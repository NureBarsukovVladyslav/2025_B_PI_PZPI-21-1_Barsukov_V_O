import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { useMutation, useQueryClient } from 'react-query';
import { CreateGroupLanguageRequestDto } from '@/services/group/group-language/dto/request/CreateGroupLanguage.request.dto';
import { groupLanguageService } from '@/services/group/group-language/group-language.service';

export const useCreateGroupLanguageMutation = (groupId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[ApiEntityEnum.GROUP_LANGUAGE],
		async (dto: CreateGroupLanguageRequestDto) => await groupLanguageService.createGroupLanguage(dto),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([ApiEntityEnum.GROUP + groupId]);
			},
		},
	);
};

export const useDeleteGroupLanguageMutation = (groupId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[ApiEntityEnum.GROUP_LANGUAGE],
		async (groupLanguageId: number) => await groupLanguageService.deleteGroupLanguage(groupLanguageId),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([ApiEntityEnum.GROUP + groupId]);
			},
		},
	);
};

import { useMutation, useQueryClient } from 'react-query';
import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { groupUserService } from '@/services/group/group-user/group-user.service';
import { DeleteGroupUserRequestDto } from '@/services/group/group-user/dto/request/DeleteGroupUser.request.dto';

export const useAddGroupUserMutation = (groupId?: number) => {
	const queryClient = useQueryClient();

	return useMutation([ApiEntityEnum.GROUP_USER], async (groupId: number) => await groupUserService.addGroupUser(groupId), {
		onSuccess: async () => {
			if (groupId) await queryClient.invalidateQueries([ApiEntityEnum.GROUP + groupId]);
			else await queryClient.invalidateQueries([ApiEntityEnum.GROUP]);
		},
	});
};

export const useLeaveGroupUserMutation = (groupId?: number, key?: string) => {
	const queryClient = useQueryClient();

	return useMutation([ApiEntityEnum.GROUP_USER], async (groupId: number) => await groupUserService.leaveGroupUser(groupId), {
		onSuccess: async () => {
			if (key) await queryClient.invalidateQueries([key]);
			else if (groupId) await queryClient.invalidateQueries([ApiEntityEnum.GROUP + groupId]);
			else await queryClient.invalidateQueries([ApiEntityEnum.GROUP]);
		},
	});
};

export const useDeleteGroupUserMutation = (groupId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[ApiEntityEnum.GROUP_USER],
		async (dto: DeleteGroupUserRequestDto) => await groupUserService.deleteGroupUser(groupId, dto),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([ApiEntityEnum.GROUP + groupId]);
			},
		},
	);
};

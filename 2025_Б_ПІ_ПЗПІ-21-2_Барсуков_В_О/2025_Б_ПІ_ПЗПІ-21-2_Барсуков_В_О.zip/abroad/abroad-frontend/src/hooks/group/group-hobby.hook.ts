import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { useMutation, useQueryClient } from 'react-query';
import { CreateOrUpdateGroupHobbyRequestDto } from '@/services/group/group-hobby/dto/request/CreateOrUpdateGroupHobby.request.dto';
import { groupHobbyService } from '@/services/group/group-hobby/group-hobby.service';

export const useCreateOrUpdateGroupHobbyMutation = (groupId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[ApiEntityEnum.GROUP_HOBBY],
		async (dto: CreateOrUpdateGroupHobbyRequestDto) => await groupHobbyService.createOrUpdateGroupHobby(dto),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([ApiEntityEnum.GROUP + groupId]);
			},
		},
	);
};

import { useMutation, useQueryClient } from 'react-query';
import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { eventGroupService } from '@/services/event/event-group/event-group.service';
import { SubscribeOrUnsubscribeEventGroupRequestDto } from '@/services/event/event-group/dto/request/SubscribeOrUnsubscribeEventGroup.request.dto';

export const useSubscribeEventGroupMutation = (groupId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[ApiEntityEnum.EVENT_GROUP],
		async ({ eventId, dto }: { eventId: number; dto: SubscribeOrUnsubscribeEventGroupRequestDto }) =>
			await eventGroupService.subscribeEventGroup(eventId, dto),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([ApiEntityEnum.GROUP + groupId]);
			},
		},
	);
};

export const useUnsubscribeEventGroupMutation = (groupId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[ApiEntityEnum.EVENT_GROUP],
		async ({ eventId, dto }: { eventId: number; dto: SubscribeOrUnsubscribeEventGroupRequestDto }) =>
			await eventGroupService.unsubscribeEventGroup(eventId, dto),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([ApiEntityEnum.GROUP + groupId]);
			},
		},
	);
};

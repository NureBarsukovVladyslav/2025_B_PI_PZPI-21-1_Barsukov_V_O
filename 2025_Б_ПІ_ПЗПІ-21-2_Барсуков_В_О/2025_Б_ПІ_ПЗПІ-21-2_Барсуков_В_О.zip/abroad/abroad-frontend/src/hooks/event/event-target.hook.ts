import { useMutation, useQueryClient } from 'react-query';
import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { CreateOrUpdateEventTargetRequestDto } from '@/services/event/event-target/dto/request/CreateOrUpdateEventTarget.request.dto';
import { eventTargetService } from '@/services/event/event-target/event-target.service';

export const useCreateOrUpdateEventTargetMutation = (eventId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[ApiEntityEnum.EVENT_TARGET],
		async (dto: CreateOrUpdateEventTargetRequestDto) => await eventTargetService.createOrUpdateEventTarget(dto),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([ApiEntityEnum.EVENT + eventId]);
			},
		},
	);
};

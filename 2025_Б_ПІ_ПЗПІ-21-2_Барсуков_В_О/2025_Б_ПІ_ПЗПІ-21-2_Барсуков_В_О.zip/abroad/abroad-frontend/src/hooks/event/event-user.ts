import { useMutation, useQueryClient } from 'react-query';
import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { eventUserService } from '@/services/event/event-user/event-user.service';

export const useSubscribeEventUserMutation = (eventId: number) => {
	const queryClient = useQueryClient();

	return useMutation([ApiEntityEnum.EVENT_USER], async (eventId: number) => await eventUserService.subscribeEventUser(eventId), {
		onSuccess: async () => {
			await queryClient.invalidateQueries([ApiEntityEnum.EVENT + eventId]);
		},
	});
};

export const useUnsubscribeEventUserMutation = (eventId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[ApiEntityEnum.EVENT_USER],
		async (eventId: number) => await eventUserService.unsubscribeEventUser(eventId),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([ApiEntityEnum.EVENT + eventId]);
			},
		},
	);
};

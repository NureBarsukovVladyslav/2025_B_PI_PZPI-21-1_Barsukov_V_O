import { useMutation, useQuery, useQueryClient } from 'react-query';
import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { eventService } from '@/services/event/event.service';
import { CreateOrUpdateEventRequestDto } from '@/services/event/dto/request/CreateOrUpdateEvent.request.dto';

export const useGetEventsQuery = () => {
	return useQuery([ApiEntityEnum.EVENT], async () => await eventService.getEvents());
};

export const useGetEventQuery = (eventId: number) => {
	return useQuery([ApiEntityEnum.EVENT + eventId], async () => await eventService.getEvent(eventId));
};

export const useCreateEventMutation = () => {
	const queryClient = useQueryClient();

	return useMutation([ApiEntityEnum.EVENT], async (dto: CreateOrUpdateEventRequestDto) => await eventService.createEvent(dto), {
		onSuccess: async () => {
			await queryClient.invalidateQueries([ApiEntityEnum.EVENT]);
		},
	});
};

export const useUpdateEventMutation = (eventId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[ApiEntityEnum.EVENT + eventId],
		async (dto: CreateOrUpdateEventRequestDto) => await eventService.updateEvent(eventId, dto),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([ApiEntityEnum.EVENT + eventId]);
			},
		},
	);
};

export const useDeleteEventMutation = (eventId: number) => {
	const queryClient = useQueryClient();

	return useMutation([ApiEntityEnum.EVENT + eventId], async (eventId: number) => await eventService.deleteEvent(eventId), {
		onSuccess: async () => {
			await queryClient.invalidateQueries([ApiEntityEnum + eventId]);
		},
	});
};

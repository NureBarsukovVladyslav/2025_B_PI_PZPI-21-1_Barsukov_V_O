import { ApiEntityEnum } from '@/utils/axios/api.routes';
import { useMutation, useQuery, useQueryClient } from 'react-query';
import { articleService } from '@/services/article/article.service';
import { CreateOrUpdateArticleRequestDto } from '@/services/article/dto/request/CreateOrUpdateArticle.request.dto';

const queryKey: string = ApiEntityEnum.ARTICLE;

export const useGetArticlesQuery = () => {
	return useQuery([queryKey], async () => await articleService.getArticles());
};

export const useGetArticleQuery = (articleId: number) => {
	return useQuery([queryKey + articleId], async () => await articleService.getArticle(articleId));
};

export const useCreateArticleMutation = () => {
	const queryClient = useQueryClient();

	return useMutation([queryKey], async (dto: CreateOrUpdateArticleRequestDto) => await articleService.createArticle(dto), {
		onSuccess: async () => {
			await queryClient.invalidateQueries([queryKey]);
		},
	});
};

export const useUpdateArticleMutation = (articleId: number) => {
	const queryClient = useQueryClient();

	return useMutation(
		[queryKey + articleId],
		async (dto: CreateOrUpdateArticleRequestDto) => await articleService.updateArticle(articleId, dto),
		{
			onSuccess: async () => {
				await queryClient.invalidateQueries([queryKey + articleId]);
			},
		},
	);
};

export const useDeleteArticleMutation = (articleId: number) => {
	const queryClient = useQueryClient();

	return useMutation([queryKey + articleId], async (articleId: number) => await articleService.deleteArticle(articleId), {
		onSuccess: async () => {
			await queryClient.invalidateQueries([queryKey + articleId]);
		},
	});
};

'use client';

// INTERFACES
import { JSX } from 'react';

interface InputGroupProps {
	children: JSX.Element | JSX.Element[];
	className?: string;
}

const InputGroup = ({ children, className }: InputGroupProps): JSX.Element => {
	return <div className={`w-full flex flex-row gap-3 align-center justify-center ${className || ''}`}>{children}</div>;
};

export default InputGroup;

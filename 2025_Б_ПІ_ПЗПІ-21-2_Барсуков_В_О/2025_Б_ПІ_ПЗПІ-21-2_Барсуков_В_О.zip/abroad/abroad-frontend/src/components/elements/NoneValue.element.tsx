'use client';

import { JSX } from 'react';

const NoneValue = (): JSX.Element => {
	return <span className="text-sm text-danger italic">none</span>;
};

export default NoneValue;

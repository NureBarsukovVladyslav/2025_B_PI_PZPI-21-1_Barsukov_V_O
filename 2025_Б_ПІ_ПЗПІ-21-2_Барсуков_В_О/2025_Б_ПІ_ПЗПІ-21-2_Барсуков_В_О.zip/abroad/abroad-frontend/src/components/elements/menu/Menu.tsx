'use client';

import { JSX } from 'react';
import { Button } from '@heroui/react';
import { MenuConfig } from '@/components/elements/menu/Menu.config';
import Link from 'next/link';
import { IconArrowsDiff, IconLogout } from '@tabler/icons-react';
import { logout } from '@/hooks/auth.hook';
import { BtnColorStyle } from '@/constants/btn.constant';
import { getCookie } from 'cookies-next';
import { ACCESS_TOKEN_KEY } from '@/constants/jwt.constant';
import { AccessTokenPayload } from '@/middleware';
import { jwtDecode } from 'jwt-decode';

const Menu = (): JSX.Element => {
	const accessToken = getCookie(ACCESS_TOKEN_KEY) || '';
	const user: AccessTokenPayload = jwtDecode(accessToken);
	const linkToProfile = `/${user.userId || 0}`;

	return (
		<div className="flex flex-col w-52 gap-2">
			<div className="flex flex-row items-center justify-center gap-1">
				<h1 className="text-xl font-medium">Connect Abroad</h1>
				<IconArrowsDiff className="text-blue-400" size={24} />
			</div>
			{MenuConfig.map((config) => (
				<Button
					key={config.key}
					as={Link}
					href={config.key === 'profile' ? config.link + linkToProfile : config.link}
					variant="flat"
					className={`${BtnColorStyle.slate} flex items-center justify-center gap-2`}
				>
					<config.Icon size={16} />
					<span className="w-10 leading-0">{config.label}</span>
				</Button>
			))}
			<Button variant="flat" className={`${BtnColorStyle.slate} flex items-center justify-center gap-2`} onPress={logout}>
				<IconLogout size={16} />
				<span className="w-10 leading-0">Log out</span>
			</Button>
		</div>
	);
};

export default Menu;

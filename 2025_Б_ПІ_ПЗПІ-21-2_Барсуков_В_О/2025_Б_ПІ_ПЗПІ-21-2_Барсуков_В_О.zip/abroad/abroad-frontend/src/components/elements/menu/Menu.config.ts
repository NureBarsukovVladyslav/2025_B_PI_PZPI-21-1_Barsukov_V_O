import { ROUTES } from '@/routes/routes';
import {
	Icon,
	IconCalendarEvent,
	IconFriends,
	IconHome,
	IconNews,
	IconUsers,
	IconUsersGroup,
	IconUserSquareRounded,
} from '@tabler/icons-react';

interface IMenuConfig {
	key: string;
	label: string;
	link: string;
	Icon: Icon;
}

export const MenuConfig: IMenuConfig[] = [
	{
		key: 'profile',
		label: 'Profile',
		link: ROUTES.USERS,
		Icon: IconUserSquareRounded,
	},
	{
		key: 'my-friends',
		label: 'My Friends',
		link: ROUTES.MY_FRIENDS,
		Icon: IconFriends,
	},
	{
		key: 'my-groups',
		label: 'My Groups',
		link: ROUTES.MY_GROUPS,
		Icon: IconUsersGroup,
	},
	{
		key: 'users',
		label: 'Users',
		link: ROUTES.USERS,
		Icon: IconUsers,
	},
	{
		key: 'groups',
		label: 'Groups',
		link: ROUTES.GROUPS,
		Icon: IconUsersGroup,
	},
	{
		key: 'events',
		label: 'Events',
		link: ROUTES.EVENTS,
		Icon: IconCalendarEvent,
	},
	{
		key: 'articles',
		label: 'Articles',
		link: ROUTES.ARTICLES,
		Icon: IconNews,
	},
];

import { CreateUserLanguageRequestDto } from '@/services/user/user-language/dto/request/CreateUserLanguage.request.dto';
import { api } from '@/utils/axios/api';
import { USER_LANGUAGE_ROUTES } from '@/utils/axios/routes/user/user-language.routes';

class UserLanguageService {
	async createUserLanguage(dto: CreateUserLanguageRequestDto) {
		return await api.post(USER_LANGUAGE_ROUTES.createUserLanguage, dto);
	}

	async deleteUserLanguage(userLanguageId: number) {
		return await api.delete(USER_LANGUAGE_ROUTES.deleteUserLanguage + userLanguageId);
	}
}

export const userLanguageService = new UserLanguageService();

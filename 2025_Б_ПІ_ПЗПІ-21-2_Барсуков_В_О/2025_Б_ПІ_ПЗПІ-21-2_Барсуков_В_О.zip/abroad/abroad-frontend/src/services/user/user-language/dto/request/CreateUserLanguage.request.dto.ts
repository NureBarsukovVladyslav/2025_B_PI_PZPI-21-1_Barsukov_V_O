import { LevelOfLanguage } from '@/enum/LevelOfLanguage.enum';

export interface CreateUserLanguageRequestDto {
	language: string;
	levelOfLanguage: LevelOfLanguage;
	isBasic: boolean;
}

import { Hobby } from '@/enum/Hobby.enum';

export interface CreateOrUpdateUserHobbyRequestDto {
	hobbies: Hobby[];
}

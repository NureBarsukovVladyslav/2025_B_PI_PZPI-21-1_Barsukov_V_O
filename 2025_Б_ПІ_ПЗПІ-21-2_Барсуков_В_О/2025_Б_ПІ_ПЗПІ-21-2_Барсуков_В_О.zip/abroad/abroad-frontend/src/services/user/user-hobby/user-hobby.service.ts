import { CreateOrUpdateUserHobbyRequestDto } from '@/services/user/user-hobby/dto/request/CreateOrUpdateUserHobby.request.dto';
import { api } from '@/utils/axios/api';
import { USER_HOBBY_ROUTES } from '@/utils/axios/routes/user/user-hobby.routes';

class UserHobbyService {
	async createOrUpdateUserHobbies(dto: CreateOrUpdateUserHobbyRequestDto) {
		return await api.post(USER_HOBBY_ROUTES.createOrUpdateHobbies, dto);
	}
}

export const userHobbyService = new UserHobbyService();

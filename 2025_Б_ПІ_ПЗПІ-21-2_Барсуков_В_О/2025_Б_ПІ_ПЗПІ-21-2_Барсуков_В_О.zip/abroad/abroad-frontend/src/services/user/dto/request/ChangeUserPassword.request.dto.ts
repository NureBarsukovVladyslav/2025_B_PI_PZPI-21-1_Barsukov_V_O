export interface ChangeUserPasswordRequestDto {
	password: string;
}

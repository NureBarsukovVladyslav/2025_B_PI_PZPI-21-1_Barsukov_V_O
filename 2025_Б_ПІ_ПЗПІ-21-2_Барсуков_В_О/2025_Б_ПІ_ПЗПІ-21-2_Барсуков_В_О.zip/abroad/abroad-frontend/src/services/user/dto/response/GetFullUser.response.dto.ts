import { TypeOfGender } from '@/enum/TypeOfGender.enum';
import { StatusOfStay } from '@/enum/StatusOfStay.enum';
import { StatusOfUser } from '@/enum/StatusOfUser.enum';
import { StatusOfVisibility } from '@/enum/StatusOfVisibility.enum';
import { LevelOfLanguage } from '@/enum/LevelOfLanguage.enum';
import { Hobby } from '@/enum/Hobby.enum';
import { Target } from '@/enum/Target.enum';

interface SelectUserLanguageResponseDto {
	userLanguageId: number;
	language: string;
	levelOfLanguage: LevelOfLanguage;
	isBasic: boolean;
}

interface SelectUserHobbyResponseDto {
	userHobbyId: number;
	hobby: Hobby;
}

interface SelectUserTargetResponseDto {
	userTargetId: number;
	target: Target;
}

interface SelectUserAuthorEventResponseDto {
	eventId: number;
	nameOfEvent: string;
	dateOfEvent: string;
	timeStart: string;
	timeEnd: string;
	country: string;
	city: string;
	address: string;
	targets: {
		eventTargetId: number;
		target: Target;
	}[];
}

interface SelectUserGroupResponseDto {
	groupUserId: number;
	group: {
		groupId: number;
		nameOfGroup: string;
		avatar: string | null;
	};
}

export interface GetFullUserResponseDto {
	userId: number;
	name: string;
	surname: string;
	email: string;
	gender: TypeOfGender;
	avatar: string | null;
	dateOfBirth: string | null;
	country: string;
	city: string;
	goalOfUser: string | null;
	dateOfArrival: string | null;
	statusOfStay: StatusOfStay | null;
	statusOfUser: StatusOfUser | null;
	statusOfVisibility: StatusOfVisibility;
	isFriend: boolean;
	isFriendPending: boolean;
	isFriendBlock: boolean;
	languages: SelectUserLanguageResponseDto[];
	hobbies: SelectUserHobbyResponseDto[];
	targets: SelectUserTargetResponseDto[];
	authorEvents: SelectUserAuthorEventResponseDto[];
	groups: SelectUserGroupResponseDto[];
}

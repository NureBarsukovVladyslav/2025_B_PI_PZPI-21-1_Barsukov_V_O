import { TypeOfGender } from '@/enum/TypeOfGender.enum';
import { StatusOfStay } from '@/enum/StatusOfStay.enum';
import { StatusOfUser } from '@/enum/StatusOfUser.enum';
import { StatusOfVisibility } from '@/enum/StatusOfVisibility.enum';

export interface UpdateUserRequestDto {
	name: string;
	surname: string;
	gender: TypeOfGender;
	email: string;
	dateOfBirth: string | null;
	country: string;
	city: string;
	dateOfArrival: string | null;
	goalOfUser: string | null;
	statusOfStay: StatusOfStay | null;
	statusOfUser: StatusOfUser | null;
	statusOfVisibility: StatusOfVisibility;
}

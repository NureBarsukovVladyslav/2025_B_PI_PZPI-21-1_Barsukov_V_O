import { LevelOfLanguage } from '@/enum/LevelOfLanguage.enum';

interface SelectUserLanguageResponseDto {
	userLanguageId: number;
	language: string;
	levelOfLanguage: LevelOfLanguage;
	isBasic: boolean;
}

export interface GetPreviewUserResponseDto {
	userId: number;
	name: string;
	surname: string;
	avatar: string | null;
	dateOfBirth: string | null;
	country: string;
	city: string;
	isFriend: boolean;
	languages: SelectUserLanguageResponseDto[];
}

import { CreateOrUpdateUserTargetRequestDto } from '@/services/user/user-target/dto/request/CreateOrUpdateUserTarget.request.dto';
import { USER_TARGET_ROUTES } from '@/utils/axios/routes/user/user-target.routes';
import { api } from '@/utils/axios/api';

class UserTargetService {
	async createOrUpdateUserTargets(dto: CreateOrUpdateUserTargetRequestDto) {
		return await api.post(USER_TARGET_ROUTES.createOrUpdateTargets, dto);
	}
}

export const userTargetService = new UserTargetService();

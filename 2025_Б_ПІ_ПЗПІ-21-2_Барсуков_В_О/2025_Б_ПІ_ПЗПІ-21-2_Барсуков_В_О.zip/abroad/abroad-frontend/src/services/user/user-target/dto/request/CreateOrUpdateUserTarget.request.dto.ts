import { Target } from '@/enum/Target.enum';

export interface CreateOrUpdateUserTargetRequestDto {
	targets: Target[];
}

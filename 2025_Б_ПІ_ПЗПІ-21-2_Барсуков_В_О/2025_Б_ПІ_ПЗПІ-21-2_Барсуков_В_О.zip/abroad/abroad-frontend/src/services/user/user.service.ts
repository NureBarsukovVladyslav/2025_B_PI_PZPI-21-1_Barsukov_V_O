import { api } from '@/utils/axios/api';
import { GetPreviewUserResponseDto } from '@/services/user/dto/response/GetPreviewUser.response.dto';
import { USER_ROUTES } from '@/utils/axios/routes/user/user.routes';
import { GetFullUserResponseDto } from '@/services/user/dto/response/GetFullUser.response.dto';
import { UpdateUserRequestDto } from '@/services/user/dto/request/UpdateUser.request.dto';
import { ChangeUserPasswordRequestDto } from '@/services/user/dto/request/ChangeUserPassword.request.dto';

class UserService {
	async getRecommendationUsers() {
		const { data } = await api.get(USER_ROUTES.getRecommendationUsers);
		return data;
	}

	async getUsers() {
		const { data } = await api.get<GetPreviewUserResponseDto[]>(USER_ROUTES.getUsers);
		return data;
	}

	async getUser(userId: number) {
		const { data } = await api.get<GetFullUserResponseDto>(USER_ROUTES.getUser + userId);
		return data;
	}

	async updateUser(dto: UpdateUserRequestDto) {
		return await api.put(USER_ROUTES.updateUser, dto);
	}

	async changeUserPassword(dto: ChangeUserPasswordRequestDto) {
		return await api.patch(USER_ROUTES.changeUserPassword, dto);
	}
}

export const userService = new UserService();

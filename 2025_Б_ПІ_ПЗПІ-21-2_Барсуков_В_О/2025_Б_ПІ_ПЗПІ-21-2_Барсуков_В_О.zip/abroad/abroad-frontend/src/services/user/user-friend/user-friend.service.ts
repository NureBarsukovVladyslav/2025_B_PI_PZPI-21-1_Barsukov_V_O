import { api } from '@/utils/axios/api';
import { GetUserFriendResponseDto } from '@/services/user/user-friend/dto/response/GetUserFriend.response.dto';
import { USER_FRIEND_ROUTES } from '@/utils/axios/routes/user/user-friend.routes';
import { GetUserFriendMessagesResponseDto } from '@/services/user/user-friend/dto/response/GetUserFriendMessages.response.dto';
import { CreateFriendMessageRequestDto } from '@/services/user/user-friend/dto/request/CreateFriendMessage.request.dto';

class UserFriendService {
	async getFriends() {
		const { data } = await api.get<GetUserFriendResponseDto[]>(USER_FRIEND_ROUTES.getFriends);
		return data;
	}

	async getFriendsRequest() {
		const { data } = await api.get<GetUserFriendResponseDto[]>(USER_FRIEND_ROUTES.getFriendsRequest);
		return data;
	}

	async getFriendMessages(friendId: number) {
		const { data } = await api.get<GetUserFriendMessagesResponseDto[]>(USER_FRIEND_ROUTES.getFriendMessages + friendId);
		return data;
	}

	async createFriendMessage(friendId: number, dto: CreateFriendMessageRequestDto) {
		return await api.patch(USER_FRIEND_ROUTES.createFriendMessage + friendId, dto);
	}

	async makeFriend(friendId: number) {
		return await api.patch(USER_FRIEND_ROUTES.makeFriend + friendId);
	}

	async acceptFriendRequest(friendId: number) {
		return await api.patch(USER_FRIEND_ROUTES.acceptFriendRequest + friendId);
	}

	async rejectFriendRequest(friendId: number) {
		return await api.patch(USER_FRIEND_ROUTES.rejectFriendRequest + friendId);
	}

	async blockFriend(friendId: number) {
		return await api.patch(USER_FRIEND_ROUTES.blockFriend + friendId);
	}

	async unblockFriend(friendId: number) {
		return await api.patch(USER_FRIEND_ROUTES.unblockFriend + friendId);
	}

	async deleteFriend(friendId: number) {
		return await api.delete(USER_FRIEND_ROUTES.deleteFriend + friendId);
	}
}

export const userFriendService = new UserFriendService();

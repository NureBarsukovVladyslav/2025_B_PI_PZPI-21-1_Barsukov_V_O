export interface GetUserFriendResponseDto {
	userId: number;
	name: string;
	surname: string;
	avatar: string | null;
}

export interface CreateFriendMessageRequestDto {
	textOfMessage: string;
}

export interface GetUserFriendMessagesResponseDto {
	userFriendChatId: number;
	userFriendId: number;
	userId: number;
	textOfMessage: string;
	updateAt: string;
	createdAt: string;
}

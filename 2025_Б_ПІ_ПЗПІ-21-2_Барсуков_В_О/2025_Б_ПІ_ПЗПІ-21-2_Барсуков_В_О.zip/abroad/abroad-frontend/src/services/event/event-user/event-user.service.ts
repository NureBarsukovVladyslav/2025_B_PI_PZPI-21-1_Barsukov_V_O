import { api } from '@/utils/axios/api';
import { EVENT_USER_ROUTES } from '@/utils/axios/routes/event/event-user.routes';

class EventUserService {
	async subscribeEventUser(eventId: number) {
		return await api.patch(EVENT_USER_ROUTES.subscribeEvent + eventId);
	}

	async unsubscribeEventUser(eventId: number) {
		return await api.patch(EVENT_USER_ROUTES.unsubscribeEvent + eventId);
	}
}

export const eventUserService = new EventUserService();

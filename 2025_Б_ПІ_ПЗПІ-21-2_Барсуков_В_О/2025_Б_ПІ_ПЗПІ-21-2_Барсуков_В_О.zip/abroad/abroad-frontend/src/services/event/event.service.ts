import { api } from '@/utils/axios/api';
import { GetPreviewEventResponseDto } from '@/services/event/dto/response/GetPreviewEvent.response.dto';
import { EVENT_ROUTES } from '@/utils/axios/routes/event/event.routes';
import { GetFullEventResponseDto } from '@/services/event/dto/response/GetFullEvent.response.dto';
import { CreateOrUpdateEventRequestDto } from '@/services/event/dto/request/CreateOrUpdateEvent.request.dto';

class EventService {
	async getEvents() {
		const { data } = await api.get<GetPreviewEventResponseDto[]>(EVENT_ROUTES.getEvents);
		return data;
	}

	async getEvent(eventId: number) {
		const { data } = await api.get<GetFullEventResponseDto>(EVENT_ROUTES.getEvent + eventId);
		return data;
	}

	async createEvent(dto: CreateOrUpdateEventRequestDto) {
		return await api.post(EVENT_ROUTES.createEvent, dto);
	}

	async updateEvent(eventId: number, dto: CreateOrUpdateEventRequestDto) {
		return await api.put(EVENT_ROUTES.updateEvent + eventId, dto);
	}

	async deleteEvent(eventId: number) {
		return await api.delete(EVENT_ROUTES.deleteEvent + eventId);
	}
}

export const eventService = new EventService();

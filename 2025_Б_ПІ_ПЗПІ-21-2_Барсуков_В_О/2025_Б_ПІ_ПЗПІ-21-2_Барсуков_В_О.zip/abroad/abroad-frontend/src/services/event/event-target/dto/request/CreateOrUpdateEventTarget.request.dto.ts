import { Target } from '@/enum/Target.enum';

export interface CreateOrUpdateEventTargetRequestDto {
	eventId: number;
	targets: Target[];
}

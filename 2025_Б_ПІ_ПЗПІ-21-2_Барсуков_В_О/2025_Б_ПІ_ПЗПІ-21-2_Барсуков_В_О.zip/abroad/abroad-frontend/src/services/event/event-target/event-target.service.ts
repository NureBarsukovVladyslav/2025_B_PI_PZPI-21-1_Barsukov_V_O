import { CreateOrUpdateEventTargetRequestDto } from '@/services/event/event-target/dto/request/CreateOrUpdateEventTarget.request.dto';
import { EVENT_TARGET_ROUTES } from '@/utils/axios/routes/event/event-target.routes';
import { api } from '@/utils/axios/api';

class EventTargetService {
	async createOrUpdateEventTarget(dto: CreateOrUpdateEventTargetRequestDto) {
		return await api.post(EVENT_TARGET_ROUTES.createOrUpdateTargets, dto);
	}
}

export const eventTargetService = new EventTargetService();

import { Target } from '@/enum/Target.enum';

export interface GetFullEventResponseDto {
	eventId: number;
	nameOfEvent: string;
	description: string;
	dateOfEvent: string;
	timeStart: string;
	timeEnd: string;
	country: string;
	city: string;
	address: string;
	isOwner: boolean;
	isParticipant: boolean;
	users: {
		eventUserId: number;
		user: {
			userId: number;
			name: string;
			surname: string;
			avatar: string | null;
		};
	}[];
	targets: {
		eventTargetId: number;
		target: Target;
	}[];
	groups: {
		groupEventId: number;
		group: {
			groupId: number;
			nameOfGroup: string;
			avatar: string | null;
		};
	}[];
	author: {
		userId: number;
		name: string;
		surname: string;
		avatar: string | null;
	};
}

import { Target } from '@/enum/Target.enum';

export interface GetPreviewEventResponseDto {
	eventId: number;
	nameOfEvent: string;
	dateOfEvent: string;
	timeStart: string;
	timeEnd: string;
	country: string;
	city: string;
	address: string;
	targets: {
		eventTargetId: number;
		target: Target;
	}[];
	groups: {
		groupEventId: number;
		group: {
			groupId: number;
			nameOfGroup: string;
			avatar: string | null;
		};
	}[];
}

export interface CreateOrUpdateEventRequestDto {
	nameOfEvent: string;
	description: string;
	dateOfEvent: string;
	timeStart: string;
	timeEnd: string;
	country: string;
	city: string;
	address: string;
}

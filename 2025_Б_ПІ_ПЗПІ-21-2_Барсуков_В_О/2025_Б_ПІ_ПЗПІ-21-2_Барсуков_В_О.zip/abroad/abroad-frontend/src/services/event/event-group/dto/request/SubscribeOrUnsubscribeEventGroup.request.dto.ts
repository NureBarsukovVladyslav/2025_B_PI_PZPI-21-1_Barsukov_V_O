export interface SubscribeOrUnsubscribeEventGroupRequestDto {
	groupId: number;
}

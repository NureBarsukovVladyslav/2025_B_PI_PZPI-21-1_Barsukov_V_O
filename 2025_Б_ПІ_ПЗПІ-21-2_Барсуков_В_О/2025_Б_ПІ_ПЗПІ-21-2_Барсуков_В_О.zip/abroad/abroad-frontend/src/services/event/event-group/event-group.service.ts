import { api } from '@/utils/axios/api';
import { EVENT_GROUP_ROUTES } from '@/utils/axios/routes/event/event-group.routes';
import { SubscribeOrUnsubscribeEventGroupRequestDto } from '@/services/event/event-group/dto/request/SubscribeOrUnsubscribeEventGroup.request.dto';

class EventGroupService {
	async subscribeEventGroup(eventId: number, dto: SubscribeOrUnsubscribeEventGroupRequestDto) {
		return await api.patch(EVENT_GROUP_ROUTES.subscribeEvent + eventId, dto);
	}

	async unsubscribeEventGroup(eventId: number, dto: SubscribeOrUnsubscribeEventGroupRequestDto) {
		return await api.patch(EVENT_GROUP_ROUTES.unsubscribeEvent + eventId, dto);
	}
}

export const eventGroupService = new EventGroupService();

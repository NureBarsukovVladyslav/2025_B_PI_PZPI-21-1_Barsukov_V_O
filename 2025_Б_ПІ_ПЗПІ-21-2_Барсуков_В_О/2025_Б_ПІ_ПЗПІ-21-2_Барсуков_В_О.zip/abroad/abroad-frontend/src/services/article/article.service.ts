import { GetPreviewArticleResponseDto } from '@/services/article/dto/response/GetPreviewArticle.response.dto';
import { ARTICLE_ROUTES } from '@/utils/axios/routes/article.routes';
import { api } from '@/utils/axios/api';
import { GetFullArticleResponseDto } from '@/services/article/dto/response/GetFullArticle.response.dto';
import { CreateOrUpdateArticleRequestDto } from '@/services/article/dto/request/CreateOrUpdateArticle.request.dto';

class ArticleService {
	async getArticles() {
		const { data } = await api.get<GetPreviewArticleResponseDto[]>(ARTICLE_ROUTES.getArticles);
		return data;
	}

	async getArticle(articleId: number) {
		const { data } = await api.get<GetFullArticleResponseDto>(ARTICLE_ROUTES.getArticle + articleId);
		return data;
	}

	async createArticle(dto: CreateOrUpdateArticleRequestDto) {
		return await api.post(ARTICLE_ROUTES.createArticle, dto);
	}

	async updateArticle(articleId: number, dto: CreateOrUpdateArticleRequestDto) {
		return await api.put(ARTICLE_ROUTES.updateArticle + articleId, dto);
	}

	async deleteArticle(articleId: number) {
		return await api.delete(ARTICLE_ROUTES.deleteArticle + articleId);
	}
}

export const articleService = new ArticleService();

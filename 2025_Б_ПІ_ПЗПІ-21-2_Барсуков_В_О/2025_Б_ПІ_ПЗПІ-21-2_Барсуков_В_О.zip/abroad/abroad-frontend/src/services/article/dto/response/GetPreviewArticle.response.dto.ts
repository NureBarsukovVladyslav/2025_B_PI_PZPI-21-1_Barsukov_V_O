import { Target } from '@/enum/Target.enum';
import { StatusOfUser } from '@/enum/StatusOfUser.enum';

interface SelectArticleAuthorResponseDto {
	userId: number;
	name: string;
	surname: string;
	avatar: string | null;
}

export interface GetPreviewArticleResponseDto {
	articleId: number;
	nameOfArticle: string;
	description: string;
	target: Target;
	statusOfUser: StatusOfUser;
	author: SelectArticleAuthorResponseDto;
}

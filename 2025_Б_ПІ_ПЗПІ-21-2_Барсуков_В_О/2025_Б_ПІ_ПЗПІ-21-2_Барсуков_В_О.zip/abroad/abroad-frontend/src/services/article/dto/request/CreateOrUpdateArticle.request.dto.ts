import { StatusOfUser } from '@/enum/StatusOfUser.enum';
import { Target } from '@/enum/Target.enum';

export interface CreateOrUpdateArticleRequestDto {
	nameOfArticle: string;
	description: string;
	content: string;
	email: string | null;
	link: string | null;
	nameOfLink: string | null;
	statusOfUser: StatusOfUser;
	target: Target;
}

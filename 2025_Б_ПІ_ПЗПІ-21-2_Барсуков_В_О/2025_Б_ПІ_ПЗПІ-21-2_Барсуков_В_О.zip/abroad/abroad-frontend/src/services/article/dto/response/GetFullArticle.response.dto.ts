import { Target } from '@/enum/Target.enum';
import { StatusOfUser } from '@/enum/StatusOfUser.enum';

interface SelectArticleAuthorResponseDto {
	userId: number;
	name: string;
	surname: string;
	avatar: string | null;
}

export interface GetFullArticleResponseDto {
	articleId: number;
	nameOfArticle: string;
	description: string;
	content: string;
	email: string;
	link: string;
	nameOfLink: string;
	target: Target;
	statusOfUser: StatusOfUser;
	updatedAt: string;
	createdAt: string;
	author: SelectArticleAuthorResponseDto;
	isOwner: boolean;
}

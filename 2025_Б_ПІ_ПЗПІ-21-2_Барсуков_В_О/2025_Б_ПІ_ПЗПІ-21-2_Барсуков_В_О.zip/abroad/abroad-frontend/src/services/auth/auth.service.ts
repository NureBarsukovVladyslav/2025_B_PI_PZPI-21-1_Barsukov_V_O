// UTIL
import { api } from '@/utils/axios/api';

// ROUTE
import { AUTH_ROUTES } from '@/utils/axios/routes/auth.routes';

// REQUEST DTO
import { LoginRequestDto } from '@/services/auth/dto/request/Login.request.dto';
import { SignupRequestDto } from '@/services/auth/dto/request/Signup.request.dto';

// RESPONSE DTO
import { PayloadResponseDto } from '@/services/auth/dto/response/payload.response.dto';

// COOKIE
import { setCookie } from 'cookies-next';
import { ACCESS_TOKEN_KEY, REFRESH_TOKEN_KEY } from '@/constants/jwt.constant';

class AuthService {
	async login(dto: LoginRequestDto) {
		const { data } = await api.post<PayloadResponseDto>(AUTH_ROUTES.login, dto);
		return data;
	}

	async signup(dto: SignupRequestDto) {
		const { data } = await api.post<PayloadResponseDto>(AUTH_ROUTES.signup, dto);
		return data;
	}

	async refresh() {
		try {
			const { data } = await api.get<PayloadResponseDto>(AUTH_ROUTES.refresh);

			if (data.data?.access_token && data.data?.refresh_token) {
				setCookie(ACCESS_TOKEN_KEY, data.data.access_token);
				setCookie(REFRESH_TOKEN_KEY, data.data.refresh_token);
				return data.data;
			}
		} catch (error) {
			throw error;
		}
	}
}

export const authService = new AuthService();

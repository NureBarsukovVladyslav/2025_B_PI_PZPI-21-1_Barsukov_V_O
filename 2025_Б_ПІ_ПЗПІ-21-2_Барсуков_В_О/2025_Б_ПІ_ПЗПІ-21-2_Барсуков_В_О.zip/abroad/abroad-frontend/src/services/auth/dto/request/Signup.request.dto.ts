import { TypeOfGender } from '@/enum/TypeOfGender.enum';
import { StatusOfStay } from '@/enum/StatusOfStay.enum';
import { StatusOfUser } from '@/enum/StatusOfUser.enum';

export interface SignupRequestDto {
	name: string;
	surname: string;
	gender: TypeOfGender;
	email: string;
	password: string;
	dateOfBirth: string | null;
	country: string;
	city: string;
	dateOfArrival: string | null;
	statusOfStay: StatusOfStay | null;
	statusOfUser: StatusOfUser | null;
	goalOfUser: string | null;
}

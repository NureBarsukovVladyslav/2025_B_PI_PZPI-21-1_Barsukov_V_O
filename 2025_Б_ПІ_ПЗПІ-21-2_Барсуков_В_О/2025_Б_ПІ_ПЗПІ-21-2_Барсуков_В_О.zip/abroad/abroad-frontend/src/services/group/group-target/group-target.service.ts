import { CreateOrUpdateGroupTargetRequestDto } from '@/services/group/group-target/dto/request/CreateOrUpdateGroupTarget.request.dto';
import { api } from '@/utils/axios/api';
import { GROUP_TARGET_ROUTES } from '@/utils/axios/routes/group/group-target.routes';

class GroupTargetService {
	async createOrUpdateGroupTarget(dto: CreateOrUpdateGroupTargetRequestDto) {
		return await api.post(GROUP_TARGET_ROUTES.createOrUpdateTargets, dto);
	}
}

export const groupTargetService = new GroupTargetService();

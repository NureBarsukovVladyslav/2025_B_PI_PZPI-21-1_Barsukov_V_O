import { Target } from '@/enum/Target.enum';

export interface CreateOrUpdateGroupTargetRequestDto {
	groupId: number;
	targets: Target[];
}

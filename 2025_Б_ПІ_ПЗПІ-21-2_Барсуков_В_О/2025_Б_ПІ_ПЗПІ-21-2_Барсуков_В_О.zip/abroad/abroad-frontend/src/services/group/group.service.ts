import { GetPreviewGroupResponseDto } from '@/services/group/dto/response/GetPreviewGroup.response.dto';
import { api } from '@/utils/axios/api';
import { GROUP_ROUTES } from '@/utils/axios/routes/group/group.routes';
import { GetFullGroupResponseDto } from '@/services/group/dto/response/GetFullGroup.response.dto';
import { CreateOrUpdateGroupRequestDto } from '@/services/group/dto/request/CreateOrUpdateGroup.request.dto';

class GroupService {
	async getRecommendationGroups() {
		const { data } = await api.get(GROUP_ROUTES.getRecommendationGroups);
		return data;
	}

	async getGroups() {
		const { data } = await api.get<GetPreviewGroupResponseDto[]>(GROUP_ROUTES.getGroups);
		return data;
	}

	async getGroup(groupId: number) {
		const { data } = await api.get<GetFullGroupResponseDto>(GROUP_ROUTES.getGroup + groupId);
		return data;
	}

	async createGroup(dto: CreateOrUpdateGroupRequestDto) {
		return await api.post(GROUP_ROUTES.createGroup, dto);
	}

	async updateGroup(groupId: number, dto: CreateOrUpdateGroupRequestDto) {
		return await api.put(GROUP_ROUTES.updateGroup + groupId, dto);
	}

	async deleteGroup(groupId: number) {
		return await api.delete(GROUP_ROUTES.deleteGroup + groupId);
	}
}

export const groupService = new GroupService();

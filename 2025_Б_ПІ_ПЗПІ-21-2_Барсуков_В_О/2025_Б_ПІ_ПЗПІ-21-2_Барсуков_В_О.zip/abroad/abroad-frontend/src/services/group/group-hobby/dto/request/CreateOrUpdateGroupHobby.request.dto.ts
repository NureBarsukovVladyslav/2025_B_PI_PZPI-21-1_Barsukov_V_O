import { Hobby } from '@/enum/Hobby.enum';

export interface CreateOrUpdateGroupHobbyRequestDto {
	groupId: number;
	hobbies: Hobby[];
}

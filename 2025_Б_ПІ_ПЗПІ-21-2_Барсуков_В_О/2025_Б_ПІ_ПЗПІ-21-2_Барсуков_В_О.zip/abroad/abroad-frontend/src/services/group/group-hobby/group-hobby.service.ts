import { CreateOrUpdateGroupHobbyRequestDto } from '@/services/group/group-hobby/dto/request/CreateOrUpdateGroupHobby.request.dto';
import { GROUP_HOBBY_ROUTES } from '@/utils/axios/routes/group/group-hobby.routes';
import { api } from '@/utils/axios/api';

class GroupHobbyService {
	async createOrUpdateGroupHobby(dto: CreateOrUpdateGroupHobbyRequestDto) {
		return await api.post(GROUP_HOBBY_ROUTES.createOrUpdateHobbies, dto);
	}
}

export const groupHobbyService = new GroupHobbyService();

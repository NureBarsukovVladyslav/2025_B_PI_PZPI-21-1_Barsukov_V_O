export interface DeleteGroupUserRequestDto {
	groupUserId: number;
}

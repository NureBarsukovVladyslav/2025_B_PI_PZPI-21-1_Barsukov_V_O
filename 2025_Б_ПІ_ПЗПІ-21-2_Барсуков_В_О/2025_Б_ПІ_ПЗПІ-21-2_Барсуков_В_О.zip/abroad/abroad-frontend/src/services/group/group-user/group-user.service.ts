import { api } from '@/utils/axios/api';
import { GROUP_USER_ROUTES } from '@/utils/axios/routes/group/group-user.routes';
import { DeleteGroupUserRequestDto } from '@/services/group/group-user/dto/request/DeleteGroupUser.request.dto';

class GroupUserService {
	async addGroupUser(groupId: number) {
		return await api.patch(GROUP_USER_ROUTES.addGroupUser + groupId);
	}

	async leaveGroupUser(groupId: number) {
		return await api.patch(GROUP_USER_ROUTES.leaveGroupUser + groupId);
	}

	async deleteGroupUser(groupId: number, dto: DeleteGroupUserRequestDto) {
		return await api.patch(GROUP_USER_ROUTES.deleteGroupUser + groupId, dto);
	}
}

export const groupUserService = new GroupUserService();

import { LevelOfLanguage } from '@/enum/LevelOfLanguage.enum';
import { Hobby } from '@/enum/Hobby.enum';
import { Target } from '@/enum/Target.enum';

interface SelectGroupAdminResponseDto {
	userId: number;
	name: string;
	surname: string;
	avatar: string | null;
}

interface SelectGroupEventResponseDto {
	groupEventId: number;
	event: {
		eventId: number;
		nameOfEvent: string;
		description: string;
		dateOfEvent: string;
		timeStart: string;
		timeEnd: string;
		country: string;
		city: string;
		address: string;
		targets: {
			eventTargetId: number;
			target: Target;
		}[];
	};
}

interface SelectGroupUserResponseDto {
	groupUserId: number;
	user: {
		userId: number;
		name: string;
		surname: string;
		avatar: string | null;
	};
}

interface SelectGroupLanguageResponseDto {
	groupLanguageId: number;
	language: string;
	levelOfLanguage: LevelOfLanguage;
}

interface SelectGroupHobbyResponseDto {
	groupHobbyId: number;
	hobby: Hobby;
}

interface SelectGroupTargetResponseDto {
	groupTargetId: number;
	target: Target;
}

interface SelectGroupMessageResponseDto {
	messageId: number;
	user: {
		userId: number;
		name: string;
		surname: string;
		avatar: string | null;
	};
	textOfMessage: string;
}

export interface GetFullGroupResponseDto {
	groupId: number;
	nameOfGroup: string;
	description: string;
	avatar: string | null;
	country: string;
	city: string;
	isParticipant: boolean;
	isOwner: boolean;
	admin: SelectGroupAdminResponseDto;
	events: SelectGroupEventResponseDto[];
	users: SelectGroupUserResponseDto[];
	languages: SelectGroupLanguageResponseDto[];
	hobbies: SelectGroupHobbyResponseDto[];
	targets: SelectGroupTargetResponseDto[];
	messages: SelectGroupMessageResponseDto[];
}

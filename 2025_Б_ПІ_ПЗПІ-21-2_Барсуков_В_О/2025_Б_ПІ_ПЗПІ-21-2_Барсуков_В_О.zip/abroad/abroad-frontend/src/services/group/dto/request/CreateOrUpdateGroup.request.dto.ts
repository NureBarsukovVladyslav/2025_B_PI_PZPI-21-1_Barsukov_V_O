export interface CreateOrUpdateGroupRequestDto {
	nameOfGroup: string;
	description: string;
	country: string;
	city: string;
}

import { LevelOfLanguage } from '@/enum/LevelOfLanguage.enum';
import { Hobby } from '@/enum/Hobby.enum';
import { Target } from '@/enum/Target.enum';

interface SelectGroupUserResponseDto {
	groupUserId: number;
	user: {
		userId: number;
		name: string;
		surname: string;
		avatar: string | null;
	};
}

interface SelectGroupLanguageResponseDto {
	groupLanguageId: number;
	language: string;
	levelOfLanguage: LevelOfLanguage;
}

interface SelectGroupHobbyResponseDto {
	groupHobbyId: number;
	hobby: Hobby;
}

interface SelectGroupTargetResponseDto {
	groupTargetId: number;
	target: Target;
}

export interface GetPreviewGroupResponseDto {
	groupId: number;
	nameOfGroup: string;
	description: string;
	avatar: string | null;
	country: string;
	city: string;
	isParticipant: boolean;
	users: SelectGroupUserResponseDto[];
	languages: SelectGroupLanguageResponseDto[];
	hobbies: SelectGroupHobbyResponseDto[];
	targets: SelectGroupTargetResponseDto[];
}

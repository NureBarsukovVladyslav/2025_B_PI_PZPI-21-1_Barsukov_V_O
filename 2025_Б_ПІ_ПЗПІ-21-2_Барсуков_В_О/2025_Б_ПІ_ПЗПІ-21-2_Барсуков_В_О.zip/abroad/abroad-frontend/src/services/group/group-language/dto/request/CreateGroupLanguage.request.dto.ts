import { LevelOfLanguage } from '@/enum/LevelOfLanguage.enum';

export interface CreateGroupLanguageRequestDto {
	groupId: number;
	language: string;
	levelOfLanguage: LevelOfLanguage;
}

import { CreateGroupLanguageRequestDto } from '@/services/group/group-language/dto/request/CreateGroupLanguage.request.dto';
import { api } from '@/utils/axios/api';
import { GROUP_LANGUAGE_ROUTES } from '@/utils/axios/routes/group/group-language.routes';

class GroupLanguageService {
	async createGroupLanguage(dto: CreateGroupLanguageRequestDto) {
		return await api.post(GROUP_LANGUAGE_ROUTES.createGroupLanguage, dto);
	}

	async deleteGroupLanguage(groupLanguageId: number) {
		return await api.delete(GROUP_LANGUAGE_ROUTES.deleteGroupLanguage + groupLanguageId);
	}
}

export const groupLanguageService = new GroupLanguageService();

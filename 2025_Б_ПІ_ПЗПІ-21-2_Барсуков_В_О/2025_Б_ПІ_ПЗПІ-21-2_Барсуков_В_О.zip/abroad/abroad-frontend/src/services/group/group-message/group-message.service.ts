import { CreateGroupMessageRequestDto } from '@/services/group/group-message/dto/request/CreateGroupMessage.request.dto';
import { GROUP_MESSAGE_ROUTES } from '@/utils/axios/routes/group/group-message.routes';
import { api } from '@/utils/axios/api';

class GroupMessageService {
	async createGroupMessage(groupId: number, dto: CreateGroupMessageRequestDto) {
		return await api.patch(GROUP_MESSAGE_ROUTES.createMessage + groupId, dto);
	}
}

export const groupMessageService = new GroupMessageService();

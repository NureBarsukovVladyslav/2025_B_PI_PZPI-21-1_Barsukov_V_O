export interface CreateGroupMessageRequestDto {
	textOfMessage: string;
}

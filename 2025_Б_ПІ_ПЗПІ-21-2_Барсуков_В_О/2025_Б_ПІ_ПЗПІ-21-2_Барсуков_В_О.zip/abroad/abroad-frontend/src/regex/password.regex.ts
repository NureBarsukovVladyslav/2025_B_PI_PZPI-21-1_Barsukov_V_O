export const PASSWORD_LOWERCASE_REGEX: RegExp = /^(?=.*[a-z])/;
export const PASSWORD_UPPERCASE_REGEX: RegExp = /^(?=.*[A-Z])/;
export const PASSWORD_NUMBER_REGEX: RegExp = /^(?=(.*[0-9]){3,})/;
export const PASSWORD_SYMBOLS_REGEX: RegExp = /^(?=.*[!@#\\$%\\^&\\*])/;

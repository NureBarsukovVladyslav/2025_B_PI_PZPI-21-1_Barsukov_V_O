export interface AxiosResponseDto<T> {
	statusCode: number;
	message: string;
	data: T;
}

export interface AxiosResponseErrorDto {
	statusCode: number;
	message: string | string[];
	error: string;
}

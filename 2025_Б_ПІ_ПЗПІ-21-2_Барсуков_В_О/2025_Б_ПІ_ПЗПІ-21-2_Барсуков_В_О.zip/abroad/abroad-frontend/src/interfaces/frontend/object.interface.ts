export interface IObjectIndex {
	[key: string]: any;
}

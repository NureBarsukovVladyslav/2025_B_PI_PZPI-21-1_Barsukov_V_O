import { IObjectIndex } from '@/interfaces/frontend/object.interface';
import { TypeOfGender } from '@/enum/TypeOfGender.enum';

export const GENDER_TEXT_CONSTANT: IObjectIndex = {
	[TypeOfGender.MALE]: 'Male',
	[TypeOfGender.FEMALE]: 'Female',
};

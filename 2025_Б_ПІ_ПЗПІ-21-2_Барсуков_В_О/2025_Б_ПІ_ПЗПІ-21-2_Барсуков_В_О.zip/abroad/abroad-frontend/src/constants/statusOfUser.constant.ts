import { IObjectIndex } from '@/interfaces/frontend/object.interface';
import { StatusOfUser } from '@/enum/StatusOfUser.enum';

export const STATUS_OF_USER_TEXT_CONSTANT: IObjectIndex = {
	[StatusOfUser.LONELY]: 'Feeling lonely 😔',
	[StatusOfUser.STRESS]: 'Under stress 😣',
	[StatusOfUser.STUDY]: 'Busy with studies 📚',
	[StatusOfUser.WALK]: 'Out for a walk 🚶‍♂️',
	[StatusOfUser.SURPRISE]: 'Feeling surprised 😲',
	[StatusOfUser.ENJOY]: 'Enjoying the moment 😊',
	[StatusOfUser.WORKING]: 'Currently working 💻',
	[StatusOfUser.EXPLORING]: 'Exploring a new place 🌍',
	[StatusOfUser.RELAXING]: 'Taking a break 🧘‍♀️',
	[StatusOfUser.HOMESICK]: 'Missing home 🏠',
	[StatusOfUser.PARTY]: 'Having a party 🎉',
	[StatusOfUser.LOST]: 'Feeling lost 😕',
	[StatusOfUser.NETWORKING]: 'Meeting new people 🤝',
	[StatusOfUser.ADVENTURE]: 'Looking for adventure 🏞️',
};

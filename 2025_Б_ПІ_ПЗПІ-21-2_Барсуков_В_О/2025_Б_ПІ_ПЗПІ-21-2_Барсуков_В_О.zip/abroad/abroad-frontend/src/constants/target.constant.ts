import { IObjectIndex } from '@/interfaces/frontend/object.interface';
import { Target } from '@/enum/Target.enum';

export const TARGET_TEXT_CONSTANT: IObjectIndex = {
	[Target.HELP]: 'Find help 🆘',
	[Target.LANGUAGE_EXCHANGE]: 'Language Exchange 🌍',
	[Target.PART_IN_EVENT]: 'Participate in an Event 🎉',
	[Target.ADAPTATION_TIPS]: 'Adaptation Tips 📝',
	[Target.LEARN_SKILLS]: 'Learn Skills 📚',
	[Target.FIND_JOB]: 'Find a Job 💼',
	[Target.SHARE_EXPERIENCE]: 'Share Experience 📢',
	[Target.NETWORKING]: 'Networking 🤝',
	[Target.JOIN_COMMUNITY]: 'Join Community 🌐',
	[Target.MAKE_FRIENDS]: 'Make Friends 👯‍♂️',
	[Target.PARTICIPATE_IN_DISCUSSIONS]: 'Participate in Discussions 💬',
	[Target.FIND_MENTOR]: 'Find a Mentor 🧑‍🏫',
	[Target.FIND_MOTIVATION]: 'Find Motivation 💪',
	[Target.SHARE_ACHIEVEMENTS]: 'Share Achievements 🏆',
	[Target.SEEK_ADVICE]: 'Seek Advice 🗣️',
	[Target.STAY_CONNECTED]: 'Stay Connected 📱',
};

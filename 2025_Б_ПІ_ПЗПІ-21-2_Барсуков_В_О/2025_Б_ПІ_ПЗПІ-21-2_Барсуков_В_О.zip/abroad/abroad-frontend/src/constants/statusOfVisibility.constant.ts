import { IObjectIndex } from '@/interfaces/frontend/object.interface';
import { StatusOfVisibility } from '@/enum/StatusOfVisibility.enum';

export const STATUS_OF_VISIBILITY_TEXT_CONSTANT: IObjectIndex = {
	[StatusOfVisibility.ALL]: 'All',
	[StatusOfVisibility.FRIEND_ONLY]: 'Only friends',
};

// INTERFACE
interface IBtnColorStyle {
	success: string;
	primary: string;
	slate: string;
	secondary: string;
	danger: string;
}

export const BtnColorStyle: IBtnColorStyle = {
	success: 'text-success-500 bg-success/20 gap-1',
	primary: 'text-blue-500 bg-blue-700/20 gap-1',
	slate: 'text-white bg-zinc-500/20 gap-1',
	secondary: 'text-indigo-500 bg-indigo-500/20 gap-1',
	danger: 'text-danger-500 bg-danger/20 gap-1',
};

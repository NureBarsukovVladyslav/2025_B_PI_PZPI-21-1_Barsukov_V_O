export const AUTH_ERROR = {
	statusCode: 401,
	message: 'Unauthorized',
};

export const AUTH_REFRESH_ERROR = {
	statusCode: 401,
	message: 'Refresh token error',
};

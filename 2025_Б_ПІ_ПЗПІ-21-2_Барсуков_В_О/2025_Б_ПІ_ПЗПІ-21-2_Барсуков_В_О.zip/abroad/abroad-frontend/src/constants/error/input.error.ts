export const INPUT_DATA_TOO_LONG: string = 'Input data is too long';
export const INPUT_DATA_TOO_SHORT: string = 'Input data is too short';
export const INPUT_DATA_IS_REQUIRED: string = 'Input data is required';
export const INPUT_EMAIL_DATA_IS_NOT_CORRECT: string = 'Email is not valid';
export const INPUT_URL_DATA_IS_NOT_CORRECT: string = 'URL is not valid';
export const INPUT_NUMBER_IS_NOT_POSITIVE: string = 'The entered number is less than 0';

export const INPUT_PASSWORD_MUST_LOWERCASE: string = 'Password must contain one lowercase character';
export const INPUT_PASSWORD_MUST_UPPERCASE: string = 'Password must contain one uppercase character';
export const INPUT_PASSWORD_MUST_NUMBER: string = 'Password must contain three number';
export const INPUT_PASSWORD_MUST_SYMBOL: string = 'Password must contain one symbol';
export const INPUT_CONFIRM_PASSWORD_NOT_MATCH: string = 'Passwords must match';

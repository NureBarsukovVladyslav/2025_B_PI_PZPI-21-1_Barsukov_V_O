import { IObjectIndex } from '@/interfaces/frontend/object.interface';
import { StatusOfStay } from '@/enum/StatusOfStay.enum';

export const STATUS_OF_STAY_TEXT_CONSTANT: IObjectIndex = {
	[StatusOfStay.TEMPORARILY]: 'Temporarily',
	[StatusOfStay.FOREVER]: 'Forever',
	[StatusOfStay.LONG_TIME]: 'For a long time',
	[StatusOfStay.CANNOT_ANSWER]: 'Indefinitely',
};

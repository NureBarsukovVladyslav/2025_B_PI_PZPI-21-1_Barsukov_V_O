export enum TypeOfGender {
	MALE = 'MALE',
	FEMALE = 'FEMALE',
}

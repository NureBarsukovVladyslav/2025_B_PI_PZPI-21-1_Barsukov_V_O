export enum StatusOfVisibility {
	ALL = 'ALL',
	FRIEND_ONLY = 'FRIEND_ONLY',
}

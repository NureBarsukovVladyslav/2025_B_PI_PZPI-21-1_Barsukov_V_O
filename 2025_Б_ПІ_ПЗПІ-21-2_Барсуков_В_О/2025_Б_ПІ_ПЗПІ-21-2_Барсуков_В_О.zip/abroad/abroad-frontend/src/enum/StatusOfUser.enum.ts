export enum StatusOfUser {
	LONELY = 'LONELY', // Одинокий
	STRESS = 'STRESS', // В стрессе
	STUDY = 'STUDY', // Учёба
	WALK = 'WALK', // Прогулка
	SURPRISE = 'SURPRISE', // Удивление
	ENJOY = 'ENJOY', // Наслаждение
	WORKING = 'WORKING', // Работаю
	EXPLORING = 'EXPLORING', // Исследую новое место
	RELAXING = 'RELAXING', // Отдыхаю
	HOMESICK = 'HOMESICK', // Скучаю по дому
	PARTY = 'PARTY', // Вечеринка
	LOST = 'LOST', // Потерялся
	NETWORKING = 'NETWORKING', // Знакомлюсь с людьми
	ADVENTURE = 'ADVENTURE', // В поиске приключений
}

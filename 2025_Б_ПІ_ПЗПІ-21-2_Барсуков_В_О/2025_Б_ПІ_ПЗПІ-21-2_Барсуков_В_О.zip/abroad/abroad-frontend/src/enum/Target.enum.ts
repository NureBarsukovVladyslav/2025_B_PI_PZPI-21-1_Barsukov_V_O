export enum Target {
	HELP = 'HELP', // Помощь
	LANGUAGE_EXCHANGE = 'LANGUAGE_EXCHANGE', // Языковой обмен
	PART_IN_EVENT = 'PART_IN_EVENT', // Участие в событии
	ADAPTATION_TIPS = 'ADAPTATION_TIPS', // Советы по адаптации
	LEARN_SKILLS = 'LEARN_SKILLS', // Изучение навыков
	FIND_JOB = 'FIND_JOB', // Поиск работы
	SHARE_EXPERIENCE = 'SHARE_EXPERIENCE', // Обмен опытом
	NETWORKING = 'NETWORKING', // Нетворкинг
	JOIN_COMMUNITY = 'JOIN_COMMUNITY', // Присоединение к сообществу
	MAKE_FRIENDS = 'MAKE_FRIENDS', // Завести друзей
	PARTICIPATE_IN_DISCUSSIONS = 'PARTICIPATE_IN_DISCUSSIONS', // Участие в обсуждениях
	FIND_MENTOR = 'FIND_MENTOR', // Найти наставника
	FIND_MOTIVATION = 'FIND_MOTIVATION', // Поиск мотивации
	SHARE_ACHIEVEMENTS = 'SHARE_ACHIEVEMENTS', // Поделиться достижениями
	SEEK_ADVICE = 'SEEK_ADVICE', // Получить совет
	STAY_CONNECTED = 'STAY_CONNECTED', // Оставаться на связи
}

/** @type {import('next').NextConfig} */
const nextConfig = {
	env: {
		DEV_API_URL: 'http://localhost:3000/api',
	}
};

module.exports = nextConfig;

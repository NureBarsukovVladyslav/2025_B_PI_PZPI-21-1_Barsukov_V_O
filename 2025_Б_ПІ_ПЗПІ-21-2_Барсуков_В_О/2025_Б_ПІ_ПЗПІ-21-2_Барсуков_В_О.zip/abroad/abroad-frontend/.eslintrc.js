module.exports = {
  parser: "@typescript-eslint/parser",
  parserOptions: {
    project: "tsconfig.json",
    tsconfigRootDir: __dirname,
    sourceType: "module",
  },
  plugins: ["@typescript-eslint", "prettier"],
  extends: [
    // "plugin:@typescript-eslint/recommended",
    "plugin:prettier/recommended",
    "prettier",
    "next/core-web-vitals",
  ],
  root: true,
  env: {
    node: true,
    jest: true,
  },
  ignorePatterns: [".eslintrc.js", "postcss.config.js", "tailwind.config.js", "next.config.js"],
  rules: {
    "@typescript-eslint/interface-name-prefix": "off",
    "@typescript-eslint/explicit-function-return-type": "off",
    "@typescript-eslint/explicit-module-boundary-types": "off",
    "@typescript-eslint/no-explicit-any": "off",
    "prettier/prettier": [
      "warn",
      { useTabs: true, singleQuote: true, tabWidth: 2, endOfLine: "auto", printWidth: 130 },
    ],
    "max-len": ["warn", { code: 170, ignoreTemplateLiterals: true }],
  },
};

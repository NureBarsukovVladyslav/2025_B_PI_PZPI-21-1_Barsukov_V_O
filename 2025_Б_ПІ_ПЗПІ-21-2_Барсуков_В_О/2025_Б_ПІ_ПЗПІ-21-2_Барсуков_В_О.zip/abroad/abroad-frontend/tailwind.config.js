/** @type {import('tailwindcss').Config} */

// PACKAGES
import { heroui } from "@heroui/react";

// CONFIG
module.exports = {
  content: [
    './src/**/*.{js,jsx,ts,tsx}',
    './node_modules/@heroui/theme/dist/**/*.{js,ts,jsx,tsx}'
  ],
  theme: {
    extend: {
      fontSize: {
        xs: ['0.75rem', 'inherit'],
        sm: ['0.875rem', 'inherit'],
        base: ['1rem', 'inherit'],
        lg: ['1.125rem', 'inherit'],
        xl: ['1.25rem', 'inherit'],
        '2xl': ['1.5rem', 'inherit'],
        '3xl': ['1.875rem', 'inherit'],
        '4xl': ['2.25rem', 'inherit'],
        '5xl': ['3rem', 'inherit'],
        '6xl': ['3.75rem', 'inherit'],
        '7xl': ['4.5rem', 'inherit'],
        '8xl': ['6rem', 'inherit'],
        '9xl': ['8rem', 'inherit'],
      },
    },
  },
  darkMode: 'class',
  plugins: [heroui()],
};

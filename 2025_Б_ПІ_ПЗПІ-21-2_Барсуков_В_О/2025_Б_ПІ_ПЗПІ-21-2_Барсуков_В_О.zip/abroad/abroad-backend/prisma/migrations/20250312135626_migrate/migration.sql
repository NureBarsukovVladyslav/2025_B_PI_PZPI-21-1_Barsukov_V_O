-- AlterTable
ALTER TABLE `group` MODIFY `avatar` VARCHAR(191) NULL;

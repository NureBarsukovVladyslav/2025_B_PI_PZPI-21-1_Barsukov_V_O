-- DropForeignKey
ALTER TABLE `eventgroup` DROP FOREIGN KEY `EventGroup_eventId_fkey`;

-- DropForeignKey
ALTER TABLE `eventgroup` DROP FOREIGN KEY `EventGroup_groupId_fkey`;

-- DropForeignKey
ALTER TABLE `eventtarget` DROP FOREIGN KEY `EventTarget_eventId_fkey`;

-- DropForeignKey
ALTER TABLE `eventuser` DROP FOREIGN KEY `EventUser_eventId_fkey`;

-- DropForeignKey
ALTER TABLE `grouphobby` DROP FOREIGN KEY `GroupHobby_groupId_fkey`;

-- DropForeignKey
ALTER TABLE `grouplanguage` DROP FOREIGN KEY `GroupLanguage_groupId_fkey`;

-- DropForeignKey
ALTER TABLE `groupmessage` DROP FOREIGN KEY `GroupMessage_groupId_fkey`;

-- DropForeignKey
ALTER TABLE `grouptarget` DROP FOREIGN KEY `GroupTarget_groupId_fkey`;

-- AddForeignKey
ALTER TABLE `EventUser` ADD CONSTRAINT `EventUser_eventId_fkey` FOREIGN KEY (`eventId`) REFERENCES `Event`(`eventId`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `EventGroup` ADD CONSTRAINT `EventGroup_groupId_fkey` FOREIGN KEY (`groupId`) REFERENCES `Group`(`groupId`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `EventGroup` ADD CONSTRAINT `EventGroup_eventId_fkey` FOREIGN KEY (`eventId`) REFERENCES `Event`(`eventId`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `EventTarget` ADD CONSTRAINT `EventTarget_eventId_fkey` FOREIGN KEY (`eventId`) REFERENCES `Event`(`eventId`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `GroupMessage` ADD CONSTRAINT `GroupMessage_groupId_fkey` FOREIGN KEY (`groupId`) REFERENCES `Group`(`groupId`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `GroupLanguage` ADD CONSTRAINT `GroupLanguage_groupId_fkey` FOREIGN KEY (`groupId`) REFERENCES `Group`(`groupId`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `GroupHobby` ADD CONSTRAINT `GroupHobby_groupId_fkey` FOREIGN KEY (`groupId`) REFERENCES `Group`(`groupId`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `GroupTarget` ADD CONSTRAINT `GroupTarget_groupId_fkey` FOREIGN KEY (`groupId`) REFERENCES `Group`(`groupId`) ON DELETE CASCADE ON UPDATE CASCADE;

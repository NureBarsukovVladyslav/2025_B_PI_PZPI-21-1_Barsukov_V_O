/*
  Warnings:

  - The values [GROUP_ONLY] on the enum `User_statusOfVisibility` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterTable
ALTER TABLE `user` MODIFY `password` VARCHAR(191) NOT NULL,
    MODIFY `statusOfVisibility` ENUM('ALL', 'FRIEND_ONLY') NOT NULL DEFAULT 'ALL';

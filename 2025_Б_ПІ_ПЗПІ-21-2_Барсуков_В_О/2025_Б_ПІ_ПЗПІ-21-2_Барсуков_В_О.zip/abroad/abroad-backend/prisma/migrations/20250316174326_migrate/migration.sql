-- AlterTable
ALTER TABLE `article` MODIFY `content` VARCHAR(3000) NOT NULL;

/*
  Warnings:

  - The values [FRIEND_ONLY,GROUP_ONLY] on the enum `User_statusOfPublicity` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterTable
ALTER TABLE `user` MODIFY `statusOfPublicity` ENUM('ALL', 'SIMILAR') NOT NULL DEFAULT 'ALL';

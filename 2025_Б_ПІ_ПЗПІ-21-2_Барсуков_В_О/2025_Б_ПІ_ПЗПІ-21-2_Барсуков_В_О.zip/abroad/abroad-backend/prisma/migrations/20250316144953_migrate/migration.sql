-- DropForeignKey
ALTER TABLE `groupuser` DROP FOREIGN KEY `GroupUser_groupId_fkey`;

-- AddForeignKey
ALTER TABLE `GroupUser` ADD CONSTRAINT `GroupUser_groupId_fkey` FOREIGN KEY (`groupId`) REFERENCES `Group`(`groupId`) ON DELETE CASCADE ON UPDATE CASCADE;

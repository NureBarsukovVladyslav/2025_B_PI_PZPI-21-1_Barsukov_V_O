import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { DatabaseService } from '../../database/database.service';
import { UpdateUserRequestDto } from './dto/request/UpdateUser.request.dto';
import { GetPreviewUserResponseDto } from './dto/response/GetPreviewUser.response.dto';
import { SelectPreviewUserPrismaDto, SelectUserLanguagePrismaDto } from './dto/prisma/SelectPreviewUser.prisma.dto';
import { SelectFullUserPrismaDto } from './dto/prisma/SelectFullUser.prisma.dto';
import { ChangeUserPasswordRequestDto } from './dto/request/ChangeUserPassword.request.dto';
import { TokenService } from '../../services/token/token.service';
import * as bcrypt from 'bcrypt';
import * as process from 'node:process';
import { StatusOfFriendship, StatusOfVisibility } from '@prisma/client';

@Injectable()
export class UserService {
	constructor(private readonly databaseService: DatabaseService, private readonly tokenService: TokenService) {}

	async getRecommendationUsers(request: Request) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const currentUser = await this.databaseService.user.findUnique({
			select: {
				languages: { select: { language: true } },
				hobbies: { select: { hobby: true } },
				targets: { select: { target: true } },
				country: true,
				city: true,
			},
			where: { userId },
		});

		if (!currentUser) throw new HttpException('User not found', HttpStatus.NOT_FOUND);

		const userLanguages = new Set(currentUser.languages.map((l) => l.language));
		const userHobbies = new Set(currentUser.hobbies.map((h) => h.hobby));
		const userTargets = new Set(currentUser.targets.map((t) => t.target));

		const friends = await this.databaseService.userFriend.findMany({
			select: { friendId: true, userId: true },
			where: {
				OR: [{ userId }, { friendId: userId }],
				statusOfFriendship: StatusOfFriendship.FRIEND,
			},
		});

		const friendIds = new Set(friends.map((f) => (f.userId === userId ? f.friendId : f.userId)));

		const recommendedUsers = await this.databaseService.user.findMany({
			select: {
				...SelectPreviewUserPrismaDto,
				languages: SelectUserLanguagePrismaDto,
				hobbies: { select: { hobby: true } },
				targets: { select: { target: true } },
				country: true,
				city: true,
			},
			where: {
				userId: {
					notIn: [...friendIds, userId],
				},
			},
		});

		return recommendedUsers
			.map((user) => {
				const commonLanguages = user.languages.filter((l) => userLanguages.has(l.language)).length;
				const commonHobbies = user.hobbies.filter((h) => userHobbies.has(h.hobby)).length;
				const commonTargets = user.targets.filter((t) => userTargets.has(t.target)).length;
				const sameCountry = user.country === currentUser.country ? 1 : 0;
				const sameCity = user.city === currentUser.city ? 1 : 0;

				return {
					...user,
					isFriend: false,
					matchCount: commonLanguages + commonHobbies + commonTargets + sameCountry + sameCity,
				};
			})
			.sort((a, b) => b.matchCount - a.matchCount);
	}

	async getUsers(request: Request): Promise<GetPreviewUserResponseDto[]> {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const users = await this.databaseService.user.findMany({
			select: SelectPreviewUserPrismaDto,
		});

		const friends = await this.databaseService.userFriend.findMany({
			select: { friendId: true, userId: true },
			where: {
				OR: [{ userId }, { friendId: userId }],
				statusOfFriendship: StatusOfFriendship.FRIEND,
			},
		});

		const friendIds = new Set(friends.map((f) => (f.userId === userId ? f.friendId : f.userId)));

		return users.map((user) => ({
			...user,
			isFriend: friendIds.has(user.userId),
		}));
	}

	async getUser(request: Request, userId: number) {
		const tokenUserId = await this.tokenService.getUserIdFromToken(request);

		if (userId === tokenUserId) {
			const user = await this.databaseService.user.findUnique({
				select: SelectFullUserPrismaDto,
				where: {
					userId,
				},
			});

			return {
				...user,
				isFriend: false,
				isFriendPending: false,
				isFriendBlock: false,
			};
		} else {
			const user = await this.databaseService.user.findUnique({
				select: SelectFullUserPrismaDto,
				where: {
					userId,
				},
			});

			if (!user) throw new HttpException('User not found', HttpStatus.NOT_FOUND);

			const friendship = await this.databaseService.userFriend.findFirst({
				select: { userFriendId: true, statusOfFriendship: true },
				where: {
					OR: [
						{ userId: tokenUserId, friendId: userId },
						{ userId: userId, friendId: tokenUserId },
					],
				},
			});

			if (user.statusOfVisibility === StatusOfVisibility.FRIEND_ONLY) {
				if (friendship && friendship.statusOfFriendship !== StatusOfFriendship.FRIEND) {
					const user = await this.databaseService.user.findUnique({
						select: {
							userId: true,
							name: true,
							surname: true,
							avatar: true,
							statusOfVisibility: true,
						},
						where: {
							userId,
						},
					});

					return {
						...user,
						isFriend: false,
						isFriendPending: friendship.statusOfFriendship === StatusOfFriendship.PENDING,
						isFriendBlock: friendship.statusOfFriendship === StatusOfFriendship.BLOCK,
					};
				} else {
					const user = await this.databaseService.user.findUnique({
						select: SelectFullUserPrismaDto,
						where: {
							userId,
						},
					});

					return {
						...user,
						isFriend: true,
						isFriendPending: false,
						isFriendBlock: false,
					};
				}
			} else {
				const user = await this.databaseService.user.findUnique({
					select: SelectFullUserPrismaDto,
					where: {
						userId,
					},
				});

				if (friendship) {
					return {
						...user,
						isFriend: friendship.statusOfFriendship === StatusOfFriendship.FRIEND,
						isFriendPending: friendship.statusOfFriendship === StatusOfFriendship.PENDING,
						isFriendBlock: friendship.statusOfFriendship === StatusOfFriendship.BLOCK,
					};
				} else {
					return {
						...user,
						isFriend: false,
						isFriendPending: false,
						isFriendBlock: false,
					};
				}
			}
		}
	}

	async updateUser(request: Request, dto: UpdateUserRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		return await this.databaseService.user.update({
			select: SelectFullUserPrismaDto,
			where: { userId },
			data: dto,
		});
	}

	async changeUserPassword(request: Request, dto: ChangeUserPasswordRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const saltRounds = process.env.SALT_ROUNDS ? Number(process.env.SALT_ROUNDS) : 10;
		dto.password = await bcrypt.hash(dto.password, saltRounds);

		return await this.databaseService.user.update({
			select: SelectFullUserPrismaDto,
			where: { userId },
			data: dto,
		});
	}
}

import { Module } from '@nestjs/common';
import { UserFriendService } from './user-friend.service';
import { UserFriendController } from './user-friend.controller';
import { DatabaseModule } from '../../../database/database.module';
import { TokenModule } from '../../../services/token/token.module';

@Module({
	imports: [DatabaseModule, TokenModule],
	providers: [UserFriendService],
	controllers: [UserFriendController],
})
export class UserFriendModule {}

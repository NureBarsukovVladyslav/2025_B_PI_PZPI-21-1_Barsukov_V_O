import { IsString, MaxLength } from 'class-validator';

export class CreateFriendMessageRequestDto {
	@IsString()
	@MaxLength(1000)
	textOfMessage: string;
}

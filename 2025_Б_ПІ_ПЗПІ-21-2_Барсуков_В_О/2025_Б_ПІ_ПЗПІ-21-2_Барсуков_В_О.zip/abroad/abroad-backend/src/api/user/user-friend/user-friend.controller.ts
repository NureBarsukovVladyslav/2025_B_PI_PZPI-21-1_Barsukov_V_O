import {
	Body,
	Controller,
	Delete,
	Get,
	Param,
	ParseIntPipe,
	Patch,
	Req,
	UseInterceptors,
	UsePipes,
	ValidationPipe,
} from '@nestjs/common';
import { UserFriendService } from './user-friend.service';
import { ApiResponseCompleteOperationInterceptor } from '../../../common/interceptors/response/completeOperation.response.interceptor';
import { CreateFriendMessageRequestDto } from './dto/request/CreateFriendMessage.request.dto';

@Controller('user-friend')
export class UserFriendController {
	constructor(private readonly userFriendService: UserFriendService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Get('/')
	async getFriends(@Req() request: Request) {
		return await this.userFriendService.getFriends(request);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Get('/friend-request/')
	async getFriendsRequest(@Req() request: Request) {
		return await this.userFriendService.getFriendsRequest(request);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Get('/messages/:id')
	async getFriendMessages(@Req() request: Request, @Param('id', ParseIntPipe) friendId: number) {
		return await this.userFriendService.getFriendMessages(request, friendId);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Patch('/create-message/:id')
	async createFriendMessage(
		@Req() request: Request,
		@Param('id', ParseIntPipe) friendId: number,
		@Body() dto: CreateFriendMessageRequestDto,
	) {
		return await this.userFriendService.createFriendMessage(request, friendId, dto);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Patch('/make-friend/:id')
	async makeFriend(@Req() request: Request, @Param('id', ParseIntPipe) friendId: number) {
		return await this.userFriendService.makeFriend(request, friendId);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Patch('/accept-friend/:id')
	async acceptFriendRequest(@Req() request: Request, @Param('id', ParseIntPipe) friendId: number) {
		return await this.userFriendService.acceptFriendRequest(request, friendId);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Patch('/reject-friend/:id')
	async rejectFriendRequest(@Req() request: Request, @Param('id', ParseIntPipe) friendId: number) {
		return await this.userFriendService.rejectFriendRequest(request, friendId);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Patch('/block-friend/:id')
	async blockFriend(@Req() request: Request, @Param('id', ParseIntPipe) friendId: number) {
		return await this.userFriendService.blockFriend(request, friendId);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Patch('/unblock-friend/:id')
	async unblockFriend(@Req() request: Request, @Param('id', ParseIntPipe) friendId: number) {
		return await this.userFriendService.unblockFriend(request, friendId);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Delete('/:id')
	async deleteFriend(@Req() request: Request, @Param('id', ParseIntPipe) friendId: number) {
		return await this.userFriendService.deleteFriend(request, friendId);
	}
}

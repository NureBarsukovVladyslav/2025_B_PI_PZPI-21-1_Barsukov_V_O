import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { DatabaseService } from '../../../database/database.service';
import { StatusOfFriendship, StatusOfPublicity } from '@prisma/client';
import { CreateFriendMessageRequestDto } from './dto/request/CreateFriendMessage.request.dto';
import { TokenService } from '../../../services/token/token.service';

@Injectable()
export class UserFriendService {
	constructor(private readonly databaseService: DatabaseService, private readonly tokenService: TokenService) {}

	async getFriends(request: Request) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const invitedFriends = await this.databaseService.user.findUnique({
			select: {
				friends: {
					where: { statusOfFriendship: StatusOfFriendship.FRIEND },
					select: {
						friend: {
							select: {
								userId: true,
								name: true,
								surname: true,
								avatar: true,
							},
						},
					},
				},
			},
			where: { userId },
		});

		const invitedByFriends = await this.databaseService.user.findUnique({
			select: {
				userFriend: {
					where: { statusOfFriendship: StatusOfFriendship.FRIEND },
					select: {
						user: {
							select: {
								userId: true,
								name: true,
								surname: true,
								avatar: true,
							},
						},
					},
				},
			},
			where: { userId },
		});

		if (!invitedFriends || !invitedByFriends) throw new HttpException('User was not found', HttpStatus.NOT_FOUND);

		return [...invitedFriends.friends.map((f) => f.friend), ...invitedByFriends.userFriend.map((f) => f.user)];
	}

	async getFriendsRequest(request: Request) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const userFriend = await this.databaseService.user.findUnique({
			select: {
				userFriend: {
					where: { statusOfFriendship: StatusOfFriendship.PENDING },
					select: {
						user: {
							select: {
								userId: true,
								name: true,
								surname: true,
								avatar: true,
							},
						},
					},
				},
			},
			where: { userId },
		});

		if (!userFriend) throw new HttpException('Friend request not found', HttpStatus.NOT_FOUND);

		return userFriend.userFriend.map(({ user }) => user);
	}

	async getFriendMessages(request: Request, friendId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const friendship = await this.databaseService.userFriend.findFirst({
			select: { userFriendId: true },
			where: {
				OR: [
					{ userId, friendId, statusOfFriendship: StatusOfFriendship.FRIEND },
					{ userId: friendId, friendId: userId, statusOfFriendship: StatusOfFriendship.FRIEND },
				],
			},
		});

		if (!friendship) throw new HttpException('Friendship not found', HttpStatus.NOT_FOUND);

		return await this.databaseService.userFriendChat.findMany({
			where: { userFriendId: friendship.userFriendId },
		});
	}

	async createFriendMessage(request: Request, friendId: number, dto: CreateFriendMessageRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const friendship = await this.databaseService.userFriend.findFirst({
			select: { userFriendId: true },
			where: {
				OR: [
					{ userId, friendId, statusOfFriendship: StatusOfFriendship.FRIEND }, // Я пригласил друга
					{ userId: friendId, friendId: userId, statusOfFriendship: StatusOfFriendship.FRIEND }, // Друг пригласил меня
				],
			},
		});

		if (!friendship) throw new HttpException('Friendship not found', HttpStatus.NOT_FOUND);

		return await this.databaseService.userFriendChat.create({
			data: {
				userFriendId: friendship.userFriendId,
				userId,
				...dto,
			},
		});
	}

	async makeFriend(request: Request, friendId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const findFriend = await this.databaseService.user.findUnique({
			select: { userId: true, languages: true, hobbies: true, statusOfPublicity: true },
			where: { userId: friendId },
		});

		if (!findFriend) throw new HttpException('User was not found', HttpStatus.NOT_FOUND);

		if (findFriend.statusOfPublicity === StatusOfPublicity.SIMILAR) {
			const findUser = await this.databaseService.user.findUnique({
				select: { userId: true, languages: true, hobbies: true },
				where: { userId },
			});

			if (!findUser) throw new HttpException('User was not found', HttpStatus.NOT_FOUND);

			const hasSimilarLanguage = findUser.languages.some((language) =>
				findFriend.languages.some((friendLanguage) => friendLanguage.language === language.language),
			);

			const hasSimilarHobby = findUser.hobbies.some((hobby) =>
				findFriend.hobbies.some((friendHobby) => friendHobby.hobby === hobby.hobby),
			);

			if (!hasSimilarLanguage && !hasSimilarHobby) {
				throw new HttpException('The user limited the sending of requests for friends', HttpStatus.BAD_REQUEST);
			}

			return await this.databaseService.userFriend.create({
				data: {
					userId,
					friendId,
				},
			});
		} else {
			return await this.databaseService.userFriend.create({
				data: {
					userId,
					friendId,
				},
			});
		}
	}

	async acceptFriendRequest(request: Request, friendId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const friendship = await this.databaseService.userFriend.findFirst({
			select: { userFriendId: true },
			where: {
				OR: [{ userId: friendId, friendId: userId, statusOfFriendship: StatusOfFriendship.PENDING }],
			},
		});

		if (!friendship) throw new HttpException('Friendship not found', HttpStatus.NOT_FOUND);

		return await this.databaseService.userFriend.update({
			where: { userFriendId: friendship.userFriendId },
			data: {
				statusOfFriendship: StatusOfFriendship.FRIEND,
			},
		});
	}

	async rejectFriendRequest(request: Request, friendId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const friendship = await this.databaseService.userFriend.findFirst({
			select: { userFriendId: true },
			where: {
				OR: [
					{ userId: friendId, friendId: userId, statusOfFriendship: StatusOfFriendship.PENDING },
					{ userId, friendId, statusOfFriendship: StatusOfFriendship.PENDING },
				],
			},
		});

		if (!friendship) throw new HttpException('Friendship not found', HttpStatus.NOT_FOUND);

		return await this.databaseService.userFriend.delete({
			where: { userFriendId: friendship.userFriendId },
		});
	}

	async blockFriend(request: Request, friendId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const friendship = await this.databaseService.userFriend.findFirst({
			select: { userFriendId: true },
			where: {
				OR: [
					{ userId, friendId },
					{ userId: friendId, friendId: userId },
				],
			},
		});

		if (!friendship) throw new HttpException('Friendship not found', HttpStatus.NOT_FOUND);

		return await this.databaseService.userFriend.update({
			where: { userFriendId: friendship.userFriendId },
			data: {
				statusOfFriendship: StatusOfFriendship.BLOCK,
			},
		});
	}

	async unblockFriend(request: Request, friendId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const friendship = await this.databaseService.userFriend.findFirst({
			select: { userFriendId: true },
			where: {
				OR: [
					{ userId, friendId, statusOfFriendship: StatusOfFriendship.BLOCK },
					{ userId: friendId, friendId: userId, statusOfFriendship: StatusOfFriendship.BLOCK },
				],
			},
		});

		if (!friendship) throw new HttpException('Friendship not found', HttpStatus.NOT_FOUND);

		return await this.databaseService.userFriend.update({
			where: { userFriendId: friendship.userFriendId },
			data: {
				statusOfFriendship: StatusOfFriendship.PENDING,
			},
		});
	}

	async deleteFriend(request: Request, friendId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const friendship = await this.databaseService.userFriend.findFirst({
			select: { userFriendId: true },
			where: {
				OR: [
					{ userId, friendId },
					{ userId: friendId, friendId: userId },
				],
			},
		});

		if (!friendship) throw new HttpException('Friendship not found', HttpStatus.NOT_FOUND);

		return await this.databaseService.userFriend.deleteMany({
			where: {
				OR: [
					{ userId, friendId: friendId },
					{ userId: friendId, friendId: userId },
				],
			},
		});
	}
}

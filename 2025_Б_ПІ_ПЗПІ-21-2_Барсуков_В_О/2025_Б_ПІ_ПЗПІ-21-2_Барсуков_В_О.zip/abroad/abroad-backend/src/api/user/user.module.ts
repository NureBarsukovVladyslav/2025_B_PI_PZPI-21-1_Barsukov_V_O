import { Module } from '@nestjs/common';
import { UserService } from './user.service';
import { UserController } from './user.controller';
import { DatabaseModule } from '../../database/database.module';
import { UserLanguageModule } from './user-language/user-language.module';
import { UserHobbyModule } from './user-hobby/user-hobby.module';
import { UserTargetModule } from './user-target/user-target.module';
import { UserFriendModule } from './user-friend/user-friend.module';
import { TokenModule } from '../../services/token/token.module';

@Module({
	imports: [DatabaseModule, TokenModule, UserLanguageModule, UserHobbyModule, UserTargetModule, UserFriendModule],
	providers: [UserService],
	controllers: [UserController],
})
export class UserModule {}

import {
	Hobby,
	LevelOfLanguage,
	StatusOfStay,
	StatusOfUser,
	StatusOfVisibility,
	Target,
	TypeOfGender,
} from '@prisma/client';

interface SelectUserLanguageDto {
	userLanguageId: number;
	language: string;
	levelOfLanguage: LevelOfLanguage;
	isBasic: boolean;
}

interface SelectUserHobbyDto {
	userHobbyId: number;
	hobby: Hobby;
}

interface SelectUserTargetDto {
	userTargetId: number;
	target: Target;
}

interface SelectUserGroupDto {
	groupUserId: number;
	group: {
		groupId: number;
		nameOfGroup: string;
		avatar: string | null;
	};
}

export interface GetFullUserResponseDto {
	userId: number;
	name: string;
	surname: string;
	gender: TypeOfGender;
	avatar: string | null;
	dateOfBirth: Date | null;
	country: string;
	city: string;
	goalOfUser: string | null;
	dateOfArrival: Date | null;
	statusOfStay: StatusOfStay | null;
	statusOfUser: StatusOfUser | null;
	statusOfVisibility: StatusOfVisibility;
	languages: SelectUserLanguageDto[];
	hobbies: SelectUserHobbyDto[];
	targets: SelectUserTargetDto[];
	groups: SelectUserGroupDto[];
}

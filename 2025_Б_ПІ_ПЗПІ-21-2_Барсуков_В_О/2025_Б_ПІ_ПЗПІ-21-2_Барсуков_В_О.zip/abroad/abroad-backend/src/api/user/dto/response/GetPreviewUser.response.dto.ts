import { Hobby, LevelOfLanguage, StatusOfUser, StatusOfVisibility, TypeOfGender } from '@prisma/client';

interface SelectUserLanguageDto {
	userLanguageId: number;
	language: string;
	levelOfLanguage: LevelOfLanguage;
	isBasic: boolean;
}

interface SelectUserHobbyDto {
	userHobbyId: number;
	hobby: Hobby;
}

export interface GetPreviewUserResponseDto {
	userId: number;
	name: string;
	surname: string;
	gender: TypeOfGender;
	avatar: string | null;
	dateOfBirth: Date | null;
	country: string;
	city: string;
	statusOfUser: StatusOfUser | null;
	statusOfVisibility: StatusOfVisibility;
	languages: SelectUserLanguageDto[];
	hobbies: SelectUserHobbyDto[];
}

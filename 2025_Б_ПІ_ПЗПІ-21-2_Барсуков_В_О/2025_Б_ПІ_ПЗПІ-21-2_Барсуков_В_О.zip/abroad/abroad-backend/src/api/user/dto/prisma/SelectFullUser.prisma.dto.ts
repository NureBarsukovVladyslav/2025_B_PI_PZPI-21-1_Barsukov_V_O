import { Prisma } from '@prisma/client';
import { DefaultArgs } from '@prisma/client/runtime/library';

const SelectUserLanguagePrismaDto: Prisma.UserLanguageDefaultArgs<DefaultArgs> = {
	select: {
		userLanguageId: true,
		language: true,
		levelOfLanguage: true,
		isBasic: true,
	},
};

const SelectUserHobbyPrismaDto: Prisma.UserHobbyDefaultArgs<DefaultArgs> = {
	select: {
		userHobbyId: true,
		hobby: true,
	},
};

const SelectUserTargetPrismaDto: Prisma.UserTargetDefaultArgs<DefaultArgs> = {
	select: {
		userTargetId: true,
		target: true,
	},
};

const SelectUserEventPrismaDto: Prisma.EventDefaultArgs<DefaultArgs> = {
	select: {
		eventId: true,
		nameOfEvent: true,
		dateOfEvent: true,
		timeStart: true,
		timeEnd: true,
		country: true,
		city: true,
		address: true,
		targets: {
			select: {
				eventTargetId: true,
				target: true,
			},
		},
	},
};

const SelectUserGroupPrismaDto: Prisma.GroupUserDefaultArgs<DefaultArgs> = {
	select: {
		groupUserId: true,
		group: {
			select: {
				groupId: true,
				nameOfGroup: true,
				avatar: true,
			},
		},
	},
};

export const SelectFullUserPrismaDto: Prisma.UserSelect = {
	userId: true,
	name: true,
	surname: true,
	email: true,
	gender: true,
	avatar: true,
	dateOfBirth: true,
	country: true,
	city: true,
	goalOfUser: true,
	dateOfArrival: true,
	statusOfStay: true,
	statusOfUser: true,
	statusOfVisibility: true,
	languages: SelectUserLanguagePrismaDto,
	hobbies: SelectUserHobbyPrismaDto,
	targets: SelectUserTargetPrismaDto,
	authorEvents: SelectUserEventPrismaDto,
	groups: SelectUserGroupPrismaDto,
};

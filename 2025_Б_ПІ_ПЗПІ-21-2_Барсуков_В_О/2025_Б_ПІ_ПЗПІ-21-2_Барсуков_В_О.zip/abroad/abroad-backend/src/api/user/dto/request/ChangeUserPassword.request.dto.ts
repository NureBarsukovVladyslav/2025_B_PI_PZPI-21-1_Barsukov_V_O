import { IsString, IsStrongPassword } from 'class-validator';

export class ChangeUserPasswordRequestDto {
	@IsString()
	@IsStrongPassword({
		minLength: 6,
		minNumbers: 3,
		minUppercase: 1,
		minLowercase: 1,
		minSymbols: 1,
	})
	password: string;
}

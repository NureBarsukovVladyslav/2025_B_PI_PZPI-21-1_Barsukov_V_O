import { IsEmail, IsEnum, IsISO8601, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';
import { DEFAULT_STRING_MIN_LENGTH } from '../../../../constants/validator/default-value.constant';
import { StatusOfStay, StatusOfUser, StatusOfVisibility, TypeOfGender } from '@prisma/client';

export class UpdateUserRequestDto {
	@IsString()
	@MinLength(DEFAULT_STRING_MIN_LENGTH)
	@MaxLength(20)
	name: string;

	@IsString()
	@MinLength(DEFAULT_STRING_MIN_LENGTH)
	@MaxLength(20)
	surname: string;

	@IsEnum(TypeOfGender)
	gender: TypeOfGender;

	@IsString()
	@IsEmail()
	@MaxLength(50)
	email: string;

	@IsOptional()
	@IsISO8601()
	dateOfBirth: Date | null;

	@IsString()
	country: string;

	@IsString()
	city: string;

	@IsOptional()
	@IsISO8601()
	dateOfArrival: Date | null;

	@IsOptional()
	@IsString()
	@MinLength(DEFAULT_STRING_MIN_LENGTH)
	@MaxLength(300)
	goalOfUser: string | null;

	@IsOptional()
	@IsEnum(StatusOfStay)
	statusOfStay: StatusOfStay | null;

	@IsOptional()
	@IsEnum(StatusOfUser)
	statusOfUser: StatusOfUser | null;

	@IsEnum(StatusOfVisibility)
	statusOfVisibility: StatusOfVisibility;
}

import { Prisma } from '@prisma/client';
import { DefaultArgs } from '@prisma/client/runtime/library';

export const SelectUserLanguagePrismaDto: Prisma.UserLanguageDefaultArgs<DefaultArgs> = {
	select: {
		userLanguageId: true,
		language: true,
		levelOfLanguage: true,
		isBasic: true,
	},
};

export const SelectPreviewUserPrismaDto: Prisma.UserSelect = {
	userId: true,
	name: true,
	surname: true,
	avatar: true,
	dateOfBirth: true,
	country: true,
	city: true,
	statusOfUser: true,
	languages: SelectUserLanguagePrismaDto,
};

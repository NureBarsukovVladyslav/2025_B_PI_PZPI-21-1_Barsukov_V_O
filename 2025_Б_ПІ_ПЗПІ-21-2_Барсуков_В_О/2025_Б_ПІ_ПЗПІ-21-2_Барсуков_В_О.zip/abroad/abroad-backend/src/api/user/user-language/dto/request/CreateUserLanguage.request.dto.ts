import { IsBoolean, IsEnum, IsString, MaxLength, MinLength } from 'class-validator';
import { LevelOfLanguage } from '@prisma/client';

export class CreateUserLanguageRequestDto {
	@IsString()
	@MinLength(2)
	@MaxLength(2)
	language: string;

	@IsEnum(LevelOfLanguage)
	levelOfLanguage: LevelOfLanguage;

	@IsBoolean()
	isBasic: boolean;
}

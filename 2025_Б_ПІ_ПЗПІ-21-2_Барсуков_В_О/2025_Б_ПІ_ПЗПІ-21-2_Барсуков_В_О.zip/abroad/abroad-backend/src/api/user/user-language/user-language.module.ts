import { Module } from '@nestjs/common';
import { UserLanguageService } from './user-language.service';
import { UserLanguageController } from './user-language.controller';
import { DatabaseModule } from '../../../database/database.module';
import { TokenModule } from '../../../services/token/token.module';

@Module({
	imports: [DatabaseModule, TokenModule],
	providers: [UserLanguageService],
	controllers: [UserLanguageController],
})
export class UserLanguageModule {}

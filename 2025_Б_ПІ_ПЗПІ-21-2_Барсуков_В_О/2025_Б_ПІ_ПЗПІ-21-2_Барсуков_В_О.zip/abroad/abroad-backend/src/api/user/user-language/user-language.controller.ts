import {
	Body,
	Controller,
	Delete,
	Param,
	ParseIntPipe,
	Post,
	Req,
	UseInterceptors,
	UsePipes,
	ValidationPipe,
} from '@nestjs/common';
import { UserLanguageService } from './user-language.service';
import { ApiResponseCompleteOperationInterceptor } from '../../../common/interceptors/response/completeOperation.response.interceptor';
import { CreateUserLanguageRequestDto } from './dto/request/CreateUserLanguage.request.dto';

@Controller('user-language')
export class UserLanguageController {
	constructor(private readonly userLanguageService: UserLanguageService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Post('/')
	async createUserLanguage(@Req() request: Request, @Body() dto: CreateUserLanguageRequestDto) {
		return await this.userLanguageService.createUserLanguage(request, dto);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Delete('/:id')
	async deleteUserLanguage(@Req() request: Request, @Param('id', ParseIntPipe) userLanguageId: number) {
		return await this.userLanguageService.deleteUserLanguage(request, userLanguageId);
	}
}

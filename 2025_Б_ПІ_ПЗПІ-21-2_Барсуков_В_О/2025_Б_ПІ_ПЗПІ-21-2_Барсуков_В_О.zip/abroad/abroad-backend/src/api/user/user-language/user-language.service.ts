import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { DatabaseService } from '../../../database/database.service';
import { CreateUserLanguageRequestDto } from './dto/request/CreateUserLanguage.request.dto';
import { TokenService } from '../../../services/token/token.service';
import { RIGHT_ERROR_MESSAGE } from '../../../constants/errors/errors.constant';

@Injectable()
export class UserLanguageService {
	constructor(private readonly databaseService: DatabaseService, private readonly tokenService: TokenService) {}

	async createUserLanguage(request: Request, dto: CreateUserLanguageRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		return await this.databaseService.userLanguage.create({
			data: {
				userId,
				...dto,
			},
		});
	}

	async deleteUserLanguage(request: Request, userLanguageId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const user = await this.databaseService.userLanguage.findUnique({
			select: { user: true },
			where: { userLanguageId },
		});

		if (!user) throw new HttpException('User not found', HttpStatus.NOT_FOUND);
		if (userId !== user.user.userId) throw new HttpException(RIGHT_ERROR_MESSAGE, HttpStatus.FORBIDDEN);

		return await this.databaseService.userLanguage.delete({
			where: { userLanguageId },
		});
	}
}

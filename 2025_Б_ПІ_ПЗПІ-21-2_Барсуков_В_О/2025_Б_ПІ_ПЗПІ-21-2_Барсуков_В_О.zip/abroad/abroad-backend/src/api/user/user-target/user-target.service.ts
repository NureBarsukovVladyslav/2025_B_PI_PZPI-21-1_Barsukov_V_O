import { Injectable } from '@nestjs/common';
import { DatabaseService } from '../../../database/database.service';
import { CreateOrUpdateUserTargetRequestDto } from './dto/request/CreateOrUpdateUserTarget.request.dto';
import { TokenService } from '../../../services/token/token.service';

@Injectable()
export class UserTargetService {
	constructor(private readonly databaseService: DatabaseService, private readonly tokenService: TokenService) {}

	async createOrUpdateUserTarget(request: Request, dto: CreateOrUpdateUserTargetRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		return await this.databaseService.user.update({
			where: { userId },
			data: {
				targets: {
					deleteMany: {},
					create: dto.targets.map((target) => {
						return { target };
					}),
				},
			},
		});
	}
}

import { Module } from '@nestjs/common';
import { UserTargetService } from './user-target.service';
import { UserTargetController } from './user-target.controller';
import { DatabaseModule } from '../../../database/database.module';
import { TokenModule } from '../../../services/token/token.module';

@Module({
	imports: [DatabaseModule, TokenModule],
	providers: [UserTargetService],
	controllers: [UserTargetController],
})
export class UserTargetModule {}

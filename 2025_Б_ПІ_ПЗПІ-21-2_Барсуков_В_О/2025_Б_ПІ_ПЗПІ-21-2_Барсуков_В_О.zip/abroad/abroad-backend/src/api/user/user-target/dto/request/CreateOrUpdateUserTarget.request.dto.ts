import { IsArray, IsEnum } from 'class-validator';
import { Target } from '@prisma/client';

export class CreateOrUpdateUserTargetRequestDto {
	@IsArray()
	@IsEnum(Target, { each: true })
	targets: Target[];
}

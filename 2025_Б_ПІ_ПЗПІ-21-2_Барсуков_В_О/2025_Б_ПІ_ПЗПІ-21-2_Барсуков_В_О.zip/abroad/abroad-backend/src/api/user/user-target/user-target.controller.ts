import { Body, Controller, Post, Req, UseInterceptors, UsePipes, ValidationPipe } from '@nestjs/common';
import { UserTargetService } from './user-target.service';
import { ApiResponseCompleteOperationInterceptor } from '../../../common/interceptors/response/completeOperation.response.interceptor';
import { CreateOrUpdateUserTargetRequestDto } from './dto/request/CreateOrUpdateUserTarget.request.dto';

@Controller('user-target')
export class UserTargetController {
	constructor(private readonly userTargetService: UserTargetService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Post('/')
	async createOrUpdateUserTarget(@Req() request: Request, @Body() dto: CreateOrUpdateUserTargetRequestDto) {
		return await this.userTargetService.createOrUpdateUserTarget(request, dto);
	}
}

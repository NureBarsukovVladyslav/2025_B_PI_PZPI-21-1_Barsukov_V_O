import { IsArray, IsEnum } from 'class-validator';
import { Hobby } from '@prisma/client';

export class CreateOrUpdateUserHobbyRequestDto {
	@IsArray()
	@IsEnum(Hobby, { each: true })
	hobbies: Hobby[];
}

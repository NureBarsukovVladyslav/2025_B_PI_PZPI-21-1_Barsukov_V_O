import { Body, Controller, Post, Req, UseInterceptors, UsePipes, ValidationPipe } from '@nestjs/common';
import { UserHobbyService } from './user-hobby.service';
import { ApiResponseCompleteOperationInterceptor } from '../../../common/interceptors/response/completeOperation.response.interceptor';
import { CreateOrUpdateUserHobbyRequestDto } from './dto/request/CreateOrUpdateUserHobby.request.dto';

@Controller('user-hobby')
export class UserHobbyController {
	constructor(private readonly userHobbyService: UserHobbyService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Post('/')
	async createOrUpdateUserHobby(@Req() request: Request, @Body() dto: CreateOrUpdateUserHobbyRequestDto) {
		return await this.userHobbyService.createOrUpdateUserHobby(request, dto);
	}
}

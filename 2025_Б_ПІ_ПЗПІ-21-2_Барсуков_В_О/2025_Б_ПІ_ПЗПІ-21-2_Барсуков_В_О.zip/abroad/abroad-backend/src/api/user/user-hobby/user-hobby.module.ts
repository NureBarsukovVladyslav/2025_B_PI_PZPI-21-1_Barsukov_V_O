import { Module } from '@nestjs/common';
import { UserHobbyService } from './user-hobby.service';
import { UserHobbyController } from './user-hobby.controller';
import { DatabaseModule } from '../../../database/database.module';
import { TokenModule } from '../../../services/token/token.module';

@Module({
	imports: [DatabaseModule, TokenModule],
	providers: [UserHobbyService],
	controllers: [UserHobbyController],
})
export class UserHobbyModule {}

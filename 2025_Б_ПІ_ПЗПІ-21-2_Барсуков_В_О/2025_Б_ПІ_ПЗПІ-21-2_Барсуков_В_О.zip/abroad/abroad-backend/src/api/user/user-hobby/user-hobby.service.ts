import { Injectable } from '@nestjs/common';
import { DatabaseService } from '../../../database/database.service';
import { CreateOrUpdateUserHobbyRequestDto } from './dto/request/CreateOrUpdateUserHobby.request.dto';
import { TokenService } from '../../../services/token/token.service';

@Injectable()
export class UserHobbyService {
	constructor(private readonly databaseService: DatabaseService, private readonly tokenService: TokenService) {}

	async createOrUpdateUserHobby(request: Request, dto: CreateOrUpdateUserHobbyRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		return await this.databaseService.user.update({
			where: { userId },
			data: {
				hobbies: {
					deleteMany: {},
					create: dto.hobbies.map((hobby) => {
						return { hobby };
					}),
				},
			},
		});
	}
}

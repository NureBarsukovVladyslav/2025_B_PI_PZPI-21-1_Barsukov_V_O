import {
	Body,
	Controller,
	Get,
	Param,
	ParseIntPipe,
	Patch,
	Put,
	Req,
	UseInterceptors,
	UsePipes,
	ValidationPipe,
} from '@nestjs/common';
import { UserService } from './user.service';
import { ApiResponseCompleteOperationInterceptor } from '../../common/interceptors/response/completeOperation.response.interceptor';
import { UpdateUserRequestDto } from './dto/request/UpdateUser.request.dto';
import { ChangeUserPasswordRequestDto } from './dto/request/ChangeUserPassword.request.dto';

@Controller('user')
export class UserController {
	constructor(private readonly userService: UserService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Get('/recommendation')
	async getRecommendationUser(@Req() request: Request) {
		return await this.userService.getRecommendationUsers(request);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Get('/')
	async getUsers(@Req() request: Request) {
		return await this.userService.getUsers(request);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Get('/:id')
	async getUser(@Req() request: Request, @Param('id', ParseIntPipe) userId: number) {
		return await this.userService.getUser(request, userId);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Put('/')
	async updateUser(@Req() request: Request, @Body() dto: UpdateUserRequestDto) {
		return await this.userService.updateUser(request, dto);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Patch('/change-password')
	async changeUserPassword(@Req() request: Request, @Body() dto: ChangeUserPasswordRequestDto) {
		return await this.userService.changeUserPassword(request, dto);
	}
}

import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { DatabaseService } from '../../database/database.service';
import { SelectPreviewGroupPrismaDto } from './dto/prisma/SelectPreviewGroup.prisma.dto';
import { SelectFullGroupPrismaDto } from './dto/prisma/SelectFullGroup.prisma.dto';
import { CreateOrUpdateGroupRequestDto } from './dto/request/CreateOrUpdateGroup.request.dto';
import { TokenService } from '../../services/token/token.service';
import { RIGHT_ERROR_MESSAGE } from '../../constants/errors/errors.constant';

@Injectable()
export class GroupService {
	constructor(private readonly databaseService: DatabaseService, private readonly tokenService: TokenService) {}

	async getRecommendationGroups(request: Request): Promise<any[]> {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const currentUser = await this.databaseService.user.findUnique({
			select: {
				country: true,
				city: true,
				languages: { select: { language: true } },
				hobbies: { select: { hobby: true } },
				targets: { select: { target: true } },
			},
			where: { userId },
		});

		if (!currentUser) throw new HttpException('User not found', HttpStatus.NOT_FOUND);

		const userLanguages = new Set(currentUser.languages.map((l) => l.language));
		const userHobbies = new Set(currentUser.hobbies.map((h) => h.hobby));
		const userTargets = new Set(currentUser.targets.map((t) => t.target));

		const userGroups = await this.databaseService.groupUser.findMany({
			select: { groupId: true },
			where: { userId },
		});

		const userGroupIds = new Set(userGroups.map((g) => g.groupId));

		const recommendedGroups = await this.databaseService.group.findMany({
			select: SelectFullGroupPrismaDto,

			where: {
				groupId: { notIn: Array.from(userGroupIds) },
			},
		});

		return recommendedGroups
			.map((group) => {
				const commonLanguages = group.languages.filter((l) => userLanguages.has(l.language)).length;
				const commonHobbies = group.hobbies.filter((h) => userHobbies.has(h.hobby)).length;
				const commonTargets = group.targets.filter((t) => userTargets.has(t.target)).length;
				const isSameCountry = group.country === currentUser.country ? 1 : 0;
				const isSameCity = group.city === currentUser.city ? 1 : 0;

				return {
					...group,
					matchCount: commonLanguages + commonHobbies + commonTargets + isSameCountry + isSameCity,
				};
			})
			.sort((a, b) => b.matchCount - a.matchCount);
	}

	async getGroups(request: Request) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const groups: any[] = await this.databaseService.group.findMany({
			select: SelectPreviewGroupPrismaDto,
		});

		return groups.map((group) => {
			const isParticipant = group.users.some((item: any) => item.user.userId === userId);

			return {
				...group,
				isParticipant,
			};
		});
	}

	async getGroup(request: Request, groupId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const group: any = await this.databaseService.group.findUnique({
			select: SelectFullGroupPrismaDto,
			where: { groupId },
		});

		if (!group) throw new HttpException('Group not found', HttpStatus.NOT_FOUND);

		const isOwner = group.admin.userId === userId;
		const isParticipant = group.users.some((item: any) => item.user.userId === userId);

		return {
			...group,
			isOwner,
			isParticipant,
		};
	}

	async createGroup(request: Request, dto: CreateOrUpdateGroupRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		return await this.databaseService.group.create({
			select: SelectPreviewGroupPrismaDto,
			data: {
				userId,
				...dto,
				users: {
					create: {
						userId,
					},
				},
			},
		});
	}

	async updateGroup(request: Request, groupId: number, dto: CreateOrUpdateGroupRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const group = await this.databaseService.group.findUnique({
			where: { groupId },
		});

		if (!group) throw new HttpException('Group not found', HttpStatus.NOT_FOUND);
		if (group.userId !== userId) throw new HttpException(RIGHT_ERROR_MESSAGE, HttpStatus.FORBIDDEN);

		return await this.databaseService.group.update({
			select: SelectPreviewGroupPrismaDto,
			where: { groupId },
			data: dto,
		});
	}

	async deleteGroup(request: Request, groupId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const group = await this.databaseService.group.findUnique({
			where: { groupId },
		});

		if (!group) throw new HttpException('Group not found', HttpStatus.NOT_FOUND);
		if (group.userId !== userId) throw new HttpException(RIGHT_ERROR_MESSAGE, HttpStatus.FORBIDDEN);

		return await this.databaseService.group.delete({
			select: SelectPreviewGroupPrismaDto,
			where: { groupId },
		});
	}
}

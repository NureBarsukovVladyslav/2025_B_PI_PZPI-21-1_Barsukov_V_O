import { Prisma } from '@prisma/client';
import { DefaultArgs } from '@prisma/client/runtime/library';

const SelectGroupAdminPrismaDto: Prisma.UserDefaultArgs<DefaultArgs> = {
	select: {
		userId: true,
		name: true,
		surname: true,
		avatar: true,
	},
};

const SelectGroupEventPrismaDto: Prisma.EventGroupDefaultArgs<DefaultArgs> = {
	select: {
		groupEventId: true,
		event: {
			select: {
				eventId: true,
				nameOfEvent: true,
				description: true,
				dateOfEvent: true,
				timeStart: true,
				timeEnd: true,
				country: true,
				city: true,
				address: true,
				targets: {
					select: {
						eventTargetId: true,
						target: true,
					},
				},
			},
		},
	},
};

const SelectGroupUserPrismaDto: Prisma.GroupUserDefaultArgs<DefaultArgs> = {
	select: {
		groupUserId: true,
		user: {
			select: {
				userId: true,
				name: true,
				surname: true,
				avatar: true,
			},
		},
	},
};

const SelectGroupMessagePrismaDto: Prisma.GroupMessageDefaultArgs<DefaultArgs> = {
	select: {
		messageId: true,
		user: {
			select: {
				userId: true,
				name: true,
				surname: true,
				avatar: true,
			},
		},
		textOfMessage: true,
	},
};

const SelectGroupLanguagePrismaDto: Prisma.GroupLanguageDefaultArgs<DefaultArgs> = {
	select: {
		groupLanguageId: true,
		language: true,
		levelOfLanguage: true,
	},
};

const SelectGroupHobbyPrismaDto: Prisma.GroupHobbyDefaultArgs<DefaultArgs> = {
	select: {
		groupHobbyId: true,
		hobby: true,
	},
};

const SelectGroupTargetPrismaDto: Prisma.GroupTargetDefaultArgs<DefaultArgs> = {
	select: {
		groupTargetId: true,
		target: true,
	},
};

export const SelectFullGroupPrismaDto: Prisma.GroupSelect = {
	groupId: true,
	nameOfGroup: true,
	description: true,
	avatar: true,
	country: true,
	city: true,
	admin: SelectGroupAdminPrismaDto,
	events: SelectGroupEventPrismaDto,
	users: SelectGroupUserPrismaDto,
	languages: SelectGroupLanguagePrismaDto,
	hobbies: SelectGroupHobbyPrismaDto,
	targets: SelectGroupTargetPrismaDto,
	messages: SelectGroupMessagePrismaDto,
};

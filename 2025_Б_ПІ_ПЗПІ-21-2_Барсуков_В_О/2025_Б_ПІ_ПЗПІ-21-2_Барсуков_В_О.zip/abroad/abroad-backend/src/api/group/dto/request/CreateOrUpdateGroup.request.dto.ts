import { IsString, MaxLength, MinLength } from 'class-validator';
import { DEFAULT_STRING_MIN_LENGTH } from '../../../../constants/validator/default-value.constant';

export class CreateOrUpdateGroupRequestDto {
	@IsString()
	@MinLength(DEFAULT_STRING_MIN_LENGTH)
	@MaxLength(100)
	nameOfGroup: string;

	@IsString()
	@MinLength(DEFAULT_STRING_MIN_LENGTH)
	@MaxLength(1000)
	description: string;

	@IsString()
	country: string;

	@IsString()
	city: string;
}

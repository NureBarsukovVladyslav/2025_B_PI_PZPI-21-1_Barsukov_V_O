import { Prisma } from '@prisma/client';
import { DefaultArgs } from '@prisma/client/runtime/library';

const SelectGroupUserPrismaDto: Prisma.GroupUserDefaultArgs<DefaultArgs> = {
	select: {
		groupUserId: true,
		user: {
			select: {
				userId: true,
				name: true,
				surname: true,
				avatar: true,
			},
		},
	},
};

const SelectGroupLanguagePrismaDto: Prisma.GroupLanguageDefaultArgs<DefaultArgs> = {
	select: {
		groupLanguageId: true,
		language: true,
		levelOfLanguage: true,
	},
};

const SelectGroupHobbyPrismaDto: Prisma.GroupHobbyDefaultArgs<DefaultArgs> = {
	select: {
		groupHobbyId: true,
		hobby: true,
	},
};

const SelectGroupTargetPrismaDto: Prisma.GroupTargetDefaultArgs<DefaultArgs> = {
	select: {
		groupTargetId: true,
		target: true,
	},
};

export const SelectPreviewGroupPrismaDto: Prisma.GroupSelect = {
	groupId: true,
	nameOfGroup: true,
	description: true,
	avatar: true,
	country: true,
	city: true,
	users: SelectGroupUserPrismaDto,
	languages: SelectGroupLanguagePrismaDto,
	hobbies: SelectGroupHobbyPrismaDto,
	targets: SelectGroupTargetPrismaDto,
};

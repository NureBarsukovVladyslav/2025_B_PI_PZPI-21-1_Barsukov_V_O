import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { DatabaseService } from '../../../database/database.service';
import { CreateGroupLanguageRequestDto } from './dto/request/CreateGroupLanguage.request.dto';
import { TokenService } from '../../../services/token/token.service';
import { RIGHT_ERROR_MESSAGE } from '../../../constants/errors/errors.constant';

@Injectable()
export class GroupLanguageService {
	constructor(private readonly databaseService: DatabaseService, private readonly tokenService: TokenService) {}

	async createGroupLanguage(request: Request, dto: CreateGroupLanguageRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const group = await this.databaseService.group.findUnique({
			where: { groupId: dto.groupId },
		});

		if (!group) throw new HttpException('Group not found', HttpStatus.NOT_FOUND);
		if (group.userId !== userId) throw new HttpException(RIGHT_ERROR_MESSAGE, HttpStatus.FORBIDDEN);

		return await this.databaseService.groupLanguage.create({
			data: dto,
		});
	}

	async deleteGroupLanguage(request: Request, groupLanguageId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const groupLanguage = await this.databaseService.groupLanguage.findUnique({
			select: { group: true },
			where: { groupLanguageId },
		});

		if (!groupLanguage) throw new HttpException('Group not found', HttpStatus.NOT_FOUND);
		if (groupLanguage.group.userId !== userId) throw new HttpException(RIGHT_ERROR_MESSAGE, HttpStatus.FORBIDDEN);

		return await this.databaseService.groupLanguage.delete({
			where: { groupLanguageId },
		});
	}
}

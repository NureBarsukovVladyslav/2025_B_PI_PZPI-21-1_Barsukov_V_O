import {
	Body,
	Controller,
	Delete,
	Param,
	ParseIntPipe,
	Post,
	Put,
	Req,
	UseInterceptors,
	UsePipes,
	ValidationPipe,
} from '@nestjs/common';
import { GroupLanguageService } from './group-language.service';
import { ApiResponseCompleteOperationInterceptor } from '../../../common/interceptors/response/completeOperation.response.interceptor';
import { CreateGroupLanguageRequestDto } from './dto/request/CreateGroupLanguage.request.dto';

@Controller('group-language')
export class GroupLanguageController {
	constructor(private readonly groupLanguageService: GroupLanguageService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Post('/')
	async createGroupLanguage(@Req() request: Request, @Body() dto: CreateGroupLanguageRequestDto) {
		return await this.groupLanguageService.createGroupLanguage(request, dto);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Delete('/:id')
	async deleteGroupLanguage(@Req() request: Request, @Param('id', ParseIntPipe) groupLanguageId: number) {
		return await this.groupLanguageService.deleteGroupLanguage(request, groupLanguageId);
	}
}

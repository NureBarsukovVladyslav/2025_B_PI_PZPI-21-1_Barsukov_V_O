import { IsEnum, IsNumber, IsPositive, IsString, MaxLength, MinLength } from 'class-validator';
import { LevelOfLanguage } from '@prisma/client';

export class CreateGroupLanguageRequestDto {
	@IsNumber()
	@IsPositive()
	groupId: number;

	@IsString()
	@MinLength(2)
	@MaxLength(2)
	language: string;

	@IsEnum(LevelOfLanguage)
	levelOfLanguage: LevelOfLanguage;
}

import { Module } from '@nestjs/common';
import { GroupLanguageService } from './group-language.service';
import { GroupLanguageController } from './group-language.controller';
import { DatabaseModule } from '../../../database/database.module';
import { TokenModule } from '../../../services/token/token.module';

@Module({
	imports: [DatabaseModule, TokenModule],
	providers: [GroupLanguageService],
	controllers: [GroupLanguageController],
})
export class GroupLanguageModule {}

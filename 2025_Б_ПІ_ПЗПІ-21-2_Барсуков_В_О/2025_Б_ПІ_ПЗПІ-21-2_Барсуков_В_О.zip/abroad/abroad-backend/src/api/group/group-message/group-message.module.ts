import { Module } from '@nestjs/common';
import { GroupMessageService } from './group-message.service';
import { GroupMessageController } from './group-message.controller';
import { DatabaseModule } from '../../../database/database.module';
import { TokenModule } from '../../../services/token/token.module';

@Module({
	imports: [DatabaseModule, TokenModule],
	providers: [GroupMessageService],
	controllers: [GroupMessageController],
})
export class GroupMessageModule {}

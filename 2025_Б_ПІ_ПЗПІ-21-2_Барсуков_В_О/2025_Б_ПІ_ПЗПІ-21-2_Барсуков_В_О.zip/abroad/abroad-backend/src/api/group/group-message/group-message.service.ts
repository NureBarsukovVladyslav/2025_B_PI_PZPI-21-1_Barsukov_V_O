import { Injectable } from '@nestjs/common';
import { DatabaseService } from '../../../database/database.service';
import { CreateGroupMessageRequestDto } from './dto/CreateGroupMessage.request.dto';
import { TokenService } from '../../../services/token/token.service';

@Injectable()
export class GroupMessageService {
	constructor(private readonly databaseService: DatabaseService, private readonly tokenService: TokenService) {}

	async createGroupMessage(request: Request, groupId: number, dto: CreateGroupMessageRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		return await this.databaseService.groupMessage.create({
			data: {
				userId,
				groupId,
				...dto,
			},
		});
	}
}

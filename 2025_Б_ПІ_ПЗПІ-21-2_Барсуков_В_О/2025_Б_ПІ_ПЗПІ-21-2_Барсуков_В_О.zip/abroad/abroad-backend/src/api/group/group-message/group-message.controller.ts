import {
	Body,
	Controller,
	Param,
	ParseIntPipe,
	Patch,
	Req,
	UseInterceptors,
	UsePipes,
	ValidationPipe,
} from '@nestjs/common';
import { GroupMessageService } from './group-message.service';
import { ApiResponseCompleteOperationInterceptor } from '../../../common/interceptors/response/completeOperation.response.interceptor';
import { CreateGroupMessageRequestDto } from './dto/CreateGroupMessage.request.dto';

@Controller('group-message')
export class GroupMessageController {
	constructor(private readonly groupMessageService: GroupMessageService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Patch('/:id')
	async createMessage(
		@Req() request: Request,
		@Param('id', ParseIntPipe) groupId: number,
		@Body() dto: CreateGroupMessageRequestDto,
	) {
		return await this.groupMessageService.createGroupMessage(request, groupId, dto);
	}
}

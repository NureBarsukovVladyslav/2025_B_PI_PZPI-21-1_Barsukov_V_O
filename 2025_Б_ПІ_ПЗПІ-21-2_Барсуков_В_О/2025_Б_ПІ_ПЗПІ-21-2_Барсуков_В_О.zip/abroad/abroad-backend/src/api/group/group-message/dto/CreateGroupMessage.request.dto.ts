import { IsString, MaxLength, MinLength } from 'class-validator';
import { DEFAULT_STRING_MIN_LENGTH } from '../../../../constants/validator/default-value.constant';

export class CreateGroupMessageRequestDto {
	@IsString()
	@MinLength(DEFAULT_STRING_MIN_LENGTH)
	@MaxLength(1000)
	textOfMessage: string;
}

import {
	Body,
	Controller,
	Delete,
	Param,
	ParseIntPipe,
	Patch,
	Req,
	UseInterceptors,
	UsePipes,
	ValidationPipe,
} from '@nestjs/common';
import { GroupUserService } from './group-user.service';
import { ApiResponseCompleteOperationInterceptor } from '../../../common/interceptors/response/completeOperation.response.interceptor';
import { DeleteGroupUserRequestDto } from './dto/request/DeleteGroupUser.request.dto';

@Controller('group-user')
export class GroupUserController {
	constructor(private readonly groupUserService: GroupUserService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Patch('/add-user/:id')
	async addGroupUser(@Req() request: Request, @Param('id', ParseIntPipe) groupId: number) {
		return await this.groupUserService.addGroupUser(request, groupId);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Patch('/leave-user/:id')
	async leaveGroupUser(@Req() request: Request, @Param('id', ParseIntPipe) groupId: number) {
		return await this.groupUserService.leaveGroupUser(request, groupId);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Patch('/delete-user/:id')
	async deleteGroupUser(
		@Req() request: Request,
		@Param('id', ParseIntPipe) groupId: number,
		@Body() dto: DeleteGroupUserRequestDto,
	) {
		return await this.groupUserService.deleteGroupUser(request, groupId, dto);
	}
}

import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { DatabaseService } from '../../../database/database.service';
import { DeleteGroupUserRequestDto } from './dto/request/DeleteGroupUser.request.dto';
import { TokenService } from '../../../services/token/token.service';
import { RIGHT_ERROR_MESSAGE } from '../../../constants/errors/errors.constant';

@Injectable()
export class GroupUserService {
	constructor(private readonly databaseService: DatabaseService, private readonly tokenService: TokenService) {}

	async addGroupUser(request: Request, groupId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		return await this.databaseService.groupUser.create({
			data: {
				userId,
				groupId,
			},
		});
	}

	async leaveGroupUser(request: Request, groupId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const findGroup = await this.databaseService.groupUser.findFirst({
			where: { userId, groupId },
		});

		if (!findGroup) throw new HttpException('The user is not in the group', HttpStatus.BAD_REQUEST);

		return await this.databaseService.groupUser.delete({
			where: { groupUserId: findGroup.groupUserId },
		});
	}

	async deleteGroupUser(request: Request, groupId: number, dto: DeleteGroupUserRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const group = await this.databaseService.group.findUnique({
			where: { groupId },
		});

		if (!group) throw new HttpException('Group not found', HttpStatus.NOT_FOUND);
		if (group.userId !== userId) throw new HttpException(RIGHT_ERROR_MESSAGE, HttpStatus.FORBIDDEN);

		return await this.databaseService.groupUser.delete({
			where: { groupUserId: dto.groupUserId },
		});
	}
}

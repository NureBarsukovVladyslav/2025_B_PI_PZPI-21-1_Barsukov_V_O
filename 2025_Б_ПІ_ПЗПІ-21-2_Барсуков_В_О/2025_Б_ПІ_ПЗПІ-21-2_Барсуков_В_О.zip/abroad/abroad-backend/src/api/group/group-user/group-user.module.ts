import { Module } from '@nestjs/common';
import { GroupUserService } from './group-user.service';
import { GroupUserController } from './group-user.controller';
import { DatabaseModule } from '../../../database/database.module';
import { TokenModule } from '../../../services/token/token.module';

@Module({
	imports: [DatabaseModule, TokenModule],
	providers: [GroupUserService],
	controllers: [GroupUserController],
})
export class GroupUserModule {}

import { IsNumber, IsPositive } from 'class-validator';

export class DeleteGroupUserRequestDto {
	@IsNumber()
	@IsPositive()
	groupUserId: number;
}

import {
	Body,
	Controller,
	Delete,
	Get,
	Param,
	ParseIntPipe,
	Post,
	Put,
	Req,
	UseInterceptors,
	UsePipes,
	ValidationPipe,
} from '@nestjs/common';
import { GroupService } from './group.service';
import { ApiResponseCompleteOperationInterceptor } from '../../common/interceptors/response/completeOperation.response.interceptor';
import { CreateOrUpdateGroupRequestDto } from './dto/request/CreateOrUpdateGroup.request.dto';

@Controller('group')
export class GroupController {
	constructor(private readonly groupService: GroupService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Get('/recommendation')
	async getRecommendationGroups(@Req() request: Request) {
		return await this.groupService.getRecommendationGroups(request);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Get('/')
	async getGroups(@Req() request: Request) {
		return await this.groupService.getGroups(request);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Get('/:id')
	async getGroup(@Req() request: Request, @Param('id', ParseIntPipe) groupId: number) {
		return await this.groupService.getGroup(request, groupId);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Post('/')
	async createGroup(@Req() request: Request, @Body() dto: CreateOrUpdateGroupRequestDto) {
		return await this.groupService.createGroup(request, dto);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Put('/:id')
	async updateGroup(
		@Req() request: Request,
		@Param('id', ParseIntPipe) groupId: number,
		@Body() dto: CreateOrUpdateGroupRequestDto,
	) {
		return await this.groupService.updateGroup(request, groupId, dto);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Delete('/:id')
	async deleteGroup(@Req() request: Request, @Param('id', ParseIntPipe) groupId: number) {
		return await this.groupService.deleteGroup(request, groupId);
	}
}

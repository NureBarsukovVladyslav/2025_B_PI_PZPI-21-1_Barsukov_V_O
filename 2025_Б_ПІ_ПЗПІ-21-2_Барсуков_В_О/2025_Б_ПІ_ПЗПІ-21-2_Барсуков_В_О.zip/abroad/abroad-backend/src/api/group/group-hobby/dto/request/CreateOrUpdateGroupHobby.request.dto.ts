import { IsArray, IsEnum, IsNumber, IsPositive } from 'class-validator';
import { Hobby } from '@prisma/client';

export class CreateOrUpdateGroupHobbyRequestDto {
	@IsNumber()
	@IsPositive()
	groupId: number;

	@IsArray()
	@IsEnum(Hobby, { each: true })
	hobbies: Hobby[];
}

import { Body, Controller, Post, Req, UseInterceptors, UsePipes, ValidationPipe } from '@nestjs/common';
import { GroupHobbyService } from './group-hobby.service';
import { ApiResponseCompleteOperationInterceptor } from '../../../common/interceptors/response/completeOperation.response.interceptor';
import { CreateOrUpdateGroupHobbyRequestDto } from './dto/request/CreateOrUpdateGroupHobby.request.dto';

@Controller('group-hobby')
export class GroupHobbyController {
	constructor(private readonly groupHobbyService: GroupHobbyService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Post('/')
	async createGroupHobby(@Req() request: Request, @Body() dto: CreateOrUpdateGroupHobbyRequestDto) {
		return await this.groupHobbyService.createGroupHobby(request, dto);
	}
}

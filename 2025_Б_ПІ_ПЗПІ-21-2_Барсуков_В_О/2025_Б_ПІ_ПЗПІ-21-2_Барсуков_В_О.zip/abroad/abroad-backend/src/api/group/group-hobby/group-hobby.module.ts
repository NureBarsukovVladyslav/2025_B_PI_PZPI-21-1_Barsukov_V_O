import { Module } from '@nestjs/common';
import { GroupHobbyService } from './group-hobby.service';
import { GroupHobbyController } from './group-hobby.controller';
import { DatabaseModule } from '../../../database/database.module';
import { TokenModule } from '../../../services/token/token.module';

@Module({
	imports: [DatabaseModule, TokenModule],
	providers: [GroupHobbyService],
	controllers: [GroupHobbyController],
})
export class GroupHobbyModule {}

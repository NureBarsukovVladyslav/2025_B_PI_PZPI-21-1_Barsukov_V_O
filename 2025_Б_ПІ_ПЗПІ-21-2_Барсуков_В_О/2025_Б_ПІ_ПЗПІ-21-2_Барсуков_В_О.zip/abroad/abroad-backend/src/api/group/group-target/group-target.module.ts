import { Module } from '@nestjs/common';
import { GroupTargetService } from './group-target.service';
import { GroupTargetController } from './group-target.controller';
import { DatabaseModule } from '../../../database/database.module';
import { TokenModule } from '../../../services/token/token.module';

@Module({
	imports: [DatabaseModule, TokenModule],
	providers: [GroupTargetService],
	controllers: [GroupTargetController],
})
export class GroupTargetModule {}

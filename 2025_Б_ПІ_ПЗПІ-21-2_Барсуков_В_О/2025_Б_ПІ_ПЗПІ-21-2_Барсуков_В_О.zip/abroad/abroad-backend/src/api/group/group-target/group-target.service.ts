import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { DatabaseService } from '../../../database/database.service';
import { CreateOrUpdateGroupTargetRequestDto } from './dto/request/CreateOrUpdateGroupTarget.request.dto';
import { TokenService } from '../../../services/token/token.service';
import { RIGHT_ERROR_MESSAGE } from '../../../constants/errors/errors.constant';

@Injectable()
export class GroupTargetService {
	constructor(private readonly databaseService: DatabaseService, private readonly tokenService: TokenService) {}

	async createOrUpdateGroupTarget(request: Request, dto: CreateOrUpdateGroupTargetRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const group = await this.databaseService.group.findUnique({
			where: { groupId: dto.groupId },
		});

		if (!group) throw new HttpException('Group not found', HttpStatus.NOT_FOUND);
		if (group.userId !== userId) throw new HttpException(RIGHT_ERROR_MESSAGE, HttpStatus.FORBIDDEN);

		return await this.databaseService.group.update({
			where: { groupId: dto.groupId },
			data: {
				targets: {
					deleteMany: {},
					create: dto.targets.map((target) => {
						return { target };
					}),
				},
			},
		});
	}
}

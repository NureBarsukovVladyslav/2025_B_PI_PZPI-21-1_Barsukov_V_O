import { IsArray, IsEnum, IsNumber, IsPositive } from 'class-validator';
import { Target } from '@prisma/client';

export class CreateOrUpdateGroupTargetRequestDto {
	@IsNumber()
	@IsPositive()
	groupId: number;

	@IsArray()
	@IsEnum(Target, { each: true })
	targets: Target[];
}

import { Body, Controller, Post, Req, UseInterceptors, UsePipes, ValidationPipe } from '@nestjs/common';
import { GroupTargetService } from './group-target.service';
import { ApiResponseCompleteOperationInterceptor } from '../../../common/interceptors/response/completeOperation.response.interceptor';
import { CreateOrUpdateGroupTargetRequestDto } from './dto/request/CreateOrUpdateGroupTarget.request.dto';

@Controller('group-target')
export class GroupTargetController {
	constructor(private readonly groupTargetService: GroupTargetService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Post('/')
	async createOrUpdateGroupTarget(@Req() request: Request, @Body() dto: CreateOrUpdateGroupTargetRequestDto) {
		return await this.groupTargetService.createOrUpdateGroupTarget(request, dto);
	}
}

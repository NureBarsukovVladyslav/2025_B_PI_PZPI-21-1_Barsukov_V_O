import { Module } from '@nestjs/common';
import { GroupService } from './group.service';
import { GroupController } from './group.controller';
import { DatabaseModule } from '../../database/database.module';
import { GroupUserModule } from './group-user/group-user.module';
import { GroupMessageModule } from './group-message/group-message.module';
import { GroupLanguageModule } from './group-language/group-language.module';
import { GroupHobbyModule } from './group-hobby/group-hobby.module';
import { GroupTargetModule } from './group-target/group-target.module';
import { TokenModule } from '../../services/token/token.module';

@Module({
	imports: [
		DatabaseModule,
		TokenModule,
		GroupUserModule,
		GroupMessageModule,
		GroupLanguageModule,
		GroupHobbyModule,
		GroupTargetModule,
	],
	providers: [GroupService],
	controllers: [GroupController],
})
export class GroupModule {}

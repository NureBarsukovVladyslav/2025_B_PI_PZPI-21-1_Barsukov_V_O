import { HttpException, HttpStatus, Injectable, InternalServerErrorException } from '@nestjs/common';
import { TokenService } from '../../services/token/token.service';
import { DatabaseService } from '../../database/database.service';
import { LoginRequestDto } from './dto/request/login.request.dto';
import { LoginResponseDto } from './dto/response/login.response.dto';
import { SignupRequestDto } from './dto/request/signup.request.dto';
import * as bcrypt from 'bcrypt';
import * as process from 'node:process';
import { SignupResponseDto } from './dto/response/signup.response.dto';

@Injectable()
export class AuthService {
	constructor(private readonly tokenService: TokenService, private readonly databaseService: DatabaseService) {}

	async login(dto: LoginRequestDto): Promise<LoginResponseDto> {
		const findUser = await this.databaseService.user.findFirst({
			where: { email: dto.email },
		});
		
		if (!findUser) throw new HttpException('User not found', HttpStatus.NOT_FOUND);

		const isPasswordMatch = await bcrypt.compare(dto.password, findUser.password);

		if (!isPasswordMatch) throw new HttpException('Not correctly entered password', HttpStatus.BAD_REQUEST);

		return await this.tokenService.getTokens(findUser);
	}

	async signup(dto: SignupRequestDto): Promise<SignupResponseDto> {
		const findUser = await this.databaseService.user.findFirst({
			where: { email: dto.email },
		});

		if (findUser) throw new HttpException('User already exists', HttpStatus.BAD_REQUEST);

		const saltRounds = process.env.SALT_ROUNDS ? Number(process.env.SALT_ROUNDS) : 10;

		dto.password = await bcrypt.hash(dto.password, saltRounds);

		return await this.databaseService.$transaction(async (tx) => {
			const createUser = await tx.user.create({
				data: dto,
			});

			return await this.tokenService.getTokens({
				userId: createUser.userId,
				name: dto.name,
				surname: dto.surname,
				email: dto.email,
			});
		});
	}

	async refresh(userId: number | null | undefined) {
		if (!userId) throw new InternalServerErrorException('User not found');

		const findUser = await this.databaseService.user.findUnique({
			where: { userId },
		});

		if (!findUser) throw new HttpException('User not found', HttpStatus.NOT_FOUND);

		return await this.tokenService.getTokens(findUser);
	}
}

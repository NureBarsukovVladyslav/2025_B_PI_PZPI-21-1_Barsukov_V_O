export interface LoginResponseDto {
	access_token: string;
	refresh_token: string;
}

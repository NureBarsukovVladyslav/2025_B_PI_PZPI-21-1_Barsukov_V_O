export interface SignupResponseDto {
	access_token: string;
	refresh_token: string;
}

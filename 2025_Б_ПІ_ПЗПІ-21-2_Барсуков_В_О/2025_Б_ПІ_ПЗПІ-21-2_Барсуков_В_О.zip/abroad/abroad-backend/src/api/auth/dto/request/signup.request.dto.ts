import {
	IsEmail,
	IsEnum,
	IsISO8601,
	IsOptional,
	IsString,
	IsStrongPassword,
	MaxLength,
	MinLength,
} from 'class-validator';
import { DEFAULT_STRING_MIN_LENGTH } from '../../../../constants/validator/default-value.constant';
import { StatusOfStay, StatusOfUser, TypeOfGender } from '@prisma/client';

export class SignupRequestDto {
	@IsString()
	@MinLength(DEFAULT_STRING_MIN_LENGTH)
	@MaxLength(20)
	name: string;

	@IsString()
	@MinLength(DEFAULT_STRING_MIN_LENGTH)
	@MaxLength(20)
	surname: string;

	@IsEnum(TypeOfGender)
	gender: TypeOfGender;

	@IsEmail()
	email: string;

	@IsString()
	@IsStrongPassword({
		minLength: 6,
		minNumbers: 3,
		minUppercase: 1,
		minLowercase: 1,
		minSymbols: 1,
	})
	password: string;

	@IsOptional()
	@IsISO8601()
	dateOfBirth: Date | null;

	@IsString()
	country: string;

	@IsString()
	city: string;

	@IsOptional()
	@IsISO8601()
	dateOfArrival: Date | null;

	@IsOptional()
	@IsEnum(StatusOfStay)
	statusOfStay: StatusOfStay | null;

	@IsOptional()
	@IsEnum(StatusOfUser)
	statusOfUser: StatusOfUser | null;

	@IsOptional()
	@IsString()
	@MinLength(DEFAULT_STRING_MIN_LENGTH)
	@MaxLength(300)
	goalOfUser: string | null;
}

import { Body, Controller, Get, Post, Req, UseGuards, UseInterceptors, UsePipes, ValidationPipe } from '@nestjs/common';
import { AuthService } from './auth.service';
import { Public } from '../../common/decorators/public.decorator';
import { ApiResponseCompleteOperationInterceptor } from '../../common/interceptors/response/completeOperation.response.interceptor';
import { LoginRequestDto } from './dto/request/login.request.dto';
import { RefreshGuard } from '../../common/guards/refresh.guard';
import { SignupRequestDto } from './dto/request/signup.request.dto';

interface Req extends Request {
	user: {
		userId: number;
	};
}

@Controller('auth')
export class AuthController {
	constructor(private readonly authService: AuthService) {}

	@Public()
	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Post('/login')
	async login(@Body() dto: LoginRequestDto) {
		return await this.authService.login(dto);
	}

	@Public()
	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Post('/signup')
	async signup(@Body() dto: SignupRequestDto) {
		return await this.authService.signup(dto);
	}

	@Public()
	@UseGuards(RefreshGuard)
	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Get('/refresh')
	async refresh(@Req() request: Req) {
		return await this.authService.refresh(request.user.userId);
	}
}

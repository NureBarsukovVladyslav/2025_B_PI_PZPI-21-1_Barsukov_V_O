import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { DatabaseService } from '../../database/database.service';
import { CreateOrUpdateArticleRequestDto } from './dto/request/CreateOrUpdateArticle.request.dto';
import { SelectPreviewArticlePrismaDto } from './dto/prisma/SelectPreviewArticle.prisma.dto';
import { SelectFullArticlePrismaDto } from './dto/prisma/SelectFullArticle.prisma.dto';
import { TokenService } from '../../services/token/token.service';
import { RIGHT_ERROR_MESSAGE } from '../../constants/errors/errors.constant';

@Injectable()
export class ArticleService {
	constructor(private readonly databaseService: DatabaseService, private readonly tokenService: TokenService) {}

	async getArticles() {
		return await this.databaseService.article.findMany({
			select: SelectPreviewArticlePrismaDto,
		});
	}

	async getArticle(request: Request, articleId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const article = await this.databaseService.article.findUnique({
			select: SelectFullArticlePrismaDto,
			where: { articleId },
		});

		if (!article) throw new HttpException('Article not found', HttpStatus.NOT_FOUND);

		return {
			isOwner: article.author.userId === userId,
			...article,
		};
	}

	async createArticle(request: Request, dto: CreateOrUpdateArticleRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		return await this.databaseService.article.create({
			data: {
				userId,
				...dto,
			},
		});
	}

	async updateArticle(request: Request, articleId: number, dto: CreateOrUpdateArticleRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const article = await this.databaseService.article.findUnique({
			where: { articleId },
		});

		if (!article) throw new HttpException('Article not found', HttpStatus.NOT_FOUND);
		if (article.userId !== userId) throw new HttpException(RIGHT_ERROR_MESSAGE, HttpStatus.FORBIDDEN);

		return await this.databaseService.article.update({
			where: { articleId },
			data: dto,
		});
	}

	async deleteArticle(request: Request, articleId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const article = await this.databaseService.article.findUnique({
			where: { articleId },
		});

		if (!article) throw new HttpException('Article not found', HttpStatus.NOT_FOUND);
		if (article.userId !== userId) throw new HttpException(RIGHT_ERROR_MESSAGE, HttpStatus.FORBIDDEN);

		return await this.databaseService.article.delete({
			where: { articleId },
		});
	}
}

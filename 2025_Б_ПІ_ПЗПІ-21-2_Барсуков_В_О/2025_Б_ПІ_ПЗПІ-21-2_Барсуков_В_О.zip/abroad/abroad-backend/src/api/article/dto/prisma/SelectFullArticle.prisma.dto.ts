import { Prisma } from '@prisma/client';
import { DefaultArgs } from '@prisma/client/runtime/library';

const SelectArticleAuthorPrismaDto: Prisma.UserDefaultArgs<DefaultArgs> = {
	select: {
		userId: true,
		name: true,
		surname: true,
		avatar: true,
	},
};

export const SelectFullArticlePrismaDto: Prisma.ArticleSelect = {
	articleId: true,
	nameOfArticle: true,
	description: true,
	content: true,
	email: true,
	link: true,
	nameOfLink: true,
	target: true,
	statusOfUser: true,
	updatedAt: true,
	createdAt: true,
	author: SelectArticleAuthorPrismaDto,
};

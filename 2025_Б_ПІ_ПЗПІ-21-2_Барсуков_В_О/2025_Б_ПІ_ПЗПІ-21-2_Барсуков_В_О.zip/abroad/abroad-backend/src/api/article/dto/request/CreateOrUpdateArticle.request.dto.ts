import { IsEmail, IsEnum, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';
import { DEFAULT_STRING_MIN_LENGTH } from '../../../../constants/validator/default-value.constant';
import { StatusOfUser, Target } from '@prisma/client';

export class CreateOrUpdateArticleRequestDto {
	@IsString()
	@MinLength(DEFAULT_STRING_MIN_LENGTH)
	@MaxLength(150)
	nameOfArticle: string;

	@IsString()
	@MinLength(DEFAULT_STRING_MIN_LENGTH)
	@MaxLength(500)
	description: string;

	@IsString()
	@MinLength(100)
	@MaxLength(3000)
	content: string;

	@IsOptional()
	@IsEmail()
	@MaxLength(50)
	email: string | null;

	@IsOptional()
	@IsString()
	@MinLength(DEFAULT_STRING_MIN_LENGTH)
	link: string | null;

	@IsOptional()
	@IsString()
	@MinLength(DEFAULT_STRING_MIN_LENGTH)
	@MaxLength(50)
	nameOfLink: string | null;

	@IsEnum(StatusOfUser)
	statusOfUser: StatusOfUser;

	@IsEnum(Target)
	target: Target;
}

import { Prisma } from '@prisma/client';
import { DefaultArgs } from '@prisma/client/runtime/library';

const SelectArticleAuthorPrismaDto: Prisma.UserDefaultArgs<DefaultArgs> = {
	select: {
		userId: true,
		name: true,
		surname: true,
		avatar: true,
	},
};

export const SelectPreviewArticlePrismaDto: Prisma.ArticleSelect = {
	articleId: true,
	nameOfArticle: true,
	description: true,
	target: true,
	statusOfUser: true,
	author: SelectArticleAuthorPrismaDto,
};

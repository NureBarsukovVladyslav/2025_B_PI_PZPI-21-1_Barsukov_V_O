import { Module } from '@nestjs/common';
import { ArticleService } from './article.service';
import { ArticleController } from './article.controller';
import { DatabaseModule } from '../../database/database.module';
import { TokenModule } from '../../services/token/token.module';

@Module({
	imports: [DatabaseModule, TokenModule],
	providers: [ArticleService],
	controllers: [ArticleController],
})
export class ArticleModule {}

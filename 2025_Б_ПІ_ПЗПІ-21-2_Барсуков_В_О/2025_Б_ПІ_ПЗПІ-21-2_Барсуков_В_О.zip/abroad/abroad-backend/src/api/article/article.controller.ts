import {
	Body,
	Controller,
	Delete,
	Get,
	Param,
	ParseIntPipe,
	Post,
	Put,
	Req,
	UseInterceptors,
	UsePipes,
	ValidationPipe,
} from '@nestjs/common';
import { ArticleService } from './article.service';
import { ApiResponseCompleteOperationInterceptor } from '../../common/interceptors/response/completeOperation.response.interceptor';
import { CreateOrUpdateArticleRequestDto } from './dto/request/CreateOrUpdateArticle.request.dto';

@Controller('article')
export class ArticleController {
	constructor(private readonly articleService: ArticleService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Get('/')
	async getArticles() {
		return await this.articleService.getArticles();
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Get('/:id')
	async getArticle(@Req() request: Request, @Param('id', ParseIntPipe) articleId: number) {
		return await this.articleService.getArticle(request, articleId);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Post('/')
	async createArticle(@Req() request: Request, @Body() dto: CreateOrUpdateArticleRequestDto) {
		return await this.articleService.createArticle(request, dto);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Put('/:id')
	async updateArticle(
		@Req() request: Request,
		@Param('id', ParseIntPipe) articleId: number,
		@Body() dto: CreateOrUpdateArticleRequestDto,
	) {
		return await this.articleService.updateArticle(request, articleId, dto);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Delete('/:id')
	async deleteArticle(@Req() request: Request, @Param('id', ParseIntPipe) articleId: number) {
		return await this.articleService.deleteArticle(request, articleId);
	}
}

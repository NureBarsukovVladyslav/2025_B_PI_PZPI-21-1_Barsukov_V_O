import { Prisma } from '@prisma/client';
import { DefaultArgs } from '@prisma/client/runtime/library';

const SelectEventUserPrismaDto: Prisma.EventUserDefaultArgs<DefaultArgs> = {
	select: {
		eventUserId: true,
		user: {
			select: {
				userId: true,
				name: true,
				surname: true,
				avatar: true,
			},
		},
	},
};

const SelectEventTargetPrismaDto: Prisma.EventTargetDefaultArgs<DefaultArgs> = {
	select: {
		eventTargetId: true,
		target: true,
	},
};

const SelectEventGroupPrismaDto: Prisma.EventGroupDefaultArgs<DefaultArgs> = {
	select: {
		groupEventId: true,
		group: {
			select: {
				groupId: true,
				nameOfGroup: true,
				avatar: true,
			},
		},
	},
};

const SelectEventAuthorPrismaDto: Prisma.UserDefaultArgs<DefaultArgs> = {
	select: {
		userId: true,
		name: true,
		surname: true,
		avatar: true,
	},
};

export const SelectFullEventPrismaDto: Prisma.EventSelect = {
	eventId: true,
	nameOfEvent: true,
	description: true,
	dateOfEvent: true,
	timeStart: true,
	timeEnd: true,
	country: true,
	city: true,
	address: true,
	users: SelectEventUserPrismaDto,
	targets: SelectEventTargetPrismaDto,
	groups: SelectEventGroupPrismaDto,
	author: SelectEventAuthorPrismaDto,
};

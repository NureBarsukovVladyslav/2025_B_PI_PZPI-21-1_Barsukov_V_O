import { Prisma } from '@prisma/client';
import { DefaultArgs } from '@prisma/client/runtime/library';

const SelectEventTargetPrismaDto: Prisma.EventTargetDefaultArgs<DefaultArgs> = {
	select: {
		eventTargetId: true,
		target: true,
	},
};

const SelectEventGroupPrismaDto: Prisma.EventGroupDefaultArgs<DefaultArgs> = {
	select: {
		groupEventId: true,
		group: {
			select: {
				groupId: true,
				nameOfGroup: true,
				avatar: true,
			},
		},
	},
};

export const SelectPreviewEventPrismaDto: Prisma.EventSelect = {
	eventId: true,
	nameOfEvent: true,
	dateOfEvent: true,
	timeStart: true,
	timeEnd: true,
	country: true,
	city: true,
	address: true,
	targets: SelectEventTargetPrismaDto,
	groups: SelectEventGroupPrismaDto,
};

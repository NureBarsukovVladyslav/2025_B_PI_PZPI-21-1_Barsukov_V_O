import { IsISO8601, IsString, MaxLength, MinLength } from 'class-validator';
import { DEFAULT_STRING_MIN_LENGTH } from '../../../../constants/validator/default-value.constant';

export class CreateOrUpdateEventRequestDto {
	@IsString()
	@MinLength(DEFAULT_STRING_MIN_LENGTH)
	@MaxLength(100)
	nameOfEvent: string;

	@IsString()
	@MinLength(DEFAULT_STRING_MIN_LENGTH)
	@MaxLength(1000)
	description: string;

	@IsISO8601()
	dateOfEvent: Date;

	@IsString()
	@MinLength(5)
	@MaxLength(5)
	timeStart: string;

	@IsString()
	@MinLength(5)
	@MaxLength(5)
	timeEnd: string;

	@IsString()
	country: string;

	@IsString()
	city: string;

	@IsString()
	address: string;
}

import { Module } from '@nestjs/common';
import { EventController } from './event.controller';
import { EventService } from './event.service';
import { DatabaseModule } from '../../database/database.module';
import { EventUserModule } from './event-user/event-user.module';
import { EventGroupModule } from './event-group/event-group.module';
import { EventTargetModule } from './event-target/event-target.module';
import { TokenModule } from '../../services/token/token.module';

@Module({
	imports: [DatabaseModule, TokenModule, EventUserModule, EventGroupModule, EventTargetModule],
	controllers: [EventController],
	providers: [EventService],
})
export class EventModule {}

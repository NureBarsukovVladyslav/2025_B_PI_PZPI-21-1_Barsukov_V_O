import {
	Body,
	Controller,
	Delete,
	Get,
	Param,
	ParseIntPipe,
	Post,
	Put,
	Req,
	UseInterceptors,
	UsePipes,
	ValidationPipe,
} from '@nestjs/common';
import { EventService } from './event.service';
import { ApiResponseCompleteOperationInterceptor } from '../../common/interceptors/response/completeOperation.response.interceptor';
import { CreateOrUpdateEventRequestDto } from './dto/request/CreateOrUpdateEvent.request.dto';

@Controller('event')
export class EventController {
	constructor(private readonly eventService: EventService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Get('/')
	async getEvents() {
		return await this.eventService.getEvents();
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Get('/:id')
	async getEvent(@Req() request: Request, @Param('id', ParseIntPipe) eventId: number) {
		return await this.eventService.getEvent(request, eventId);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Post('/')
	async createEvent(@Req() request: Request, @Body() dto: CreateOrUpdateEventRequestDto) {
		return await this.eventService.createEvent(request, dto);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Put('/:id')
	async updateEvent(
		@Req() request: Request,
		@Param('id', ParseIntPipe) eventId: number,
		@Body() dto: CreateOrUpdateEventRequestDto,
	) {
		return await this.eventService.updateEvent(request, eventId, dto);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Delete('/:id')
	async deleteEvent(@Req() request: Request, @Param('id', ParseIntPipe) eventId: number) {
		return await this.eventService.deleteEvent(request, eventId);
	}
}

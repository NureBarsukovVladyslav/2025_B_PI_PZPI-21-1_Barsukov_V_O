import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { DatabaseService } from '../../../database/database.service';
import { SubscribeOrUnsubscribeEventGroupRequestDto } from './dto/request/SubscribeOrUnsubscribeEventGroup.request.dto';
import { TokenService } from '../../../services/token/token.service';
import { RIGHT_ERROR_MESSAGE } from '../../../constants/errors/errors.constant';

@Injectable()
export class EventGroupService {
	constructor(private readonly databaseService: DatabaseService, private readonly tokenService: TokenService) {}

	async subscribeEvent(request: Request, eventId: number, dto: SubscribeOrUnsubscribeEventGroupRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const group = await this.databaseService.group.findUnique({
			where: { groupId: dto.groupId },
		});

		if (!group) throw new HttpException('Group not found', HttpStatus.NOT_FOUND);
		if (group.userId !== userId) throw new HttpException(RIGHT_ERROR_MESSAGE, HttpStatus.FORBIDDEN);

		return await this.databaseService.eventGroup.create({
			data: {
				eventId,
				groupId: dto.groupId,
			},
		});
	}

	async unsubscribeEvent(request: Request, eventId: number, dto: SubscribeOrUnsubscribeEventGroupRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const group = await this.databaseService.group.findUnique({
			where: { groupId: dto.groupId },
		});

		if (!group) throw new HttpException('Group not found', HttpStatus.NOT_FOUND);
		if (group.userId !== userId) throw new HttpException(RIGHT_ERROR_MESSAGE, HttpStatus.FORBIDDEN);

		const findEventGroup = await this.databaseService.eventGroup.findFirst({
			where: { eventId, groupId: dto.groupId },
		});

		if (!findEventGroup) throw new HttpException('The event was not found', HttpStatus.NOT_FOUND);

		return await this.databaseService.eventGroup.delete({
			where: { groupEventId: findEventGroup.groupEventId },
		});
	}
}

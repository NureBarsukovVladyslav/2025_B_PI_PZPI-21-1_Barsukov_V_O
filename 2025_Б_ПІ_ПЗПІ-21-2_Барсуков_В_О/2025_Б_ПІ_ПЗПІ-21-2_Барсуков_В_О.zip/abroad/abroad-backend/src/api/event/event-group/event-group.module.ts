import { Module } from '@nestjs/common';
import { EventGroupService } from './event-group.service';
import { EventGroupController } from './event-group.controller';
import { DatabaseModule } from '../../../database/database.module';
import { TokenModule } from '../../../services/token/token.module';

@Module({
	imports: [DatabaseModule, TokenModule],
	providers: [EventGroupService],
	controllers: [EventGroupController],
})
export class EventGroupModule {}

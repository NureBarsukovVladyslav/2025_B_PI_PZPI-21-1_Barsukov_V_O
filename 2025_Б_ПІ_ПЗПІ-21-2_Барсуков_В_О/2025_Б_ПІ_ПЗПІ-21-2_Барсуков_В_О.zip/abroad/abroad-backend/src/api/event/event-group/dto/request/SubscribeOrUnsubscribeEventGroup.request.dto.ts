import { IsNumber, IsPositive } from 'class-validator';

export class SubscribeOrUnsubscribeEventGroupRequestDto {
	@IsNumber()
	@IsPositive()
	groupId: number;
}

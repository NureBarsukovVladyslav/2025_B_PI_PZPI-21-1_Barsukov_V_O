import {
	Body,
	Controller,
	Param,
	ParseIntPipe,
	Patch,
	Req,
	UseInterceptors,
	UsePipes,
	ValidationPipe,
} from '@nestjs/common';
import { EventGroupService } from './event-group.service';
import { ApiResponseCompleteOperationInterceptor } from '../../../common/interceptors/response/completeOperation.response.interceptor';
import { SubscribeOrUnsubscribeEventGroupRequestDto } from './dto/request/SubscribeOrUnsubscribeEventGroup.request.dto';

@Controller('event-group')
export class EventGroupController {
	constructor(private readonly eventGroupService: EventGroupService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Patch('/subscribe/:id')
	async subscribeEvent(
		@Req() request: Request,
		@Param('id', ParseIntPipe) eventId: number,
		@Body() dto: SubscribeOrUnsubscribeEventGroupRequestDto,
	) {
		return await this.eventGroupService.subscribeEvent(request, eventId, dto);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Patch('/unsubscribe/:id')
	async unsubscribeEvent(
		@Req() request: Request,
		@Param('id', ParseIntPipe) eventId: number,
		@Body() dto: SubscribeOrUnsubscribeEventGroupRequestDto,
	) {
		return await this.eventGroupService.unsubscribeEvent(request, eventId, dto);
	}
}

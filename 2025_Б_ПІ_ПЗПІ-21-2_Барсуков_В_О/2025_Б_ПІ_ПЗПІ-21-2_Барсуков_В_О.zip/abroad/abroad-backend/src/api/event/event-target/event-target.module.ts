import { Module } from '@nestjs/common';
import { EventTargetService } from './event-target.service';
import { EventTargetController } from './event-target.controller';
import { DatabaseModule } from '../../../database/database.module';
import { TokenModule } from '../../../services/token/token.module';

@Module({
	imports: [DatabaseModule, TokenModule],
	providers: [EventTargetService],
	controllers: [EventTargetController],
})
export class EventTargetModule {}

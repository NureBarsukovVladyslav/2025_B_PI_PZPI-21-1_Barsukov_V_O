import { IsArray, IsEnum, IsNumber, IsPositive } from 'class-validator';
import { Target } from '@prisma/client';

export class CreateOrDeleteEventTargetRequestDto {
	@IsNumber()
	@IsPositive()
	eventId: number;

	@IsArray()
	@IsEnum(Target, { each: true })
	targets: Target[];
}

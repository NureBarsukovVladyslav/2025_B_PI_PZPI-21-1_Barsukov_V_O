import { Body, Controller, Post, Req, UseInterceptors, UsePipes, ValidationPipe } from '@nestjs/common';
import { EventTargetService } from './event-target.service';
import { ApiResponseCompleteOperationInterceptor } from '../../../common/interceptors/response/completeOperation.response.interceptor';
import { CreateOrDeleteEventTargetRequestDto } from './dto/request/CreateOrDeleteEventTarget.request.dto';

@Controller('event-target')
export class EventTargetController {
	constructor(private readonly eventTargetService: EventTargetService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@UsePipes(new ValidationPipe())
	@Post('/')
	async createOrUpdateEventTarget(@Req() request: Request, @Body() dto: CreateOrDeleteEventTargetRequestDto) {
		return await this.eventTargetService.createOrUpdateEventTarget(request, dto);
	}
}

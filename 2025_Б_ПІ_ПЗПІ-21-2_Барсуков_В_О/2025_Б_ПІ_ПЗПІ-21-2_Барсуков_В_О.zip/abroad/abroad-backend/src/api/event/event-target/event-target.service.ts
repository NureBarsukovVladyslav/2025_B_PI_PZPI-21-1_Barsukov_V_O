import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { DatabaseService } from '../../../database/database.service';
import { CreateOrDeleteEventTargetRequestDto } from './dto/request/CreateOrDeleteEventTarget.request.dto';
import { RIGHT_ERROR_MESSAGE } from '../../../constants/errors/errors.constant';
import { TokenService } from '../../../services/token/token.service';

@Injectable()
export class EventTargetService {
	constructor(private readonly databaseService: DatabaseService, private readonly tokenService: TokenService) {}

	async createOrUpdateEventTarget(request: Request, dto: CreateOrDeleteEventTargetRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const event = await this.databaseService.event.findUnique({
			where: { eventId: dto.eventId },
		});

		if (!event) throw new HttpException('Event not found', HttpStatus.NOT_FOUND);
		if (event.userId !== userId) throw new HttpException(RIGHT_ERROR_MESSAGE, HttpStatus.FORBIDDEN);

		return await this.databaseService.event.update({
			where: { eventId: dto.eventId },
			data: {
				targets: {
					deleteMany: {},
					create: dto.targets.map((target) => {
						return { target };
					}),
				},
			},
		});
	}
}

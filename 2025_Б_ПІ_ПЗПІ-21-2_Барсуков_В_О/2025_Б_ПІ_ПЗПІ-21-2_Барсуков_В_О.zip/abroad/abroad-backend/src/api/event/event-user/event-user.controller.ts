import { Controller, Param, ParseIntPipe, Patch, Req, UseInterceptors } from '@nestjs/common';
import { EventUserService } from './event-user.service';
import { ApiResponseCompleteOperationInterceptor } from '../../../common/interceptors/response/completeOperation.response.interceptor';

@Controller('event-user')
export class EventUserController {
	constructor(private readonly eventUserService: EventUserService) {}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Patch('/subscribe/:id')
	async subscribeEvent(@Req() request: Request, @Param('id', ParseIntPipe) eventId: number) {
		return await this.eventUserService.subscribeEvent(request, eventId);
	}

	@UseInterceptors(ApiResponseCompleteOperationInterceptor)
	@Patch('/unsubscribe/:id')
	async unsubscribeEvent(@Req() request: Request, @Param('id', ParseIntPipe) eventId: number) {
		return await this.eventUserService.unsubscribeEvent(request, eventId);
	}
}

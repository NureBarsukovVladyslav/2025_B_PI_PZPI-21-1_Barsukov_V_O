import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { DatabaseService } from '../../../database/database.service';
import { TokenService } from '../../../services/token/token.service';

@Injectable()
export class EventUserService {
	constructor(private readonly databaseService: DatabaseService, private readonly tokenService: TokenService) {}

	async subscribeEvent(request: Request, eventId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		return await this.databaseService.eventUser.create({
			data: {
				eventId,
				userId,
			},
		});
	}

	async unsubscribeEvent(request: Request, eventId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const findEvent = await this.databaseService.eventUser.findFirst({
			where: { userId, eventId },
		});

		if (!findEvent) throw new HttpException('The event was not found', HttpStatus.NOT_FOUND);

		return await this.databaseService.eventUser.delete({
			where: { eventUserId: findEvent.eventUserId },
		});
	}
}

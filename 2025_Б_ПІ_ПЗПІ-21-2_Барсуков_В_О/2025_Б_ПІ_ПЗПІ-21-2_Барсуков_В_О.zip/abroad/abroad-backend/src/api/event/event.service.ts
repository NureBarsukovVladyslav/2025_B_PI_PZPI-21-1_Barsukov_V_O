import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { DatabaseService } from '../../database/database.service';
import { SelectPreviewEventPrismaDto } from './dto/prisma/SelectPreviewEvent.prisma.dto';
import { SelectFullEventPrismaDto } from './dto/prisma/SelectFullEvent.prisma.dto';
import { CreateOrUpdateEventRequestDto } from './dto/request/CreateOrUpdateEvent.request.dto';
import { TokenService } from '../../services/token/token.service';
import { RIGHT_ERROR_MESSAGE } from '../../constants/errors/errors.constant';

@Injectable()
export class EventService {
	constructor(private readonly databaseService: DatabaseService, private readonly tokenService: TokenService) {}

	async getEvents() {
		return await this.databaseService.event.findMany({
			select: SelectPreviewEventPrismaDto,
		});
	}

	async getEvent(request: Request, eventId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const event: any = await this.databaseService.event.findUnique({
			select: SelectFullEventPrismaDto,
			where: { eventId },
		});

		if (!event) throw new HttpException('Event not found', HttpStatus.NOT_FOUND);

		const isOwner = event.author.userId === userId;
		const isParticipant = event.users.some((item: any) => item.user.userId === userId);

		return {
			...event,
			isOwner,
			isParticipant,
		};
	}

	async createEvent(request: Request, dto: CreateOrUpdateEventRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		return await this.databaseService.event.create({
			data: {
				userId,
				...dto,
				users: {
					create: {
						userId,
					},
				},
			},
		});
	}

	async updateEvent(request: Request, eventId: number, dto: CreateOrUpdateEventRequestDto) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const event = await this.databaseService.event.findUnique({
			where: { eventId },
		});

		if (!event) throw new HttpException('Event not found', HttpStatus.NOT_FOUND);
		if (event.userId !== userId) throw new HttpException(RIGHT_ERROR_MESSAGE, HttpStatus.FORBIDDEN);

		return await this.databaseService.event.update({
			where: { eventId },
			data: dto,
		});
	}

	async deleteEvent(request: Request, eventId: number) {
		const userId = await this.tokenService.getUserIdFromToken(request);

		const event = await this.databaseService.event.findUnique({
			where: { eventId },
		});

		if (!event) throw new HttpException('Event not found', HttpStatus.NOT_FOUND);
		if (event.userId !== userId) throw new HttpException(RIGHT_ERROR_MESSAGE, HttpStatus.FORBIDDEN);

		return await this.databaseService.event.delete({
			where: { eventId },
		});
	}
}

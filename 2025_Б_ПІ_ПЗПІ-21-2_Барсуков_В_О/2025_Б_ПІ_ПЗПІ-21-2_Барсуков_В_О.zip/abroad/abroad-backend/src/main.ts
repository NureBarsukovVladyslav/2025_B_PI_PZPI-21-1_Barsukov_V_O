import { HttpAdapterHost, NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import * as cookieParser from 'cookie-parser';
import { PrismaClientExceptionFilter } from './common/filters/prismaClientException.filter';
import { getCORSConfig } from './configs/cors-politics.config';
import { ConfigService } from '@nestjs/config';

async function bootstrap() {
	const app = await NestFactory.create(AppModule);
	const configService = app.get(ConfigService);
	const { httpAdapter } = app.get(HttpAdapterHost);

	app.use(cookieParser());
	app.setGlobalPrefix('api');
	app.useGlobalFilters(new PrismaClientExceptionFilter(httpAdapter));
	app.enableCors(await getCORSConfig(configService));

	await app.listen(3000);
}
bootstrap();

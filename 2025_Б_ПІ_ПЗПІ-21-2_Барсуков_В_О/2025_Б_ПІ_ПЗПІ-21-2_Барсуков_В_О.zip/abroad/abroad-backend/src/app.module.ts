import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UserModule } from './api/user/user.module';
import { DatabaseModule } from './database/database.module';
import { GroupModule } from './api/group/group.module';
import { ArticleModule } from './api/article/article.module';
import { EventModule } from './api/event/event.module';
import { TokenModule } from './services/token/token.module';
import { AuthModule } from './api/auth/auth.module';
import { APP_GUARD } from '@nestjs/core';
import { AuthGuard } from './api/auth/auth.guard';

@Module({
	imports: [UserModule, DatabaseModule, GroupModule, ArticleModule, EventModule, TokenModule, AuthModule],
	controllers: [AppController],
	providers: [AppService, { provide: APP_GUARD, useClass: AuthGuard }],
})
export class AppModule {}

import { CallHandler, ExecutionContext, HttpException, HttpStatus, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable, map } from 'rxjs';
import { Reflector } from '@nestjs/core';
import { RequestMethods } from '../request-methods.constant';
import { DEFAULT_RESPONSE_MESSAGE } from '../response-messages.constant';

@Injectable()
export class ApiResponseCompleteOperationInterceptor implements NestInterceptor {
	constructor(private reflector: Reflector) {}

	intercept(context: ExecutionContext, next: CallHandler<any>): Observable<any> | Promise<Observable<any>> {
		return next.handle().pipe(
			map((data) => {
				if (!data) throw new HttpException('Operation failed', HttpStatus.BAD_REQUEST);

				const requestMethod: RequestMethods = context.switchToHttp().getRequest().method;

				return {
					statusCode: HttpStatus.OK,
					message:
						this.reflector.get<string>('responseMessage', context.getHandler()) ||
						DEFAULT_RESPONSE_MESSAGE[requestMethod],
					data,
				};
			}),
		);
	}
}

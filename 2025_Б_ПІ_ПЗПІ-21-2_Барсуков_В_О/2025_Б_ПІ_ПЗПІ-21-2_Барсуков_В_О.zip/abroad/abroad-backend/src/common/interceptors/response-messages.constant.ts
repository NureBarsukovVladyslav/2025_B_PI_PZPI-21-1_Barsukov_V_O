import { RequestMethods } from './request-methods.constant';

// SUCCESSFUL OPERATIONS
export const RESPONSE_MESSAGE_OPERATION_IS_SUCCESSFUL = 'The operation is successful';
export const RESPONSE_MESSAGE_CREATION_SUCCESSFUL = 'The creation is successful';
export const RESPONSE_MESSAGE_UPDATE_SUCCESSFUL = 'The update is successful';
export const RESPONSE_MESSAGE_DELETION_SUCCESSFUL = 'The deletion is successful';

// FAILED OPERATIONS
export const RESPONSE_MESSAGE_OPERATION_FAILED = 'The operation failed';
export const RESPONSE_MESSAGE_CREATION_FAILED = 'Creation failed';
export const RESPONSE_MESSAGE_UPDATE_FAILED = 'Update failed';
export const RESPONSE_MESSAGE_DELETION_FAILED = 'Deletion failed';

// OTHER OPERATIONS
export const RESPONSE_MESSAGE_USER_ALREADY_EXISTS = 'User with this email already exists';
export const RESPONSE_MESSAGE_ALREADY_EXISTS = 'Resource already exists';
export const RESPONSE_MESSAGE_NOT_MODIFIED = 'Resource not modified';
export const RESPONSE_MESSAGE_SERVICE_UNAVAILABLE = 'Service unavailable';

export const DEFAULT_RESPONSE_MESSAGE: { [method: string]: string } = {
	[RequestMethods.GET]: RESPONSE_MESSAGE_OPERATION_IS_SUCCESSFUL,
	[RequestMethods.POST]: RESPONSE_MESSAGE_CREATION_SUCCESSFUL,
	[RequestMethods.PUT]: RESPONSE_MESSAGE_UPDATE_SUCCESSFUL,
	[RequestMethods.DELETE]: RESPONSE_MESSAGE_DELETION_SUCCESSFUL,
	[RequestMethods.PATCH]: RESPONSE_MESSAGE_OPERATION_IS_SUCCESSFUL,
};

import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { TokenService } from '../../services/token/token.service';
import { Request } from 'express';

@Injectable()
export class RefreshGuard implements CanActivate {
	constructor(private readonly reflector: Reflector, private readonly tokenService: TokenService) {}

	async canActivate(context: ExecutionContext): Promise<boolean> {
		try {
			const request: Request = context.switchToHttp().getRequest();

			const refreshToken = request.cookies['refresh_token'];

			request.user = await this.tokenService.verifyRefreshToken(refreshToken);

			return true;
		} catch (error) {
			throw new UnauthorizedException('Refresh token error', error.message);
		}
	}
}

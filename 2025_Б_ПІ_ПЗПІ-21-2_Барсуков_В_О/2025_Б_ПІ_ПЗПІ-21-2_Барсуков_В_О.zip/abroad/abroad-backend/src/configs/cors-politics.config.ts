import { ConfigService } from '@nestjs/config';

const ALLOW_ORIGIN = 'http://localhost:4000';

export const getCORSConfig = async (configService: ConfigService) => {
	return {
		origin: getOriginCheckCallback(configService),
		methods: ['GET', 'PUT', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
		allowedHeaders: ['Origin', 'X-Requested-With', 'Content-Type', 'Accept', 'Authorization'],
		credentials: true,
		preflightContinue: false,
	};
};

function getOriginCheckCallback(
	configService: ConfigService,
): (origin: string, callback: (error: Error | null, allow: boolean) => void) => void {
	return async (origin, callback) => {
		if (!origin || origin === ALLOW_ORIGIN) {
			callback(null, true);
		} else {
			callback(new Error('Not allowed by CORS'), false);
		}
	};
}

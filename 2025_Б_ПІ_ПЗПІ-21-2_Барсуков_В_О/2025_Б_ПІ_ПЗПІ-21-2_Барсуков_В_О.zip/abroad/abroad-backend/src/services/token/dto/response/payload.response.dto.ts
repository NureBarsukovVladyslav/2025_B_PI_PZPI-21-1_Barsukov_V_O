export interface PayloadResponseDto {
	userId: number;
	name: string;
	surname: string;
	email: string;
}

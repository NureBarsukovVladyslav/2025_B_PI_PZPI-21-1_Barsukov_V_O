import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { JwtService, JwtSignOptions } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { PayloadResponseDto } from './dto/response/payload.response.dto';

interface AuthRequestHeaders extends Headers {
	authorization: string;
}

@Injectable()
export class TokenService {
	constructor(private readonly jwtService: JwtService, private readonly configService: ConfigService) {}

	private async getAccessJwtOptions(): Promise<JwtSignOptions> {
		return {
			secret: await this.configService.get<string>('JWT_ACCESS_TOKEN_SECRET'),
			expiresIn: await this.configService.get<string>('JWT_ACCESS_TOKEN_EXPIRATION'),
		};
	}

	private async getRefreshJwtOptions(): Promise<JwtSignOptions> {
		return {
			secret: await this.configService.get<string>('JWT_REFRESH_TOKEN_SECRET'),
			expiresIn: await this.configService.get<string>('JWT_REFRESH_TOKEN_EXPIRATION'),
		};
	}

	private extractTokenFromHeader(request: Request): string | undefined {
		const [type, token] = (request.headers as AuthRequestHeaders).authorization?.split(' ') ?? [];

		return type === 'Bearer' ? token : undefined;
	}

	async getTokens(payloadForAccessToken: PayloadResponseDto): Promise<{ access_token: string; refresh_token: string }> {
		const payloadForRefreshToken = { userId: payloadForAccessToken.userId };

		return {
			access_token: await this.jwtService.signAsync(payloadForAccessToken, await this.getAccessJwtOptions()),
			refresh_token: await this.jwtService.signAsync(payloadForRefreshToken, await this.getRefreshJwtOptions()),
		};
	}

	async verifyAccessToken(accessToken: string) {
		const secret = await this.configService.get('JWT_ACCESS_TOKEN_SECRET');
		return await this.jwtService.verify(accessToken, { secret });
	}

	async verifyRefreshToken(refreshToken: string) {
		const secret = await this.configService.get('JWT_REFRESH_TOKEN_SECRET');
		return await this.jwtService.verify(refreshToken, { secret });
	}

	async getUserIdFromToken(request: Request): Promise<number> {
		const token = this.extractTokenFromHeader(request) || '';
		const { userId } = await this.jwtService.decode(token);

		return Number(userId);
	}
}

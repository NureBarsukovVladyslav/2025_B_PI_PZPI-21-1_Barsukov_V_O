export const RIGHT_ERROR_MESSAGE = 'There is not enough rights to perform an action';
